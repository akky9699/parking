var temp_border = [];
$(document).ready(function () {
    $('.submit_btn').click(function () {

        var focus = false;
        var check_focus = false;
        var form_err = '';

        $(this).closest('form').find('[required="required"]').each(function (i, j) {

            if (typeof temp_border[i] === 'undefined') {
                temp_border[i] = $(this).css('border');
            }

            $(this).css('border', temp_border[i]);

            var min_length = parseInt($.trim($(this).attr('minlength')));
            var max_length = parseInt($.trim($(this).attr('maxlength')));

            var temp_val = $.trim($(this).val());
            var temp_length = parseInt($.trim($(this).val().length));

            var temp_type = $.trim($(this).attr('type'));
            var temp_name = $.trim($(this).attr('name'));
            if (temp_val == '') {
                $(this).css('border', '1px solid red');
                form_err = 'Enter value ' + i + ' \n';
                focus = true;
            }

            if (temp_type == 'email') {
                if (!isValidEmailAddress(temp_val)) {
                    $(this).css('border', '1px solid red');
                    form_err = 'Enter value ' + i + ' \n';
                    focus = true;
                }
            }

            if (temp_type == 'number') {
                if (!$.isNumeric(temp_val)) {
                    $(this).css('border', '1px solid red');
                    form_err = 'Enter value ' + i + ' \n';
                    focus = true;
                }

            }

//            if (temp_type == 'radio') {
//                var selected_count = $('[name="1"]:checked').length;
//                if (selected_count == 0) {
//                    $(this).css('border', '1px solid red');
//                    form_err = 'Enter value ' + i + ' \n';
//                    focus = true;
//                }
//            }

            if (max_length != '' && temp_length > max_length) {
                $(this).css('border', '1px solid red');
                form_err = 'Enter value ' + i + ' \n';
                focus = true;
            }

            if (min_length != '' && temp_length < min_length) {
                $(this).css('border', '1px solid red');
                form_err = 'Enter value ' + i + ' \n';
                focus = true;
            }


            if (focus == true) {
                if (check_focus == false) {
                    $(this).focus();
                    check_focus = true;
                }
            }

        });

        if (form_err != '') {
            console.log('ERROR : ' + form_err);
            return false;
        }

    });
});
function isValidEmailAddress(emailAddress) {
    var pattern = /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i;
    return pattern.test(emailAddress);
}

function toggleText(obj, text) {
    var obj_text = $(obj).text();

    if (obj_text != text) {
        $(obj).text(text);
        obj_text_temp = obj_text;
    } else {
        $(obj).text(obj_text_temp);
    }
}

function isNumber(evt) {
    evt = (evt) ? evt : window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode;
    if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
}