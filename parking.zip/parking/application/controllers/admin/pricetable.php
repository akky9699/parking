<?php

class pricetable extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->admin_logged = $this->session->userdata('admin_logged_in');
        if (empty($this->admin_logged)) {
            redirect(ADMIN_FOLDER . 'login');
        }
    }

    function index() {
        $data = array();
        $data['menu'] = 4;
        $data['submenu'] = '';
        $list = getdata('pricetable');
        $vehicle_type = getdata('vehicle_type');
        $parking_type = getdata('parking_type');

        $new_array = array();
        foreach ($parking_type as $p) {
            $new_array[$p['id']] = $p;
        }

        $parking_type = $new_array;
        
        if (isset($vehicle_type) && !empty($vehicle_type)) {
            foreach ($vehicle_type as &$vt) {

                if (isset($parking_type) && !empty($parking_type)) {
                    foreach ($parking_type as $pt) {

                        $check = 0;
                        $price = 0;
                        if (isset($list) && !empty($list)) {
                            foreach ($list as $l) {
                                if ($l['vehicle_type_id'] == $vt['id'] && $l['parking_type_id'] == $pt['id']) {
                                    $price = $l['price'];
                                }
                            }
                        }
                        $vt['pricearray'][$pt['id']] = $price;
                    }
                }
            }
        }

        $data['vehicle_type'] = $vehicle_type;
        $data['parking_type'] = $parking_type;

        $this->load->view(ADMIN_FOLDER . 'pricetable', $data);
    }

    function save() {
        if (isset($_POST['price']) && !empty($_POST['price'])) {
            foreach ($_POST['price'] as $vehicle_type_id => $vt) {
                foreach ($vt as $parking_type_id => $price) {
                    $array = array();
                    $array['vehicle_type_id'] = $vehicle_type_id;
                    $array['parking_type_id'] = $parking_type_id;
                    $array['price'] = $price;

                    $check = $this->db
                                    ->where('vehicle_type_id', $vehicle_type_id)
                                    ->where('parking_type_id', $parking_type_id)
                                    ->get('pricetable')->num_rows();

                    if ($check > 0) {
                        update_data($array, array('vehicle_type_id' => $vehicle_type_id, 'parking_type_id' => $parking_type_id), 'pricetable');
                    } else {
                        add_data($array, 'pricetable');
                    }
                }
            }
            $this->session->set_flashdata('msg', 'PRICE DETAILS SAVED !!!');
        }
        redirect(ADMIN_FOLDER . 'pricetable');
    }

}
