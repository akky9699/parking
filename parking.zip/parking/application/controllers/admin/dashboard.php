<?php

class dashboard extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->admin_login = $this->session->userdata('admin_logged_in');

        if (empty($this->admin_login)) {
            redirect(ADMIN_FOLDER . 'login');
        }
    }

    function index() {
        $data = array();
        $data['menu'] = 1;


        $format_arr = unserialize(DATE_FORMAT);
        $start_date = date('Y-m-d');

        $new_array = array();

        foreach ($format_arr as $key => $format) {
            if ($key == 1) {
                $end_date = date('d M Y');
                $format12 = 1;
            } else if ($key == 2) {
                $end_date = date('d M Y', strtotime('+ 1 week'));
                $format12 = 2;
            } else if ($key == 3) {
                $end_date = date('d M Y', strtotime('+ 1 month'));
                $format12 = 3;
            } else if ($key == 4) {
                $end_date = date('d M Y', strtotime('+ 1 year'));
                $format12 = 4;
            } else {
                break;
            }

            $this->db->select('sum(price) as price, count(id) as count');
//            $this->db->where('((start_date BETWEEN "' . date('Y-m-d', strtotime($start_date)) . '" AND "' . date('Y-m-d', strtotime($end_date)) . '") || (end_date BETWEEN "' . date('Y-m-d', strtotime($start_date)) . '" AND "' . date('Y-m-d', strtotime($end_date)) . '"))');
            $this->db->where('parking_type',$format12);
            $count = $this->db->get('parking')->row_array();
            $temp['name'] = $format;
            $temp['count'] = $count['count'];
            $temp['price'] = $count['price'];
            $new_array[] = $temp;
        }

        $data['new_array'] = $new_array;
       
        $this->load->view(ADMIN_FOLDER . 'dashboard', $data);
    }

}
