<?php

class parking extends CI_Controller {

    function __construct() {
        parent::__construct();
        $this->admin_logged = $this->session->userdata('admin_logged_in');
        if (empty($this->admin_logged)) {
            redirect(ADMIN_FOLDER . 'login');
        }
    }

    function index() {
        $data = array();

        $state_arr = get_data_where('country_zones', array('country_id' => '223'));
        $data['state_arr'] = sort_select_data($state_arr, 'id', 'name');

        $format_arr = unserialize(DATE_FORMAT);
        $data['format_arr'] = $format_arr;

        if (!isset($_GET['format'])) {
            $format = 1;
        } else if($_GET['format'] <= '5'){
            $format = $_GET['format'];
        }else{
            $format = 1;
        }

        if ($format == 1) {
            $data['menu'] = 33;
        }

        if ($format == 2) {
            $data['menu'] = 35;
        }

        if ($format == 3) {
            $data['menu'] = 36;
        }

        if ($format == 4) {
            $data['menu'] = 37;
        }

        if ($format == 5) {
            $data['menu'] = 3;
        }

        if (isset($_GET['start_date']) && !empty($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = date('d M Y');
        }

        if (isset($_GET['end_date']) && !empty($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            $end_date = date('d M Y');
        }

        if (isset($_GET['number_plate']) && $_GET['number_plate'] != '') {
            $number_plate = $_GET['number_plate'];
        } else {
            $number_plate = '';
        }

        if (isset($_GET['name']) && $_GET['name'] != '') {
            $name = $_GET['name'];
        } else {
            $name = '';
        }

        if (isset($_GET['state_id']) && $_GET['state_id'] != '') {
            $state_id = $_GET['state_id'];
        } else {
            $state_id = '';
        }

        $data['start_date'] = $start_date;
        $data['end_date'] = $end_date;
        $data['number_plate'] = $number_plate;
        $data['name'] = $name;
        $data['format'] = $format;
        $data['state_id'] = $state_id;

        
        if (!empty($name)) {
            $this->db->like('name', $name);
        }

        if (!empty($number_plate)) {
            $this->db->like('number_plate', $number_plate);
        }

        if (!empty($state_id)) {
            $this->db->where('state_id', $state_id);
        }
        $this->db->select('p.*,pt.name as parking_type');
        $this->db->where('p.parking_type',$format);
        $this->db->join('parking_type as pt','pt.id = p.parking_type');
        $data['list'] = $this->db->get('parking as p')->result_array();
       
        $this->load->view(ADMIN_FOLDER . 'parking', $data);
    }
    

    function add() {
        $data = array();
        $data['menu'] = 2;
        $data['submenu'] = '';
        if (isset($_POST['submit'])) {

            $this->form_validation->set_rules('id', 'ID', 'trim');
            $this->form_validation->set_rules('number_plate', 'Number Plate', 'trim|required');
            $this->form_validation->set_rules('name', 'Person Name', 'trim|required');
            $this->form_validation->set_rules('type', 'Vehicle Type', 'trim|xss_clean|required');
            $this->form_validation->set_rules('model', 'Model Name', 'trim|xss_clean|required');
            $this->form_validation->set_rules('parking_type', 'Parking Type', 'trim|xss_clean|required');
            $this->form_validation->set_rules('price', 'Price', 'trim|xss_clean|required');
            $this->form_validation->set_rules('start_date', 'From Date', 'trim|xss_clean|required');
            $this->form_validation->set_rules('end_date', 'To Date', 'trim|xss_clean|required');
            $this->form_validation->set_rules('start_time', 'From Time', 'trim|xss_clean|required');
            $this->form_validation->set_rules('end_time', 'To Time', 'trim|xss_clean|required');
            $this->form_validation->set_rules('state_id', 'State', 'trim|xss_clean|required');

            if ($this->form_validation->run() == FALSE) {
                $this->load->view(ADMIN_FOLDER . 'parking_form', $data);
            } else {
                $insert = array('number_plate', 'name', 'type', 'model', 'parking_type', 'price', 'state_id');
                foreach ($insert as $val) {
                    $data1[$val] = $_POST[$val];
                }

                $data1['start_date'] = date('Y-m-d', strtotime($_POST['start_date']));
                $data1['end_date'] = date('Y-m-d', strtotime($_POST['end_date']));
                $data1['start_time'] = date('H:i', strtotime($_POST['start_time']));
                $data1['end_time'] = date('H:i', strtotime($_POST['end_time']));

                if (isset($_POST['id']) && !empty($_POST['id'])) {
                    update_data($data1, array('id' => $_POST['id']), 'parking');
                } else {
                    add_data($data1, 'parking');
                }
                $this->session->set_flashdata('msg', 'PARKING DETAILS SAVED !!!');
                redirect(ADMIN_FOLDER . 'parking', $data);
            }
        } else {
            $this->load->view(ADMIN_FOLDER . 'parking_form', $data);
        }
    }

    public function edit($edit) {
        $data = array();
        $data['menu'] = 3;
        $data['sub_menu'] = '';
        $id = custom_decrypt($edit);
        $where = array('id' => $id);
        $data['edit'] = get_data_where('parking', $where);
        $this->load->view(ADMIN_FOLDER . 'parking_form', $data);
    }

    public function delete($del) {
        $id = custom_decrypt($del);
        $where = array('id' => $id);
        delete_data_where('parking', $where);
        $this->session->set_flashdata('msg', 'DESIGNER DETAILS DELETED SUCCESSFULLY !!!');
        redirect(ADMIN_FOLDER . 'parking');
    }

    function calculate_price() {
        $vehicle_type_id = $_POST['vehicle_type_id'];
        $parking_type_id = $_POST['parking_type_id'];

        $status = '';
        $msg = '';
        $price = '';

        $check = $this->db
                        ->where('vehicle_type_id', $vehicle_type_id)
                        ->where('parking_type_id', $parking_type_id)
                        ->where('price != ', 0)
                        ->get('pricetable')->row_array();

        if (empty($check)) {
            $status = 0;
            $msg = 'No price updated';
        } else {
            $status = 1;

            if ($parking_type_id == 4) {
                $start_date = $_POST['start_date'];
                $end_date = $_POST['end_date'];
                $dates = fetch_dates($start_date, $end_date);
                $count = count($dates);
                $price = $count * $check['price'];
            } else {
                $price = $check['price'];
            }
        }

        $return['status'] = $status;
        $return['msg'] = $msg;
        $return['price'] = $price;
        echo json_encode($return);
    }

}
