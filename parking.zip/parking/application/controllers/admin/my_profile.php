<?php

class my_profile extends CI_Controller {

    function __construct() {
        parent::__construct();
        $user_s = $this->session->userdata('designer_logged_in');
        $this->user = $user_s;
        if (empty($user_s)) {
            redirect('designer/login');
        }
    }

    function index() {
        $data = array();
        $data['menu'] = 1;

        $data['edit'] = $this->user;
        
        $this->load->view('designer/my_profile', $data);
    }

    function form() {
        $data1 = array();
        $data['menu'] = 1;
      
//        $user_s = $this->session->userdata('logged_in');
        if (isset($_POST['submit'])) {
      
            $this->form_validation->set_rules('name', 'Name', 'trim|xss_clean|required');
            $this->form_validation->set_rules('email', 'Email', 'trim|xss_clean|required');
            $this->form_validation->set_rules('password', 'Password', 'trim|xss_clean|required');
            $this->form_validation->set_rules('gender', 'Gender', 'trim|xss_clean|required');
            $this->form_validation->set_rules('mobile', 'Mobile', 'trim|xss_clean|required');
            $this->form_validation->set_rules('address', 'Address', 'trim|xss_clean|required');
            $this->form_validation->set_rules('city', 'City', 'trim|xss_clean|required');
            $this->form_validation->set_rules('country', 'Country', 'trim|xss_clean|required');
            $this->form_validation->set_rules('state', 'State', 'trim|xss_clean|required');
            $this->form_validation->set_rules('city', 'City', 'trim|xss_clean|required');
            $this->form_validation->set_rules('pincode', 'Pincode', 'trim|xss_clean|required');
            $this->form_validation->set_rules('status', 'Status', 'trim|xss_clean|required');

            if ($this->form_validation->run() == FALSE) {

                $this->load->view('designer/my_profile', $data);
            } else {
                $insert = array('name', 'email', 'gender', 'mobile', 'address', 'country', 'state', 'city', 'pincode', 'status');
                foreach ($insert as $val) {
                    $data1[$val] = $_POST[$val];
                }
          
          
            
                  $data1['p'] = $_POST['password'];
                $data1['password'] = md5($_POST['password']);
  
                if (isset($_POST['id']) && !empty($_POST['id'])) {
                    $data1['update_date'] = date('Y-m-d h:i:s');

                    update_data($data1, array('id' => $_POST['id']), 'designer');
                    $this->session->set_flashdata('msg', 'DESIGNER DETAILS UPDATED SUCCESSFULLY !!!');
                } else {
                    $data1['add_date'] = date('Y-m-d h:i:s');

                    add_data($data1, 'designer');
                    $this->session->set_flashdata('msg', 'DESIGNER DETAILS ADDED SUCCESSFULLY !!!');
                }

                $admin = (array) $this->db->where('id', $this->user ['id'])->get('designer')->row();
                $this->session->set_userdata('designer_logged_in', $admin);
                redirect('designer/my_profile', $data);
            }
        } else {
            $this->load->view('designer/my_profile', $data);
        }
    }

    public function edit($edit) {
        $data = array();
        $data['menu'] = 1;
        $data['sub_menu'] = 9;
        $id = substr(base64_decode($edit), 6);
        $where = array('id' => $id);
        $data['edit'] = get_data_where('my_profile', $where);
        $this->load->view('designer/add_my_profile', $data);
    }

}
