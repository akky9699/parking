<?php

class login extends CI_Controller {

    function __construct() {
        parent::__construct();
    }

    function index() {
        $data = array();
        $data['active'] = 0;
        $admin_login = $this->session->userdata('admin_logged_in');
        if (!empty($admin_login)) {
            redirect(ADMIN_FOLDER . 'dashboard');
        } else {
            if (isset($_POST['email'])) {
                $this->form_validation->set_rules('email', 'Email', 'trim|required|xss_clean');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');
                if ($this->form_validation->run() == TRUE) {
                    $password = md5($_POST['password']);
                    $user = (array) $this->db
                                    ->where('email', $_POST['email'])
                                    ->where('password', $password)
                                    ->get('admin_login')->row();
                    if (!empty($user)) {
                        if ($user['active'] == 1) {
                            $this->session->set_userdata('admin_logged_in', $user);
                            redirect(ADMIN_FOLDER . 'dashboard');
                        } else {
                            $data['error'] = "User In-active";
                            $this->load->view(ADMIN_FOLDER . 'login', $data);
                        }
                    } else {
                        $data['error'] = "Invalid User ID OR Password";
                        $this->load->view(ADMIN_FOLDER . 'login', $data);
                    }
                } else {
                    $data['error'] = validation_errors();
                    $this->load->view(ADMIN_FOLDER . 'login', $data);
                }
            } else {
                $this->load->view(ADMIN_FOLDER . 'login', $data);
            }
        }
    }

    function logout() {
        $this->session->unset_userdata('admin_logged_in');
        redirect(ADMIN_FOLDER.'login');
    }

    function forgot() {
        $data = array();
        if (isset($_POST) && !empty($_POST)) {
            $this->form_validation->set_rules('email', 'email', 'trim|required|xss_clean');
            if ($this->form_validation->run() == TRUE) {
                $email = $_POST['email'];
                $user = (array) $this->db->select('*')
                                ->where('email', $email)
                                ->get('designer')->row();

                if (!empty($user)) {
                    $data2 = array();
                    $data2['mail_data'] = $user;
                    $msg = $this->load->view('mail_template/designer_forgotpassword', $data2, TRUE);
                    if (!empty($user['email'])) {
                        $to = trim($user['email']);
                        $sub = 'Designer Forgot Password | BOLOCO';
                        $bcc = getBccEmail();
                        email_send($to, '', $sub, $msg, FALSE, $bcc);
                    }

                    $this->session->set_flashdata('msg', 'Password sent to your email id..');
                    redirect('designer/login');
                } else {
                    $data['error'] = "Invalid Email ID !!";
                    $this->load->view('designer/login', $data);
                }
            } else {
                $data['error'] = validation_errors();
                $this->load->view('designer/login', $data);
            }
        } else {
            $this->load->view('designer/login', $data);
        }
    }

}
