<?php $this->load->view(ADMIN_FOLDER . 'include/header'); ?>
<?php
if (isset($edit) && !empty($edit)) {
    $id = $edit[0]['id'];
    $number_plate = $edit[0]['number_plate'];
    $name = $edit[0]['name'];
    $type = $edit[0]['type'];
    $model = $edit[0]['model'];
    $parking_type = $edit[0]['parking_type'];
    $price = $edit[0]['price'];
    $start_date = custom_date_format($edit[0]['start_date']);
    $end_date = custom_date_format($edit[0]['end_date']);
    $start_time = $edit[0]['start_time'];
    $end_time = $edit[0]['end_time'];
    $state_id = $edit[0]['state_id'];
} else {
    $id = set_value('id');
    $number_plate = set_value('number_plate');
    $name = set_value('name');
    $type = set_value('type');
    $model = set_value('model');
    $parking_type = set_value('parking_type');
    $price = set_value('price');
    $start_date = set_value('start_date');
    $end_date = set_value('end_date');
    $start_time = set_value('start_time');
    $end_time = set_value('end_time');
    $state_id = set_value('state_id');
}

if (empty($start_date)) {
    $start_date = custom_date_format(date('y-m-d'));
}

if (empty($end_date)) {
    $end_date = custom_date_format(date('y-m-d'));
}

$type_arr = getdata('vehicle_type');
$type_arr = sort_select_data1($type_arr, 'id', 'name');

$parking_type_arr = getdata('parking_type');
$parking_type_arr = sort_select_data1($parking_type_arr, 'id', 'name');

$state_arr = get_data_where('country_zones', array('country_id' => '223'));
$state_arr = sort_select_data1($state_arr, 'id', 'name');
?>

<div id="page_content">
    <div id="page_content_inner">

        <h3 class="heading_b uk-margin-bottom">PARKING DETAILS</h3>

        <div class="md-card">
            <div class="md-card-content large-padding">
                <form id="form_validation" method="post" enctype="multipart/form-data" action="<?php echo site_url(ADMIN_FOLDER . 'parking/add'); ?>" class="uk-form-stacked">

                    <div class="uk-grid" data-uk-grid-margin>
                        <input type="hidden" name="id" value='<?php echo $id; ?>' />

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">Number Plate<span class="req">*</span></label>
                                <input type="text" name="number_plate" value='<?php echo $number_plate; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('number_plate') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">Name<span class="req">*</span></label>
                                <input type="text" name="name" value='<?php echo $name; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('name') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">Vehicle Type<span class="req">*</span></label>
                                <?php echo form_dropdown('type', $type_arr, $type, 'id="type" required class="md-input calculate_price"') ?>
                                <span style="color:red"><?php echo form_error('type') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">Model Name<span class="req">*</span></label>
                                <input type="text" name="model" value='<?php echo $model; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('model') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">Parking Type<span class="req">*</span></label>                                
                                <?php echo form_dropdown('parking_type', $parking_type_arr, $parking_type, 'id="parking_type" required class="md-input calculate_price"') ?>
                                <span style="color:red"><?php echo form_error('parking_type') ?></span>
                            </div>
                        </div>
                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">State<span class="req">*</span></label>                                
                                <?php echo form_dropdown('state_id', $state_arr, $state_id, ' required class="md-input"') ?>
                                <span style="color:red"><?php echo form_error('state_id') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2 date_div">
                            <div class="parsley-row">
                                <label for="title">From Date<span class="req">*</span></label>                                
                                <input type="text" name="start_date" id="start_date" value='<?php echo $start_date; ?>' required class="md-input" data-uk-datepicker="{format:'DD MMMM YYYY'}"/>
                                <span style="color:red"><?php echo form_error('start_date') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2 date_div">
                            <div class="parsley-row">
                                <label for="title">To Date<span class="req">*</span></label>                                
                                <input type="text" name="end_date" id="end_date" value='<?php echo $end_date; ?>' required class="md-input" data-uk-datepicker="{format:'DD MMM YYYY'}" />
                                <span style="color:red"><?php echo form_error('end_date') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-1">
                            <div class="parsley-row">
                                <label for="title">Price<span class="req">*</span></label>                                
                                <input type="text" onkeypress="return false" name="price" value='<?php echo $price; ?>' id="price" readonly required class="md-input" />
                                <span style="color:red"><?php echo form_error('end_date') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">In Time<span class="req">*</span></label>                                
                                <input type="text" name="start_time" value='<?php echo $start_time; ?>' required class="md-input" data-uk-timepicker />
                                <span style="color:red"><?php echo form_error('start_time') ?></span>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-2">
                            <div class="parsley-row">
                                <label for="title">Out Time<span class="req">*</span></label>                                
                                <input type="text" name="end_time" value='<?php echo $end_time; ?>' required class="md-input" data-uk-timepicker />
                                <span style="color:red"><?php echo form_error('end_time') ?></span>
                            </div>
                        </div>

                        <div class="uk-grid">
                            <div class="uk-width-medium-1-1" style="text-align: center;">
                                <button type="submit" name='submit' class="md-btn md-btn-primary">Submit</button>
                                <br>
                                <br>
                            </div>
                        </div>
                </form>
            </div>
        </div>

    </div>
</div>

<script>
    $(document).ready(function () {
        $('.calculate_price').change(function () {

            var vt = $('#type').val();
            var pt = $('#parking_type').val();

            if (pt == 1) {
                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                $('#end_date').attr('value', '<?php echo date('d M Y') ?>');
            } else if (pt == 2) {
                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                $('#end_date').attr('value', '<?php echo date('d M Y', strtotime('+ 1 month')) ?>');
            } else if (pt == 3) {
                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                $('#end_date').attr('value', '<?php echo date('d M Y', strtotime('+ 1 month')) ?>');
            } else if (pt == 4) {
//                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
//                $('#end_date').attr('value', '<?php echo date('d M Y') ?>');
            }



            var st = $('#start_date').val();
            var et = $('#end_date').val();
            var postdata = {'vehicle_type_id': vt, 'parking_type_id': pt, 'start_date': st, 'end_date': et};

            if (pt == 4) {
                $('.date_div').show();
            } else {
                $('.date_div').hide();
            }

            $.post('<?php echo site_url(ADMIN_FOLDER . 'parking/calculate_price') ?>', postdata, function (res) {
                $('#price').val(res['price']);
            }, 'json');

        });
        $('#parking_type').change();

        $('#start_date, #end_date').change(function () {
            $('#parking_type').change();
        });


    });
</script>

<?php $this->load->view(ADMIN_FOLDER . 'include/footer'); ?>