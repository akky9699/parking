<?php $this->load->view(ADMIN_FOLDER . 'include/header'); ?>
<div id="page_content">
    <div id="page_content_inner">

        <div class="md-card">
            <div class="md-card-toolbar">               
                <h3 class="md-card-toolbar-heading-text">Parking List</h3>
            </div>

        </div>

        <?php
        if ($this->session->flashdata('msg') != "") {
            ?>
            <div class="uk-alert uk-alert-success" data-uk-alert>
                <a href="#" class="uk-alert-close uk-close"></a>
                <?php echo $this->session->flashdata('msg') ?>               
            </div>                    
        <?php } ?>
        <div class="md-card uk-margin-medium-bottom">
            <div class="md-card-content">
                <script>
                    $(document).ready(function () {
                        $('#format').change(function () {

                            var format = document.getElementById('format').value;

                            if (format == 5) {
                                $('.date_field').show();
                            } else {
                                $('.date_field').hide();
                            }

                            if (format == 1) {
                                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                                $('#end_date').attr('value', '<?php echo date('d M Y') ?>');
                            } else if (format == 2) {
                                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                                $('#end_date').attr('value', '<?php echo date('d M Y', strtotime('+ 1 week')) ?>');
                            } else if (format == 3) {
                                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                                $('#end_date').attr('value', '<?php echo date('d M Y', strtotime('+ 1 month')) ?>');
                            } else if (format == 4) {
                                $('#start_date').attr('value', '<?php echo date('d M Y') ?>');
                                $('#end_date').attr('value', '<?php echo date('d M Y', strtotime('+ 1 year')) ?>');
                            }
                        }
                        );
                        $('#format').trigger('change');

                    });</script>

                <form id="form_validation" method="get" action="<?php echo site_url(ADMIN_FOLDER . 'parking'); ?>" class="uk-form-stacked" novalidate="">
                    <div class="uk-grid" data-uk-grid-margin="">

                        <div class="uk-width-medium-1-6 uk-row-first">
                            <div class="parsley-row">
                                <?php echo form_dropdown('format', $format_arr, $format, 'id ="format" class="md-input"'); ?>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-6 date_field">
                            <div class="parsley-row">
                                <input type="text" name="start_date" id="start_date" value='<?php echo $start_date; ?>' required class="md-input" data-uk-datepicker="{format:'DD MMMM YYYY'}" placeholder="From Date">
                            </div>
                        </div>

                        <div class="uk-width-medium-1-6 date_field">
                            <div class="parsley-row">
                                <input type="text" name="end_date" id="end_date" value='<?php echo $end_date; ?>' required class="md-input" data-uk-datepicker="{format:'DD MMM YYYY'}" placeholder="To Date">
                            </div>
                        </div>

                        <div class="uk-width-medium-1-6">
                            <div class="parsley-row">
                                <?php echo form_dropdown('state_id', $state_arr, $state_id, 'class="md-input"') ?>
                            </div>
                        </div>

                        <div class="uk-width-medium-1-6">
                            <div class="parsley-row">
                                <input type="text" name="number_plate" value='<?php echo $number_plate; ?>' class="md-input" placeholder="Number Plate">
                            </div>
                        </div>

                        <div class="uk-width-medium-1-6">
                            <div class="parsley-row">
                                <input type="text" name="name" value='<?php echo $name; ?>' class="md-input" placeholder="Person Name" />
                            </div>
                        </div>

                        <div class="uk-width-medium-1-6">
                            <div class="parsley-row">                                
                                <button type="submit" name="submit" class="md-btn md-btn-primary">Search</button>                                
                            </div>
                        </div>

                    </div>
                </form>
                <hr>
                <div class="uk-overflow-container">                    
                    <table class="uk-table uk-table-nowrap">
                        <thead>
                            <tr>
                                <th class="uk-width-1-10 uk-text-center">Sr. No.</th>                               
                                <th class="uk-width-2-10 uk-text-center">Number Plate</th>
                                <th class="uk-width-2-10 uk-text-center">Person Name</th>
                                <th class="uk-width-2-10 uk-text-center">Model</th> 
                                <th class="uk-width-2-10 uk-text-center">Type</th> 
                                <th class="uk-width-2-10 uk-text-center">Period</th> 
                                <th class="uk-width-2-10 uk-text-center">Price</th> 
                                <th class="uk-width-2-10 uk-text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $total = 0;
                            if (isset($list) && !empty($list)) {
                                
                                $i = 1;
                                foreach ($list as $val) {
                                    ?>
                                    <tr>
                                        <td class="uk-text-center"> <?php echo $i; ?> </td>
                                        <td class="uk-text-center"> <?php echo $val['number_plate']; ?> </td>
                                        <td class="uk-text-center"> <?php echo $val['name']; ?> </td>
                                        <td class="uk-text-center"> <?php echo $val['model']; ?> </td>
                                        <td class="uk-text-center"> <?php echo $val['parking_type']; ?> </td>
                                        <td class="uk-text-center"> 
                                            <?php echo "Start: ".custom_date_format($val['start_date']) .' '. $val['start_time'].'<br>End: ' . custom_date_format($val['end_date']).' '. $val['end_time']; ?> 
                                        </td>
                                        <td class="uk-text-center"> 
                                            <?php
                                            echo $val['price'];
                                            $total +=$val['price']
                                            ?> 
                                        </td>
                                        <td class="uk-text-center">
                                            <a title='edit' href="<?php echo site_url(ADMIN_FOLDER . 'parking/edit/' . custom_encypt($val['id'])); ?>"><i class="md-icon material-icons">&#xE254;</i></a>
                                            <a title='delete' style="padding: 5px 12px;font-size: 23px;" onclick='return confirm("Are You Sure You Want To Delete The parking details?")' href="<?php echo site_url(ADMIN_FOLDER . 'parking/delete/' . custom_encypt($val['id'])); ?>" class='ts_remove_row'><img  src="<?php echo ADMIN_THEME; ?>/images/delete (1).png" class='trash' alt=""/></a>
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                }
                            }
                            ?>
                                    <tr>
                                        <td colspan="6" style="text-align: right;"><b>Total :</b></td>
                                        <td style="text-align: center;"><b><?php echo $total;?></b></td>
                                        <td></td>
                                    </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view(ADMIN_FOLDER . 'include/footer'); ?>