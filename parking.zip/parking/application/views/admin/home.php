<?php $this->load->view('super/include/header'); ?>
<div id="page_content">
    <div id="page_content_inner">

        <?php
        if ($this->session->flashdata('msg') != "") {
            ?>
            <div class="uk-alert uk-alert-success" data-uk-alert>
                <a href="#" class="uk-alert-close uk-close"></a>
                <?php echo $this->session->flashdata('msg') ?>               
            </div>                    
        <?php } ?>
        <div class="md-card uk-margin-medium-bottom">
            <div class="md-card-content">

                <?php
                if (isset($list) && !empty($list)) {
                    ?>
                    <div class="uk-overflow-container">
                        <caption>Banner Text 1 </caption>
                        <a style='float: right' href="<?php echo site_url('super/home/edit/' . base64_encode('akshay' . $list[0]['id'])); ?>"><i class="md-icon material-icons">&#xE254;</i></a>
                        <table class="uk-table">                        
                            <tr>
                                <th>Title</th>                           
                            </tr>                    
                            <tr>
                                <td><?php echo $list[0]['section1'] ?></td>  
                            </tr>  
                            <tr>
                                <th>Description</th>                           
                            </tr>                    
                            <tr>
                                <td><?php echo $list[0]['section2'] ?></td>   
                            </tr>
                        </table>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
        <!--        <div class="md-card uk-margin-medium-bottom">
                    <div class="md-card-content">
        <?php
        // if (isset($list) && !empty($list)) {
        ?>
                            <div class="uk-overflow-container">
                                <caption>Banner Text 2 </caption>
                                <a style='float: right' href="<?php // echo site_url('super/home/edit/' . base64_encode('akshay' . $list[1]['id']));        ?>"><i class="md-icon material-icons">&#xE254;</i></a>
                                <table class="uk-table">                        
                                    <tr>
                                        <th>Title</th>                           
                                    </tr>                    
                                    <tr>
                                        <td><?php // echo $list[1]['section1']        ?></td>  
                                    </tr>  
                                    <tr>
                                        <th>Start Project Link</th>                           
                                    </tr>                    
                                    <tr>
                                        <td><?php //echo $list[1]['section2']        ?></td>   
                                    </tr>
                                </table>
                            </div>
        <?php
        //}
        ?>
                    </div>
                </div>-->
    </div>
</div>
<?php $this->load->view('super/include/footer'); ?>


