<script src="<?php echo ADMIN_THEME; ?>assets/js/uikit_custom.min.js"></script>
        <script src="<?php echo ADMIN_THEME; ?>assets/js/altair_admin_common.min.js"></script>
        <script src="<?php echo ADMIN_THEME; ?>assets/js/pages/login.min.js"></script>
    </body>
</html>