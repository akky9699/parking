<!-- secondary sidebar -->
<aside id="sidebar_secondary" class="tabbed_sidebar">
    <ul class="uk-tab uk-tab-icons uk-tab-grid" data-uk-tab="{connect:'#dashboard_sidebar_tabs', animation:'slide-horizontal'}">
        <li class="uk-active uk-width-1-3"><a href="#"><i class="material-icons">&#xE422;</i></a></li>
        <li class="uk-width-1-3 chat_sidebar_tab"><a href="#"><i class="material-icons">&#xE0B7;</i></a></li>
        <li class="uk-width-1-3"><a href="#"><i class="material-icons">&#xE8B9;</i></a></li>
    </ul>

    <div class="scrollbar-inner">
        <ul id="dashboard_sidebar_tabs" class="uk-switcher">
            <li>
                <div class="timeline timeline_small uk-margin-bottom">
                    <div class="timeline_item">
                        <div class="timeline_icon timeline_icon_success"><i class="material-icons">&#xE85D;</i></div>
                        <div class="timeline_date">
                            09<span>Feb</span>
                        </div>
                        <div class="timeline_content">Created ticket <a href="#"><strong>#3289</strong></a></div>
                    </div>
                    <div class="timeline_item">
                        <div class="timeline_icon timeline_icon_danger"><i class="material-icons">&#xE5CD;</i></div>
                        <div class="timeline_date">
                            15<span>Feb</span>
                        </div>
                        <div class="timeline_content">Deleted post <a href="#"><strong>Aperiam nobis ut ut dolorum praesentium autem aut.</strong></a></div>
                    </div>
                    <div class="timeline_item">
                        <div class="timeline_icon"><i class="material-icons">&#xE410;</i></div>
                        <div class="timeline_date">
                            19<span>Feb</span>
                        </div>
                        <div class="timeline_content">
                            Added photo
                            <div class="timeline_content_addon">
                                <img src="<?php echo ADMIN_THEME; ?>assets/img/gallery/Image16.jpg" alt=""/>
                            </div>
                        </div>
                    </div>
                    <div class="timeline_item">
                        <div class="timeline_icon timeline_icon_primary"><i class="material-icons">&#xE0B9;</i></div>
                        <div class="timeline_date">
                            21<span>Feb</span>
                        </div>
                        <div class="timeline_content">
                            New comment on post <a href="#"><strong>Voluptas quod pariatur.</strong></a>
                            <div class="timeline_content_addon">
                                <blockquote>
                                    Asperiores qui praesentium magnam libero saepe possimus perferendis est autem.&hellip;
                                </blockquote>
                            </div>
                        </div>
                    </div>
                    <div class="timeline_item">
                        <div class="timeline_icon timeline_icon_warning"><i class="material-icons">&#xE7FE;</i></div>
                        <div class="timeline_date">
                            29<span>Feb</span>
                        </div>
                        <div class="timeline_content">
                            Added to Friends
                            <div class="timeline_content_addon">
                                <ul class="md-list md-list-addon">
                                    <li>
                                        <div class="md-list-addon-element">
                                            <img class="md-user-image md-list-addon-avatar" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_02_tn.png" alt=""/>
                                        </div>
                                        <div class="md-list-content">
                                            <span class="md-list-heading">Janessa Kassulke</span>
                                            <span class="uk-text-small uk-text-muted">Beatae blanditiis aut totam.</span>
                                        </div>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <ul class="md-list md-list-addon chat_users">
                    <li>
                        <div class="md-list-addon-element">
                            <span class="element-status element-status-success"></span>
                            <img class="md-user-image md-list-addon-avatar" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_02_tn.png" alt=""/>
                        </div>
                        <div class="md-list-content">
                            <div class="md-list-action-placeholder"></div>
                            <span class="md-list-heading">Mariela Mann</span>
                            <span class="uk-text-small uk-text-muted uk-text-truncate">Minus voluptatem.</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-addon-element">
                            <span class="element-status element-status-success"></span>
                            <img class="md-user-image md-list-addon-avatar" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_09_tn.png" alt=""/>
                        </div>
                        <div class="md-list-content">
                            <div class="md-list-action-placeholder"></div>
                            <span class="md-list-heading">Beverly Goodwin</span>
                            <span class="uk-text-small uk-text-muted uk-text-truncate">Perferendis aut iste.</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-addon-element">
                            <span class="element-status element-status-danger"></span>
                            <img class="md-user-image md-list-addon-avatar" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_04_tn.png" alt=""/>
                        </div>
                        <div class="md-list-content">
                            <div class="md-list-action-placeholder"></div>
                            <span class="md-list-heading">Kaela Reichel</span>
                            <span class="uk-text-small uk-text-muted uk-text-truncate">Quasi ut voluptatem.</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-addon-element">
                            <span class="element-status element-status-warning"></span>
                            <img class="md-user-image md-list-addon-avatar" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_07_tn.png" alt=""/>
                        </div>
                        <div class="md-list-content">
                            <div class="md-list-action-placeholder"></div>
                            <span class="md-list-heading">Krystal Harvey</span>
                            <span class="uk-text-small uk-text-muted uk-text-truncate">Praesentium eos.</span>
                        </div>
                    </li>
                </ul>
                <div class="chat_box_wrapper chat_box_small" id="chat">
                    <div class="chat_box chat_box_colors_a">
                        <div class="chat_message_wrapper">
                            <div class="chat_user_avatar">
                                <img class="md-user-image" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_11_tn.png" alt=""/>
                            </div>
                            <ul class="chat_message">
                                <li>
                                    <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio, eum? </p>
                                </li>
                                <li>
                                    <p> Lorem ipsum dolor sit amet.<span class="chat_message_time">13:38</span> </p>
                                </li>
                            </ul>
                        </div>
                        <div class="chat_message_wrapper chat_message_right">
                            <div class="chat_user_avatar">
                                <img class="md-user-image" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_03_tn.png" alt=""/>
                            </div>
                            <ul class="chat_message">
                                <li>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Autem delectus distinctio dolor earum est hic id impedit ipsum minima mollitia natus nulla perspiciatis quae quasi, quis recusandae, saepe, sunt totam.
                                        <span class="chat_message_time">13:34</span>
                                    </p>
                                </li>
                            </ul>
                        </div>
                        <div class="chat_message_wrapper">
                            <div class="chat_user_avatar">
                                <img class="md-user-image" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_11_tn.png" alt=""/>
                            </div>
                            <ul class="chat_message">
                                <li>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit. Atque ea mollitia pariatur porro quae sed sequi sint tenetur ut veritatis.
                                        <span class="chat_message_time">23 Jun 1:10am</span>
                                    </p>
                                </li>
                            </ul>
                        </div>
                        <div class="chat_message_wrapper chat_message_right">
                            <div class="chat_user_avatar">
                                <img class="md-user-image" src="<?php echo ADMIN_THEME; ?>assets/img/avatars/avatar_03_tn.png" alt=""/>
                            </div>
                            <ul class="chat_message">
                                <li>
                                    <p> Lorem ipsum dolor sit amet, consectetur. </p>
                                </li>
                                <li>
                                    <p>
                                        Lorem ipsum dolor sit amet, consectetur adipisicing elit.
                                        <span class="chat_message_time">Friday 13:34</span>
                                    </p>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </li>
            <li>
                <h4 class="heading_c uk-margin-small-bottom uk-margin-top">General Settings</h4>
                <ul class="md-list">
                    <li>
                        <div class="md-list-content">
                            <div class="uk-float-right">
                                <input type="checkbox" data-switchery data-switchery-size="small" checked id="settings_site_online" name="settings_site_online" />
                            </div>
                            <span class="md-list-heading">Site Online</span>
                            <span class="uk-text-muted uk-text-small">Lorem ipsum dolor sit amet&hellip;</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-content">
                            <div class="uk-float-right">
                                <input type="checkbox" data-switchery data-switchery-size="small" id="settings_seo" name="settings_seo" />
                            </div>
                            <span class="md-list-heading">Search Engine Friendly URLs</span>
                            <span class="uk-text-muted uk-text-small">Lorem ipsum dolor sit amet&hellip;</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-content">
                            <div class="uk-float-right">
                                <input type="checkbox" data-switchery data-switchery-size="small" id="settings_url_rewrite" name="settings_url_rewrite" />
                            </div>
                            <span class="md-list-heading">Use URL rewriting</span>
                            <span class="uk-text-muted uk-text-small">Lorem ipsum dolor sit amet&hellip;</span>
                        </div>
                    </li>
                </ul>
                <hr class="md-hr">
                <h4 class="heading_c uk-margin-small-bottom uk-margin-top">Other Settings</h4>
                <ul class="md-list">
                    <li>
                        <div class="md-list-content">
                            <div class="uk-float-right">
                                <input type="checkbox" data-switchery data-switchery-size="small" data-switchery-color="#7cb342" checked id="settings_top_bar" name="settings_top_bar" />
                            </div>
                            <span class="md-list-heading">Top Bar Enabled</span>
                            <span class="uk-text-muted uk-text-small">Lorem ipsum dolor sit amet&hellip;</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-content">
                            <div class="uk-float-right">
                                <input type="checkbox" data-switchery data-switchery-size="small" data-switchery-color="#7cb342" id="settings_api" name="settings_api" />
                            </div>
                            <span class="md-list-heading">Api Enabled</span>
                            <span class="uk-text-muted uk-text-small">Lorem ipsum dolor sit amet&hellip;</span>
                        </div>
                    </li>
                    <li>
                        <div class="md-list-content">
                            <div class="uk-float-right">
                                <input type="checkbox" data-switchery data-switchery-size="small" data-switchery-color="#d32f2f" id="settings_minify_static" checked name="settings_minify_static" />
                            </div>
                            <span class="md-list-heading">Minify JS files automatically</span>
                            <span class="uk-text-muted uk-text-small">Lorem ipsum dolor sit amet&hellip;</span>
                        </div>
                    </li>
                </ul>
            </li>
        </ul>
    </div>

    <button type="button" class="chat_sidebar_close uk-close"></button>
    <div class="chat_submit_box">
        <div class="uk-input-group">
            <input type="text" class="md-input" name="submit_message" id="submit_message" placeholder="Send message">
            <span class="uk-input-group-addon">
                <a href="#"><i class="material-icons md-24">&#xE163;</i></a>
            </span>
        </div>
    </div>

</aside><!-- secondary sidebar end -->

<!-- google web fonts -->
<script>
    WebFontConfig = {
        google: {
            families: [
                'Source+Code+Pro:400,700:latin',
                'Roboto:400,300,500,700,400italic:latin'
            ]
        }
    };
    (function () {
        var wf = document.createElement('script');
        wf.src = ('https:' == document.location.protocol ? 'https' : 'http') +
                '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
        wf.type = 'text/javascript';
        wf.async = 'true';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(wf, s);
    })();
</script>

<!-- common functions -->
<script src="<?php echo ADMIN_THEME; ?>assets/js/common.min.js"></script>
<!-- uikit functions -->
<script src="<?php echo ADMIN_THEME; ?>assets/js/uikit_custom.min.js"></script>
<!-- altair common functions/helpers -->
<script src="<?php echo ADMIN_THEME; ?>assets/js/altair_admin_common.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/components_preloaders.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/forms_file_upload.min.js"></script>
<!-- page specific plugins -->
<!-- d3 -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/d3/d3.min.js"></script>
<!-- metrics graphics (charts) -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/metrics-graphics/dist/metricsgraphics.min.js"></script>
<!-- chartist (charts) -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/chartist/dist/chartist.min.js"></script>
<!-- maplace (google maps) -->
<script src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script src="<?php echo ADMIN_THEME; ?>bower_components/maplace-js/dist/maplace.min.js"></script>
<!-- peity (small charts) -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/peity/jquery.peity.min.js"></script>
<!-- easy-pie-chart (circular statistics) -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/jquery.easy-pie-chart/dist/jquery.easypiechart.min.js"></script>
<!-- countUp -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/countUp.js/countUp.min.js"></script>
<!-- handlebars.js -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/handlebars/handlebars.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/custom/handlebars_helpers.min.js"></script>
<!-- CLNDR -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/clndr/src/clndr.js"></script>
<!-- fitvids -->
<script src="<?php echo ADMIN_THEME; ?>bower_components/fitvids/jquery.fitvids.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/kendoui_custom.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/kendoui.min.js"></script>
<!--  dashbord functions -->
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/dashboard.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/page_help.min.js"></script>
<script>
    $(function () {
        // enable hires images
        altair_helpers.retina_images();
        // fastClick (touch devices)
        if (Modernizr.touch) {
            FastClick.attach(document.body);
        }
    });
</script>

<script>
    (function (i, s, o, g, r, a, m) {
        i['GoogleAnalyticsObject'] = r;
        i[r] = i[r] || function () {
            (i[r].q = i[r].q || []).push(arguments)
        }, i[r].l = 1 * new Date();
        a = s.createElement(o),
                m = s.getElementsByTagName(o)[0];
        a.async = 1;
        a.src = g;
        m.parentNode.insertBefore(a, m)
    })(window, document, 'script', '../www.google-analytics.com/analytics.js', 'ga');
    ga('create', 'UA-65191727-1', 'auto');
    ga('send', 'pageview');
</script>

<!--  <div id="style_switcher">
     <div id="style_switcher_toggle"><i class="material-icons">&#xE8B8;</i></div>
     <div class="uk-margin-medium-bottom">
         <h4 class="heading_c uk-margin-bottom">Colors</h4>
         <ul class="switcher_app_themes" id="theme_switcher">
             <li class="app_style_default active_theme" data-app-theme="">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_a" data-app-theme="app_theme_a">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_b" data-app-theme="app_theme_b">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_c" data-app-theme="app_theme_c">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_d" data-app-theme="app_theme_d">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_e" data-app-theme="app_theme_e">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_f" data-app-theme="app_theme_f">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_g" data-app-theme="app_theme_g">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_h" data-app-theme="app_theme_h">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
             <li class="switcher_theme_i" data-app-theme="app_theme_i">
                 <span class="app_color_main"></span>
                 <span class="app_color_accent"></span>
             </li>
         </ul>
     </div>
     <div class="uk-visible-large uk-margin-medium-bottom">
         <h4 class="heading_c">Sidebar</h4>
         <p>
             <input type="checkbox" name="style_sidebar_mini" id="style_sidebar_mini" data-md-icheck />
             <label for="style_sidebar_mini" class="inline-label">Mini Sidebar</label>
         </p>
     </div>
     <div class="uk-visible-large uk-margin-medium-bottom">
         <h4 class="heading_c">Layout</h4>
         <p>
             <input type="checkbox" name="style_layout_boxed" id="style_layout_boxed" data-md-icheck />
             <label for="style_layout_boxed" class="inline-label">Boxed layout</label>
         </p>
     </div>
     <div class="uk-visible-large">
         <h4 class="heading_c">Main menu accordion</h4>
         <p>
             <input type="checkbox" name="accordion_mode_main_menu" id="accordion_mode_main_menu" data-md-icheck />
             <label for="accordion_mode_main_menu" class="inline-label">Accordion mode</label>
         </p>
     </div>
 </div> -->
<script>
// load parsley config (altair_admin_common.js)
    altair_forms.parsley_validation_config();
</script>
<script src="<?php echo ADMIN_THEME; ?>bower_components/parsleyjs/dist/parsley.min.js"></script>

<!--  forms validation functions -->
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/forms_validation.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/kendoui_custom.min.js"></script>
<script src="<?php echo ADMIN_THEME; ?>assets/js/pages/kendoui.min.js"></script>
<script>
    $(function () {
        var $switcher = $('#style_switcher'),
                $switcher_toggle = $('#style_switcher_toggle'),
                $theme_switcher = $('#theme_switcher'),
                $mini_sidebar_toggle = $('#style_sidebar_mini'),
                $boxed_layout_toggle = $('#style_layout_boxed'),
                $accordion_mode_toggle = $('#accordion_mode_main_menu'),
                $body = $('body');


        $switcher_toggle.click(function (e) {
            e.preventDefault();
            $switcher.toggleClass('switcher_active');
        });

        $theme_switcher.children('li').click(function (e) {
            e.preventDefault();
            var $this = $(this),
                    this_theme = $this.attr('data-app-theme');

            $theme_switcher.children('li').removeClass('active_theme');
            $(this).addClass('active_theme');
            $body
                    .removeClass('app_theme_a app_theme_b app_theme_c app_theme_d app_theme_e app_theme_f app_theme_g app_theme_h app_theme_i')
                    .addClass(this_theme);

            if (this_theme == '') {
                localStorage.removeItem('altair_theme');
            } else {
                localStorage.setItem("altair_theme", this_theme);
            }

        });

        // hide style switcher
        $document.on('click keyup', function (e) {
            if ($switcher.hasClass('switcher_active')) {
                if (
                        (!$(e.target).closest($switcher).length)
                        || (e.keyCode == 27)
                        ) {
                    $switcher.removeClass('switcher_active');
                }
            }
        });

        // get theme from local storage
        if (localStorage.getItem("altair_theme") !== null) {
            $theme_switcher.children('li[data-app-theme=' + localStorage.getItem("altair_theme") + ']').click();
        }


        // toggle mini sidebar

        // change input's state to checked if mini sidebar is active
        if ((localStorage.getItem("altair_sidebar_mini") !== null && localStorage.getItem("altair_sidebar_mini") == '1') || $body.hasClass('sidebar_mini')) {
            $mini_sidebar_toggle.iCheck('check');
        }

        $mini_sidebar_toggle
                .on('ifChecked', function (event) {
                    $switcher.removeClass('switcher_active');
                    localStorage.setItem("altair_sidebar_mini", '1');
                    location.reload(true);
                })
                .on('ifUnchecked', function (event) {
                    $switcher.removeClass('switcher_active');
                    localStorage.removeItem('altair_sidebar_mini');
                    location.reload(true);
                });


        // toggle boxed layout

        if ((localStorage.getItem("altair_layout") !== null && localStorage.getItem("altair_layout") == 'boxed') || $body.hasClass('boxed_layout')) {
            $boxed_layout_toggle.iCheck('check');
            $body.addClass('boxed_layout');
            $(window).resize();
        }

        $boxed_layout_toggle
                .on('ifChecked', function (event) {
                    $switcher.removeClass('switcher_active');
                    localStorage.setItem("altair_layout", 'boxed');
                    location.reload(true);
                })
                .on('ifUnchecked', function (event) {
                    $switcher.removeClass('switcher_active');
                    localStorage.removeItem('altair_layout');
                    location.reload(true);
                });

        // main menu accordion mode
        if ($sidebar_main.hasClass('accordion_mode')) {
            $accordion_mode_toggle.iCheck('check');
        }

        $accordion_mode_toggle
                .on('ifChecked', function () {
                    $sidebar_main.addClass('accordion_mode');
                })
                .on('ifUnchecked', function () {
                    $sidebar_main.removeClass('accordion_mode');
                });


    });
</script>
</body>

</html>