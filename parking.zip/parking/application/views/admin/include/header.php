<!doctype html>
<!--[if lte IE 9]> <html class="lte-ie9" lang="en"> <![endif]-->
<!--[if gt IE 9]><!--> <html lang="en"> <!--<![endif]-->
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <!-- Remove Tap Highlight on Windows Phone IE -->
        <meta name="msapplication-tap-highlight" content="no"/>

        <link rel="icon" type="image/png" href="<?php echo ADMIN_THEME; ?>assets/img/favicon-16x16.png" sizes="16x16">
        <link rel="icon" type="image/png" href="<?php echo ADMIN_THEME; ?>assets/img/favicon-32x32.png" sizes="32x32">

        <title>Denton and Denton Parking Garage | Panel</title>
        <!-- additional styles for plugins -->
        <!-- weather icons -->
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>bower_components/weather-icons/css/weather-icons.min.css" media="all">
        <!-- metrics graphics (charts) -->
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>bower_components/metrics-graphics/dist/metricsgraphics.css">
        <!-- chartist -->
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>bower_components/chartist/dist/chartist.min.css">

        <!-- uikit -->
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>bower_components/uikit/css/uikit.almost-flat.min.css" media="all">
        <!-- flag icons -->
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>assets/icons/flags/flags.min.css" media="all">
        <!-- altair admin -->
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>assets/css/main.min.css" media="all">
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>bower_components/kendo-ui/styles/kendo.common-material.min.css"/>
        <link rel="stylesheet" href="<?php echo ADMIN_THEME; ?>bower_components/kendo-ui/styles/kendo.material.min.css"/>
        <!-- matchMedia polyfill for testing media queries in JS -->
        <!--[if lte IE 9]>
            <script type="text/javascript" src="bower_components/matchMedia/matchMedia.js"></script>
            <script type="text/javascript" src="bower_components/matchMedia/matchMedia.addListener.js"></script>
        <![endif]-->


        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.0/jquery.min.js"></script>
        <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
        <script src="<?php echo ADMIN_THEME; ?>assets/js/form_validation.js"></script>
    </head>
    <body class=" sidebar_main_open sidebar_main_swipe app_theme_i">
        <!-- main header -->
        <header id="header_main">
            <div class="header_main_content">
                <nav class="uk-navbar">

                    <!-- main sidebar switch -->
                    <a href="javascript:;" id="sidebar_main_toggle" class="sSwitch sSwitch_left">
                        <span class="sSwitchIcon"></span>
                    </a>

                    <!-- secondary sidebar switch -->
                    <!--                    <a href="javascript:;" id="sidebar_secondary_toggle" class="sSwitch sSwitch_right sidebar_secondary_check">
                                            <span class="sSwitchIcon"></span>
                                        </a>-->

                    <div class="uk-navbar-flip">
                        <ul class="uk-navbar-nav user_actions">
<!--                            <li><a href="javascript:;" id="full_screen_toggle" class="user_action_icon uk-visible-large"><i class="material-icons md-24 md-light">&#xE5D0;</i></a></li>
                            <li><a href="javascript:;" id="main_search_btn" class="user_action_icon"><i class="material-icons md-24 md-light">&#xE8B6;</i></a></li>-->

                            <li data-uk-dropdown="{mode:'click',pos:'bottom-right'}">
                                <a href="javascript:;" class="user_action_image"><img class="md-user-image" src="<?php echo ADMIN_THEME; ?>images/886509.gif" alt=""/></a>
                                <div class="uk-dropdown uk-dropdown-small">
                                    <ul class="uk-nav js-uk-prevent">
                                        <!--<li><a href="<?php echo site_url(ADMIN_FOLDER . 'my_profile') ?>">My profile</a></li>-->
                                        <!--<li><a href="">Settings</a></li>-->
                                        <li><a href="<?php echo site_url(ADMIN_FOLDER . 'login/logout'); ?>">Logout</a></li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                </nav>
            </div>
            <div class="header_main_search_form">
                <i class="md-icon header_main_search_close material-icons">&#xE5CD;</i>
                <form class="uk-form">
                    <input type="text" class="header_main_search_input" />
                    <button class="header_main_search_btn uk-button-link"><i class="md-icon material-icons">&#xE8B6;</i></button>
                </form>
            </div>
        </header><!-- main header end -->
        <!-- main sidebar -->
        <aside id="sidebar_main">

            <div class="sidebar_main_header">
                <div class="sidebar_logo">
                    <a href="<?php echo site_url(ADMIN_FOLDER . 'dashboard') ?>" class="sSidebar_hide">
                        <img src="<?php echo UPLOAD_PATH; ?>logo.png" class="img-responsive" />
                    </a>
                    <a href="<?php echo site_url(ADMIN_FOLDER . 'dashboard') ?>" class="sSidebar_show">
                        <img src="<?php echo UPLOAD_PATH; ?>logo.png" class="img-responsive" />
                    </a>
                </div>

            </div>

            <div class="menu_section">
                <ul>
                    <li <?php echo(isset($menu) && ($menu == '1')) ? 'class="current_section"' : '' ?> title="Dashboard">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'dashboard'); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Dashboard</span>
                        </a>
                    </li>                    
                    <li <?php echo(isset($menu) && ($menu == '2')) ? 'class="current_section"' : '' ?> title="Add Parking">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'parking/add'); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Add Parking</span>
                        </a>
                    </li>                    
                    <li <?php echo(isset($menu) && ($menu == '33')) ? 'class="current_section"' : '' ?> title="Todays Parking">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'parking'); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Today's Parking</span>
                        </a>
                    </li>                    
<!--                    <li <?php echo(isset($menu) && ($menu == '34')) ? 'class="current_section"' : '' ?> title="Week Parking">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'parking?format=2&end_date='.date('d M Y', strtotime('+1 week'))); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Week Parking</span>
                        </a>
                    </li>                    -->
                    <li <?php echo(isset($menu) && ($menu == '35')) ? 'class="current_section"' : '' ?> title="Month Parking">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'parking?format=2&end_date='.date('d M Y', strtotime('+1 month'))); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Monthly Parking</span>
                        </a>
                    </li>                    
                    <li <?php echo(isset($menu) && ($menu == '36')) ? 'class="current_section"' : '' ?> title="Year Parking">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'parking?format=3&end_date='.date('d M Y', strtotime('+1 year'))); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Yearly Parking</span>
                        </a>
                    </li>                    
                    <li <?php echo(isset($menu) && ($menu == '37')) ? 'class="current_section"' : '' ?> title="Year Parking">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'parking?format=4&end_date='.date('d M Y', strtotime('+1 year'))); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Custom Date Parking</span>
                        </a>
                    </li>                    
                    <li <?php echo(isset($menu) && ($menu == '4')) ? 'class="current_section"' : '' ?> title="Price Table">
                        <a href="<?php echo site_url(ADMIN_FOLDER . 'pricetable'); ?>">
                            <span class="menu_icon"><i class="material-icons">&#xE871;</i></span>
                            <span class="menu_title">Price Table</span>
                        </a>
                    </li>                    
                </ul>
            </div>
             <div class="uk-margin-top uk-text-center">
            
        </div>
        </aside><!-- main sidebar end -->