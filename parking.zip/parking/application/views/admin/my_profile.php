<?php $this->load->view('designer/include/header'); ?>
<?php
if (isset($edit) && !empty($edit)) {
    $id = $edit['id'];
    $name = $edit['name'];
    $email = $edit['email'];
    $password = $edit['p'];
    $gender = $edit['gender'];
    $mobile = $edit['mobile'];
    $address = $edit['address'];
    $city = $edit['city'];
    $state = $edit['state'];
    $country = $edit['country'];
    $pincode = $edit['pincode'];
    $status = $edit['status'];

} else {
    $id = set_value('id');
    $name = set_value('name');
    $email = set_value('email');
    $password = set_value('password');
    $gender = set_value('gender');
    $mobile = set_value('mobile');
    $address = set_value('address');
    $city = set_value('city');
    $state = set_value('state');
    $country = set_value('country');
    $pincode = set_value('pincode');
    $status = set_value('status');

}
?>
<div id="page_content">
    <div id="page_content_inner">
           <?php
        if ($this->session->flashdata('msg') != "") {
            ?>
            <div class="uk-alert uk-alert-success" data-uk-alert>
                <a href="#" class="uk-alert-close uk-close"></a>
                <?php echo $this->session->flashdata('msg') ?>               
            </div>                    
        <?php } ?>

        <h3 class="heading_b uk-margin-bottom">ADD/EDIT DESIGNERS</h3>

        <div class="md-card">
            <div class="md-card-content large-padding">
                <form id="form_validation" method="post" enctype="multipart/form-data" action="<?php echo site_url('designer/my_profile/form'); ?>" class="uk-form-stacked">

                    <div class="uk-grid" data-uk-grid-margin>
                        <input type="hidden" name="id" value='<?php echo $id; ?>' />
                        <div class="uk-width-medium-1-2">
                        
                            <div class="parsley-row">
                                <label for="title">Name<span class="req">*</span></label>
                                <input type="text" name="name" value='<?php echo $name; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('name') ?></span>
                            </div>
                            <br>


                            <div class="parsley-row">
                                <label for="title">Email<span class="req">*</span></label>
                                <input type="text" name="email" value='<?php echo $email; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('email') ?></span>
                            </div>
                            <br>

                            <div class="parsley-row">
                                <label for="title">Password<span class="req">*</span></label>
                                <input type="text" name="password" value='<?php echo $password; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('password') ?></span>
                            </div>
                            <br>

                            <div class="parsley-row">
                                <label for="title">Gender<span class="req">*</span></label>
                                <br>
                                <input type="checkbox" name="gender" value="Male" <?php echo ($gender == 'Male' ? 'checked' : ''); ?>  class="md-input" />Male
                                <input type="checkbox" name="gender" value="Female" <?php echo ($gender == 'Female' ? 'checked' : ''); ?>   class="md-input" />Female
                                <span style="color:red"><?php echo form_error('gender') ?></span>
                            </div>
                            <br>


                            <div class="parsley-row">
                                <label for="title">Mobile<span class="req">*</span></label>
                                <input type="text" name="mobile" value='<?php echo $mobile; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('mobile') ?></span>
                            </div>
                            <br>


                            <div class="parsley-row">
                                <label for="title">Address<span class="req">*</span></label>
                                <input type="text" name="address" value='<?php echo $address; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('address') ?></span>
                            </div>
                            <br>

                            <div class="parsley-row">
                                <label for="title">City<span class="req">*</span></label>
                                <input type="text" name="city" value='<?php echo $city; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('city') ?></span>
                            </div>
                            <br>

                            <div class="parsley-row">
                                <label for="title">State<span class="req">*</span></label>
                                <input type="text" name="state" value='<?php echo $state; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('state') ?></span>
                            </div>
                            <br>


                            <div class="parsley-row">
                                <label for="title">Country<span class="req">*</span></label>
                                <input type="text" name="country" value='<?php echo $country; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('country') ?></span>
                            </div>
                            <br>


                            <div class="parsley-row">
                                <label for="title">Pincode<span class="req">*</span></label>
                                <input type="text" name="pincode" value='<?php echo $pincode; ?>' required class="md-input" />
                                <span style="color:red"><?php echo form_error('pincode') ?></span>
                            </div>
                            <br>

                            <div class="parsley-row">
                                <label for="title">Status<span class="req">*</span></label>
                                <select name="status" id="status" class="md-input" required="">
                                    <option value="1"  <?php echo ($status == 1 ? 'selected' : ''); ?>  >Active</option>
                                    <option value="0"  <?php echo ($status == 0 ? 'selected' : ''); ?> >De-Active</option>
                                </select>
                            </div>
                            <br>
                        </div>                        
                    </div>                 
                    <div class="uk-grid">
                        <div class="uk-width-1-1">
                            <button type="submit" name='submit' class="md-btn md-btn-primary">Submit</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php $this->load->view('designer/include/footer'); ?>







