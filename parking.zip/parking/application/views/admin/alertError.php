<div class="uk-width-1-1 uk-row-first">
<?php
$msg = $this->session->flashdata('msg');
if ($msg != '') {
    ?>
     <div class="uk-alert uk-alert-success" data-uk-alert="">
        <a href="javascript:;" class="uk-alert-close uk-close"></a>
            <?php
            echo $msg;
            $this->session->set_flashdata('msg', '');
            ?>   
    </div>
<?php } ?>

<?php
$err = $this->session->flashdata('err');
if ($err != '') {
    ?>
    <div class="uk-alert uk-alert-danger" data-uk-alert="">
        <a href="javascript:;" class="uk-alert-close uk-close"></a>
        <?php
        echo $err;
        $this->session->set_flashdata('err', '');
        ?>  
    </div>
<?php } ?>

<?php
if (isset($error) && !empty($error)) {
    ?>
   <div class="uk-alert uk-alert-danger" data-uk-alert="">
        <a href="javascript:;" class="uk-alert-close uk-close"></a>
            <?php
            echo $error;
            ?>   
    </div>
<?php } ?>
</div>