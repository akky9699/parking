<?php $this->load->view(ADMIN_FOLDER . 'include/header'); ?>
<div id="page_content">
    <div id="page_content_inner">

        <div class="md-card">
            <div class="md-card-toolbar">               
                <h3 class="md-card-toolbar-heading-text">Price Table</h3>
            </div>

        </div>

        <?php
        if ($this->session->flashdata('msg') != "") {
            ?>
            <div class="uk-alert uk-alert-success" data-uk-alert>
                <a href="#" class="uk-alert-close uk-close"></a>
                <?php echo $this->session->flashdata('msg') ?>               
            </div>                    
        <?php } ?>
        <div class="md-card uk-margin-medium-bottom">
            <div class="md-card-content large-padding">
                <form id="form_validation" method="post" enctype="multipart/form-data" action="<?php echo site_url(ADMIN_FOLDER . 'pricetable/save'); ?>" class="uk-form-stacked">
                    <div class="uk-overflow-container">                    

                        <?php
                        if (isset($vehicle_type) && !empty($vehicle_type)) {
                            foreach ($vehicle_type as $vt) {
                                ?>
                                <div class="uk-grid" data-uk-grid-margin>
                                    <div class="uk-width-medium-1-6">
                                        <div class="parsley-row">
                                            <h2><?php echo $vt['name']; ?></h2>
                                        </div>
                                    </div>

                                    <?php
                                    if (isset($vt['pricearray']) && !empty($vt['pricearray'])) {
                                        foreach ($vt['pricearray'] as $key => $val) {
                                            ?>
                                            <div class="uk-width-medium-1-6">

                                                <div class="parsley-row">
                                                    <label for="title"><?php echo $parking_type[$key]['name'] ?><span class="req">*</span></label>
                                                    <input type="text" name="price[<?php echo $vt['id'] ?>][<?php echo $key ?>]" value="<?php echo $val; ?>" onkeypress="return isNumber(this.event)" class="md-input" required>
                                                </div>
                                            </div>
                                            <?php
                                        }
                                    }
                                    ?>
                                </div>
                                <?php
                            }
                        }
                        ?>
                        <div class="uk-grid" data-uk-grid-margin>
                            <div class="uk-width-medium-1-1">
                                <button type="submit" name='submit' class="md-btn md-btn-primary">Submit</button>
                            </div>
                        </div>

                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view(ADMIN_FOLDER . 'include/footer'); ?>