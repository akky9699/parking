<?php $this->load->view(ADMIN_FOLDER . 'include/header'); ?>
<div id="page_content">
    <div id="page_content_inner">

        <div class="md-card">
            <div class="md-card-toolbar">               
                <h3 class="md-card-toolbar-heading-text">Dashboard</h3>
            </div>

        </div>

        <!-- statistics (small charts) -->
        <div class="uk-grid uk-grid-width-large-1-2 uk-grid-width-medium-1-2 uk-grid-medium  hierarchical_show" data-uk-grid-margin>

            <?php
            if (isset($new_array) && !empty($new_array)) {
               
                foreach ($new_array as $val) {
                    ?>
                    <div>
                        <div class="md-card">
                            <div class="md-card-content">                                
                                <div class="uk-float-right uk-margin-top uk-margin-small-right">
                                    <h2>Parking : <?php echo (!empty($val['count']) ? $val['count'] : '0'); ?></h2>
                                </div>
                                <span class="uk-text-muted uk-text-small"><?php echo $val['name']; ?></span>                                
                                <h2 class="uk-margin-remove">Price : 
                                    <span class="countUpMe">
                                    <?php echo (!empty($val['price']) ? $val['price'] : '0'); ?>
                                    </span>
                                </h2>
                            </div>                            
                        </div>
                    </div>
                    <?php
                }
            }
            ?>

        </div>
    </div>

    <?php $this->load->view(ADMIN_FOLDER . 'include/footer'); ?>
