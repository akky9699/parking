<?php $this->load->view(ADMIN_FOLDER . 'include/header_login.php'); ?>
<div class="login_page_wrapper">
    <div class="md-card" id="login_card">
        <div class="md-card-content large-padding" id="login_form">
            <div class="login_heading">                
                <img src="<?php echo UPLOAD_PATH; ?>logo.png" class="img-responsive" />
            </div>
            <form name="login_form" id="login_form" action="<?php echo site_url(ADMIN_FOLDER . 'login/index'); ?>" method="post">
                <div class="uk-form-row">
                    <label for="login_username">Email</label>
                    <input class="md-input" type="text" id="username" name="email" autocomplete="off" />
                </div>
                <div class="uk-form-row">
                    <label for="login_password">Password</label>
                    <input class="md-input" type="password" id="password" name="password" autocomplete="off" />
                </div>
                <div class="uk-margin-medium-top">
                    <button type="submit" class="md-btn md-btn-primary md-btn-block md-btn-large">Sign In</button>
                </div>
                <div class="uk-margin-top">
                    <a href="#" id="password_reset_show" class="uk-float-right">Forgot password ?</a>
                    <span class="icheck-inline">
                        <input type="checkbox" name="login_page_stay_signed" id="login_page_stay_signed" data-md-icheck />
                        <label for="login_page_stay_signed" class="inline-label">Stay signed in</label>
                    </span>
                </div>
                <?php
                $this->load->view(ADMIN_FOLDER . 'alertError.php');
                ?>
            </form>
        </div>
        <div class="md-card-content large-padding" id="login_password_reset" style="display: none">
            <button type="button" class="uk-position-top-right uk-close uk-margin-right uk-margin-top back_to_login"></button>
            <h2 class="heading_a uk-margin-large-bottom">Reset password</h2>
            <form name="forgot_form" id="forgot_form" action="<?php echo site_url(ADMIN_FOLDER . 'login/forgot') ?>" method="post">
                <div class="uk-form-row">
                    <label for="login_email_reset">Your email address</label>
                    <input class="md-input" type="text" id="email" autocomplete="off" placeholder="" name="email" required="" />
                </div>
                <div class="uk-margin-medium-top">
                    <button type="submit" class="md-btn md-btn-primary md-btn-block">Reset password</button>
                </div>
            </form>
            <span></span>
        </div>

    </div>
    <div class="uk-margin-top uk-text-center">
            <a href="javascript:;" style="color:#444;">Developed By GROUP 6</a>
        </div>
</div>
<?php $this->load->view(ADMIN_FOLDER . 'include/footer_login.php'); ?>