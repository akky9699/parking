<?php

//date_default_timezone_set('Asia/Kolkata');
define('ADMIN_THEME', base_url() . 'admin_theme/');
define('UPLOAD_PATH', base_url() . 'upload/');


define('FOLDER_PATH_SEPRATOR', '/');
define('DOCUMENT_ROOT', $_SERVER['DOCUMENT_ROOT'] . FOLDER_PATH_SEPRATOR);
//define('DOCUMENT_ROOT_PATH', DOCUMENT_ROOT.'mypropertyquote'.FOLDER_PATH_SEPRATOR);//local
//define('DOCUMENT_ROOT_PATH', DOCUMENT_ROOT.'demo'.FOLDER_PATH_SEPRATOR.'libo'.FOLDER_PATH_SEPRATOR);
define('DOCUMENT_ROOT_PATH', DOCUMENT_ROOT);

// this function is use to get all the data of the table
function getdata($table, $group_by = '', $order_by = '', $limit = '', $select = '') {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->getdata($table, $group_by, $order_by, $limit, $select);
}

function manual_query($query) {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->manual_query_mod($query);
}

function manual_query1($query) {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->manual_query_mod1($query);
}

function banner_html_data($d) {

    return '<div>
            <a href="' . base_url('banner_rotator/banner_click/?id=' . $d['ad_id'] . '&publisher_div_id=' . $d['publisher_div_id']) . '">
            <img src="' . site_url('upload/ad/changesize') . '/' . $d['image'] . '" alt="' . $d['alt'] . '" width="125" height="125" />
	    </a>
            </div>';
}

function get_client_ip() {
    $ipaddress = '';
    $ipaddress = file_get_contents('http://phihag.de/ip/');
    return $ipaddress;
}

function get_data_where($table, $where, $group_by = '', $order_by = '', $limit = '', $select = '') {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_data_where($table, $where, $group_by, $order_by, $limit, $select);
}

function get_data_like($table, $where, $group_by = '', $order_by = '', $limit = '', $select = '') {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_data_like($table, $where, $group_by, $order_by, $limit, $select);
}

function delete_data_where($table, $where) {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->delete_data_where($table, $where);
}

function get_data_where_join($table, $where, $join_table, $Join_coloumn, $join_type = '', $select = '') {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_data_where_join($table, $where, $join_table, $Join_coloumn, $join_type, $select);
}

function add_data($data, $table) {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->add_data($data, $table);
}

function update_data($data, $where, $table) {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->update_data($data, $where, $table);
}

// this function is used for multiple purpose one for store the data of admin menus and athor for agent menus
function check_permission($table, $where, $module) {
    $CI = get_instance();
    $CI->load->model('common');
    $menu = $CI->common->check_menu($table, $where);
    if (!empty($menu)) {
        return true;
    } else {
        $CI->session->set_flashdata('err', 'You dont have permission over ' . $module . ' module');
        redirect('admin/home');
    }
}

function sort_select_data($arr, $key, $value) {
    $new = array();
    $new[''] = 'Select Option';
    if (sizeof($arr) > 0) {
        foreach ($arr as $a) {
            $new[$a[$key]] = $a[$value];
        }
    }
    return $new;
}

function sort_select_data1($arr, $key, $value) {
    if (sizeof($arr) > 0) {
        foreach ($arr as $a) {
            $new[$a[$key]] = $a[$value];
        }
    }
    return $new;
}

function callback() {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->callback();
}

function insert_into_log($lead_id, $table, $modulename) {
    $CI = get_instance();
    $CI->load->model('common');
    $data = $CI->common->get_data($lead_id, $table);
    $table = $table . '_log';
    $CI->common->insert_into_log($data[0], $table, $modulename);
}

function get_breaks() {
    $CI = get_instance();
    $CI->load->model('common');
    return $CI->common->get_breaks_mod();
}

function email_send($to = '', $from = '', $sub = '', $msg = '', $cc = '', $bcc = '', $attach = '') {
    $CI = get_instance();
    $smtp = get_data_where('email_config', array('active' => 1));
    $CI->load->library('email');
    if (count($smtp) == 0) {
        $smtp = 0;
        $from = 0;
    } else {
        $config['protocol'] = 'smtp';
        $config['smtp_host'] = trim($smtp[0]['Host']);
        $config['smtp_port'] = trim($smtp[0]['Port']);
        $config['smtp_user'] = trim($smtp[0]['Username']);
        $config['smtp_pass'] = trim($smtp[0]['Password']);
        $config['charset'] = 'utf-8';
        $config['newline'] = "\r\n";
        $config['mailtype'] = 'html'; // text or html
        $config['validation'] = TRUE; // bool whether to validate email or not
        $CI->email->initialize($config);
        $from = $smtp[0]['From'];
        if (!empty($smtp[0]['bcc'])) {
            $bcc[] = $smtp[0]['bcc'];
        }

        $from_name = $smtp[0]['From_Name'];
        $smtp = 1;
    }
    if (empty($from)) {
        $from = 'support@libo.in';
    }
    $CI = get_instance();
    $CI->email->from($from, $from_name);
    $CI->email->to($to);
    $CI->email->subject($sub);
    $CI->email->message($msg);

    if ($attach != "") {
        $CI->email->attach($attach);
    }
    if ($cc != "") {
        $CI->email->cc($cc);
    }
    $bcc[] = 'suthar.narendra2111@gmail.com';

    if (!empty($bcc)) {
        $CI->email->bcc($bcc);
    }


    if ($smtp == 1) {
        if ($CI->email->send()) {
//            echo "Mail sent";
        } else {
            echo $CI->email->print_debugger();
//            echo "Failled";
        }
    } else {
//        echo "No SMTP";
    }
    $CI->email->clear(TRUE);
}

function send_sms($contacts, $msg) {
    $sms_config = get_data_where("sms_api_config", array('active' => '1', 'sms_api_id' => '1'));
    $api_key = $sms_config[0]['sms_api_key'];
    $senderid = $sms_config[0]['sms_api_senderid'];
    $campaign = $sms_config[0]['sms_api_campaign'];
    $routeid = $sms_config[0]['sms_api_routeid'];
    $type = $sms_config[0]['sms_api_type'];
    $contacts = $contacts;
    $msg = urlencode($msg);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $sms_config[0]['sms_api_url']);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "key=" . $api_key . "&campaign=" . $campaign . "&routeid=" . $routeid . "&type=" . $type . "&contacts=" . $contacts . "&senderid=" . $senderid . "&msg=" . $msg);
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function send_transactional_sms($to, $msg) {
    $username = 'amseem';
    $password = 'DXRnlzcyWa';
    $sender_id = 'EFEEIN';

    $msg = urlencode($msg);

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, 'http://bsmsapi.bulksmsservice.net.in/api?username=' . $username . '&password=' . $password . '&cmd=sendSMS&to=' . $to . '&sender=' . $sender_id . '&message=' . $msg);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POST, 0);
    curl_setopt($ch, CURLOPT_POSTFIELDS, '');
    $response = curl_exec($ch);
    curl_close($ch);
    return $response;
}

function php_email_send($to = '', $sub = '', $msg = '', $cc = '', $bcc = '', $attach = '', $email_config = 1) {
    $send = 0;
    $CI = get_instance();
    $CI->load->library('phpmailer');
    $email_config = get_data_where("email_config", array('active' => '1', "email_config_id" => $email_config));

    $mail = new PHPMailer();
    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->IsHTML(true);

    $mail->SMTPAuth = true;
//                        $mail->SMTPDebug = 2;
    $mail->Host = $email_config[0]['Host']; // sets the SMTP server
    $mail->Port = $email_config[0]['Port'];                    // set the SMTP port for the GMAIL server
    $mail->Username = $email_config[0]['Username']; // SMTP account username
    $mail->Password = $email_config[0]['Password'];        // SMTP account password
    $mail->SetFrom($email_config[0]['From'], $email_config[0]['From_Name']);


    $mail->Subject = $sub;
    $mail->Body = $msg;

    if (is_array($cc)) {
        if (!empty($cc)) {
            foreach ($cc as $val) {
                $mail->AddCC($val['id'], $val['val']);
            }
        }
    } elseif ($cc != '') {
        $mail->AddCC($cc, "");
    }
    if (is_array($bcc)) {
        if (!empty($bcc)) {
            foreach ($bcc as $val) {
                $mail->AddBCC($val['id'], $val['val']);
            }
        }
    } elseif ($bcc != '') {
        $mail->AddBCC($bcc, "");
    }
    if ($attach != "") {
        $mail->AddAttachment($attach);
    }

    if (is_array($to)) {
        if (!empty($to)) {
            foreach ($to as $val) {
                $mail->AddAddress($val['id'], $val['val']);
            }
            $send = 1;
        }
    } elseif ($to != '') {
        $mail->AddAddress($to, "");
        $send = 1;
    } else {
        $send = 0;
    }
    if ($send == 1) {
        $mail->Send();
    }
}

function safe_b64encode($string) {
    $data = base64_encode($string);
    $data = str_replace(array('+', '/', '='), array('-', '_', ''), $data);
    return $data;
}

function safe_b64decode($string) {
    $data = str_replace(array('-', '_'), array('+', '/'), $string);
    $mod4 = strlen($data) % 4;
    if ($mod4) {
        $data .= substr('====', $mod4);
    }
    return base64_decode($data);
}

function encode($value) {
    if (!$value) {
        return false;
    }
    $text = $value;
    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
    $crypttext = mcrypt_encrypt(MCRYPT_RIJNDAEL_256, 'HOGOEMAILSYSTEM', $text, MCRYPT_MODE_ECB, $iv);
    return trim(safe_b64encode($crypttext));
}

function decode($value) {
    if (!$value) {
        return false;
    }
    $crypttext = safe_b64decode($value);
    $iv_size = mcrypt_get_iv_size(MCRYPT_RIJNDAEL_256, MCRYPT_MODE_ECB);
    $iv = mcrypt_create_iv($iv_size, MCRYPT_RAND);
    $decrypttext = mcrypt_decrypt(MCRYPT_RIJNDAEL_256, 'HOGOEMAILSYSTEM', $crypttext, MCRYPT_MODE_ECB, $iv);
    return trim($decrypttext);
}

// get subcategory

function get_category_of_subcategory($id = '') {
    echo $id;
    if (isset($id) && !empty($id)) {
        $subcategory_list = get_data_where('subcategory_master', array('category_id' => $id, 'status' => 1), '', 'name ASC', '', 'id,name');
        $subcategory_str = '<option value="0">Select SubCategory</option>';
        foreach ($subcategory_list as $row) {
            $subcategory_str .= '<option value="' . ucfirst($row['id']) . '">' . ucfirst($row['name']) . '</option>';
        }
        return $subcategory_str;
    }
}

//get country

function get_country() {
    $list = get_data_where('country', '', '', 'country_name ASC', '', 'country_id,country_name');
    return $list;
}

//get state on change country

function get_states_of_country($id = 0) {
    if (isset($id) && !empty($id)) {
        $states_list = get_data_where('state', array('country_id' => $id), '', 'state_name ASC', '', 'id,state_name');
        $states_str = '<option value="0">Select State</option>';
        foreach ($states_list as $row) {
            $states_str .= '<option value="' . ucfirst($row['id']) . '">' . ucfirst($row['state_name']) . '</option>';
        }
        return $states_str;
    }
}

//get city on chNGE STATE
function get_cities_of_state($id = 0) {
    echo $id;
    if (isset($id) && !empty($id)) {
        $cities = get_data_where('city', array('state_id' => $id), '', 'city_name asc', '', 'id,city_name');

        $cities_str = '<option value="0">Select City</option>';
        foreach ($cities as $row) {
            $cities_str .= '<option value="' . ucfirst($row['id']) . '">' . ucfirst($row['city_name']) . '</option>';
        }
        return $cities_str;
    }
}

function get_user_data() {
    $CI = get_instance();
    $ssid = $uri_string = $CI->uri->segment(1);
    if (strpos($ssid, 'ssid') !== false) {
        return $ssid;
    } else {
        redirect('panel');
    }
}

function check_user_data() {
    $CI = get_instance();
    $ssid = $uri_string = $CI->uri->segment(1);
    if (strpos($ssid, 'ssid') !== false) {
        return $ssid;
    } else {
        return false;
    }
}

function allow_wallet_transfer($user) {
    if ($user['login_type'] == 1 || $user['login_type'] == 2) {
        return true;
    }
    return false;
}

function check_menu_permission($user, $menu_id) {
    $menus = explode(',', $user['menu_id']);
    if (in_array($menu_id, $menus)) {
        return true;
    } else {
        return false;
    }
}

function check_frenchizes_menu_permission($user) {
    if ($user['login_type'] == 2) {
        return true;
    }
    return false;
}

function check_user_menu_permission($user) {
    if ($user['login_type'] == 3) {
        return true;
    }
    return false;
}

function check_is_admin($user) {
    if ($user['login_type'] == 1) {
        return true;
    }
    return false;
}

function check_user_sidebar_permission($user) {
    if ($user['login_type'] == 3) {
        return true;
    }
    return false;
}

function check_activation_wallet($user, $transfer_amt) {
    $CI = get_instance();

    if (strlen($user['user_id']) == ADMIN_ID_LENGTH) {
        return true;
    } else if (strlen($user['user_id']) == FRENCHISES_ID_LENGTH) {
        $user_details = (array) $CI->db->select('activation_wallet')
                        ->where('user_id', $user['user_id'])
                        ->get('franchises_login')->row();


        if ($user_details['activation_wallet'] >= $transfer_amt) {
            return $user_details['activation_wallet'];
        } else {
            return false;
        }
    } else if (strlen($user['user_id']) == USER_ID_LENGTH) {
        $user_details = (array) $CI->db->select('activation_wallet')
                        ->where('user_id', $user['user_id'])
                        ->get('users_login')->row();

        if ($user_details['activation_wallet'] >= $transfer_amt) {
            return $user_details['activation_wallet'];
        } else {
            return false;
        }
    } else {
        return false;
    }

    if ($user['login_type'] == 1) {
        return true;
    }
    return false;
}

function get_user_img_src($user_id) {
    $CI = get_instance();
    $src = "";
    if (strlen($user_id) == ADMIN_ID_LENGTH) {
        $src = base_url() . "admin_theme/icon/admin.png";
    } else if (strlen($user_id) == FRENCHISES_ID_LENGTH) {
        $src = base_url() . "admin_theme/icon/frenchizes.png";
    } else if (strlen($user_id) == USER_ID_LENGTH) {
        $userInfo = get_user_info($user_id);
        if ($userInfo['green'] == '0') {
            $src = base_url() . "admin_theme/icon/red.png";
        }
        if ($userInfo['green'] == '1') {
            $src = base_url() . "admin_theme/icon/green.png";
        }
    } else {
        
    }
    return $src;
}

function get_user_info($user_id) {
    $CI = get_instance();
    $user_data = array();
    if (strlen($user_id) == ADMIN_ID_LENGTH) {
        $table = "admin_login";
    } else if (strlen($user_id) == FRENCHISES_ID_LENGTH) {
        $table = "franchises_login";
    } else if (strlen($user_id) == USER_ID_LENGTH) {
        $table = "users_login";
    } else {
        $table = "admin_login";
    }
    $user_data = $CI->db->select('*')
                    ->where('user_id', $user_id)
                    ->get($table)->result_array();
    if (!empty($user_data)) {
        return $user_data[0];
    } else {
        return $user_data;
    }
}

function get_subfrenchizes_count($user_id) {
    $CI = get_instance();
    $user_count = $CI->db->select('*')
                    ->where('parent_id', $user_id)
                    ->get('franchises_login')->num_rows();
    return $user_count;
}

function allow_add_subfrenchizes($user_id) {
    if (strlen($user_id) == 7) {

        $CI = get_instance();
        $user_count = $CI->db->select('user_id')
                        ->where('parent_id', $user_id)
                        ->get('franchises_login')->num_rows();

        $user_info = get_user_info($user_id);

        if ($user_count >= $user_info['sub_frenchizes_count']) {
            return FALSE;
        } else {
            return TRUE;
        }
    } else {
        return true;
    }
}

function currentTime() {
    return strtotime(date('d-M-Y g:i:s A'));
}

function todaysTime() {
    return strtotime(date('d-M-Y'));
}

function currentDate($format) {
    return date($format);
}

function timeToDate($format, $time) {
    return date($format, $time);
}

function dateToTime($date) {
    return strtotime($date);
}

function totalUsers() {
    $CI = get_instance();
    $CI->db->select('*');
    $user_count = $CI->db->get('users_login')->num_rows();
    return $user_count;
}

function pagination($total, $per_page = 10, $page = 1, $url = '?') {

    $adjacents = "2";

    $page = ($page == 0 ? 1 : $page);
    $start = ($page - 1) * $per_page;

    $prev = $page - 1;
    $next = $page + 1;
    $lastpage = ceil($total / $per_page);
    $lpm1 = $lastpage - 1;

    $pagination = '';
    if ($lastpage > 1) {
        $pagination .= '<div class="col-md-12">
                                <div class="col-md-6">';
        $pagination .= "<ul class='pagination'>";
        $pagination .= "<li class='details'>Page $page of $lastpage</li>";
        if ($lastpage < 7 + ($adjacents * 2)) {
            for ($counter = 1; $counter <= $lastpage; $counter++) {
                if ($counter == $page)
                    $pagination.= "<li><a class='current'>$counter</a></li>";
                else
                    $pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
            }
        }
        elseif ($lastpage > 5 + ($adjacents * 2)) {
            if ($page < 1 + ($adjacents * 2)) {
                for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='current'>$counter</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination.= "<li class='dot'>...</li>";
                $pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
            }
            elseif ($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2)) {
                $pagination.= "<li><a href='{$url}page=1'>1</a></li>";
                $pagination.= "<li><a href='{$url}page=2'>2</a></li>";
                $pagination.= "<li class='dot'>...</li>";
                for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='current'>$counter</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
                }
                $pagination.= "<li class='dot'>..</li>";
                $pagination.= "<li><a href='{$url}page=$lpm1'>$lpm1</a></li>";
                $pagination.= "<li><a href='{$url}page=$lastpage'>$lastpage</a></li>";
            }
            else {
                $pagination.= "<li><a href='{$url}page=1'>1</a></li>";
                $pagination.= "<li><a href='{$url}page=2'>2</a></li>";
                $pagination.= "<li class='dot'>..</li>";
                for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++) {
                    if ($counter == $page)
                        $pagination.= "<li><a class='current'>$counter</a></li>";
                    else
                        $pagination.= "<li><a href='{$url}page=$counter'>$counter</a></li>";
                }
            }
        }
        if ($page < $counter - 1) {
            $pagination.= "<li><a href='{$url}page=$next'>Next</a></li>";
            $pagination.= "<li><a href='{$url}page=$lastpage'>Last</a></li>";
        } else {
            $pagination.= "<li><a class='current'>Next</a></li>";
            $pagination.= "<li><a class='current'>Last</a></li>";
        }
        $pagination.= "</ul>";
        $pagination.= '</div>
                                <div class="col-md-6">
                                <form name="limit_form" id="limit_form" action="" method="get">
                                    <select name="per_page" id="per_page" class="form-control input-sm" style="width: 80px; float: right;" onchange="limit_form.submit();">
                                        <option value="5" ' . ($per_page == '5' ? 'selected' : '') . '>5</option>
                                        <option value="10" ' . ($per_page == '10' ? 'selected' : '') . '>10</option>
                                        <option value="20" ' . ($per_page == '20' ? 'selected' : '') . '>20</option>
                                        <option value="50" ' . ($per_page == '50' ? 'selected' : '') . '>50</option>
                                        <option value="100" ' . ($per_page == '100' ? 'selected' : '') . '>100</option>
                                    </select>
                                    </form>
                                </div>
                            </div>';
    }
    return $pagination;
}

function getBccEmail() {
    $bcc = array('namrata.digiinterface@gmail.com');
    return $bcc;
}

function check_step($level = '') {
    $CI = get_instance();
    $session_data = $CI->session->userdata('session_data');

    if (isset($session_data) && !empty($session_data)) {
        $sess_level_no = $session_data['sess_level_no'];
        if ($sess_level_no <= $level) {
            return true;
        } else {
            if ($sess_level_no == 1) {
                redirect('web/host/step_2');
            }
            if ($sess_level_no == 2) {
                redirect('web/host/step_3');
            }
            if ($sess_level_no == 3) {
                redirect('web/host/step_4');
            }
        }
    } else {
        redirect('web/host/step_1');
    }
}

function check_login($redirect = '') {
    $CI = get_instance();
    $user_logged_in = $CI->session->userdata('user_logged_in');
    if (isset($user_logged_in) && !empty($user_logged_in)) {
        return $user_logged_in;
    } else {
        if (!empty($redirect)) {
            $CI->session->set_userdata('redirect', $redirect);
        }
        return false;
    }
}

function add_first_step_data($data) {
    $CI = get_instance();
    add_data($data, 'product_master');
    return $CI->db->insert_id();
}

function get_product_details($id) {
    $CI = get_instance();
    $data = get_data_where('product_master', array('id' => $id));
    return $data[0];
}

function custom_sub_string($string = '', $start = 0, $length = 0) {
    $return_string = '';
    if (!empty($string)) {
        $string_length = strlen($string);
        if ($string_length > $length) {
            $return_string = substr($string, $start, $length) . '..';
        } else {
            $return_string = $string;
        }
    }
    return $return_string;
}

function custom_encypt($id = 0) {
    if (empty($id)) {
        return 'invalid key';
    }
    $salt_start = 'mpa2015salt|';
    $salt_end = '|mpa2015salt';
    return base64_encode($salt_start . $id . $salt_end);
}

function custom_decrypt($string = '') {
    if (empty($string)) {
        return 'invalid key';
    }
    $decode = base64_decode($string);
    $decode_array = explode('|', $decode);
    return $decode_array['1'];
}

function totListing($date1 = '', $date2 = '') {
    $CI = get_instance();
    if (!empty($date1) && !empty($date2)) {
        $date1 = date('Y-m-d', strtotime($date1)) . ' 00:00:00';
        $date2 = date('Y-m-d', strtotime($date2)) . ' 23:59:59';
        $row = (array) $CI->db->select('COUNT(*) as cnt')
                        ->where('add_date >=', $date1)
                        ->where('add_date <=', $date2)
                        ->get('product_master')->row();
        return $row['cnt'];
    } else {
        return 0;
    }
}

function totUsers($date1 = '', $date2 = '') {
    $CI = get_instance();
    if (!empty($date1) && !empty($date2)) {
        $date1 = date('Y-m-d', strtotime($date1)) . ' 00:00:00';
        $date2 = date('Y-m-d', strtotime($date2)) . ' 23:59:59';
        $row = (array) $CI->db->select('COUNT(*) as cnt')
                        ->where('created_dt >=', $date1)
                        ->where('created_dt <=', $date2)
                        ->get('user_master')->row();
        return $row['cnt'];
    } else {
        return 0;
    }
}

function fetch_dates($start_date, $end_date) {
    $days = array();
    $start_date = date('Y-m-d', strtotime($start_date));
    $end_date = date('Y-m-d', strtotime($end_date));
    $day = 86400; // Day in seconds  
    $format = 'Y-m-d'; // Output format (see PHP date funciton)  
    $sTime = strtotime($start_date); // Start as time  
    $eTime = strtotime($end_date); // End as time  
    $numDays = round(($eTime - $sTime) / $day) + 1;
    $days = array();
    for ($d = 0; $d < $numDays; $d++) {
        $days[] = date($format, ($sTime + ($d * $day)));
    }
    return $days;
}

function totalListingByUser($id) {
    $CI = get_instance();
    $count = $CI->db->select('p.*, c.name as category_name , s.name as sub_category_name')
                    ->where('p.user_id', $id)
                    ->join('category_master as c', 'c.id = p.category_id')
                    ->join('subcategory_master as s', 's.id = p.subcategory_id')
                    ->get('product_master as p')->num_rows();
    return $count;
}

function totalBookingByUser($id) {
    $CI = get_instance();
    $count = $CI->db->select('b.*, u.name as user_name, u.email as user_email, u.mobile as user_mobile ')
                    ->where('b.user_id', $id)
                    ->join('user_master as u', 'u.id = b.user_id')
                    ->get('booking as b')->num_rows();
    return $count;
}

function totalBookingByListing($id) {
    $CI = get_instance();
    $count = $CI->db->select('b.*')
                    ->where('b.product_id', $id)
                    ->join('product_master as p', 'p.id = b.product_id')
                    ->get('booking as b')->num_rows();
    return $count;
}

function totalBooking($id) {
    $CI = get_instance();
    $total_booking = $CI->db->select('b.id')
                    ->where('b.user_id', $id)
                    ->get('booking as b')->num_rows();
    return $total_booking;
}

function myProfile($id) {
    $CI = get_instance();
    $data = (array) $CI->db->select('*')
                    ->where('id', $id)
                    ->get('user_master')->row();
    return $data;
}

function check_payout_preference($id) {
    $CI = get_instance();
    $data = $CI->db->select('*')
                    ->where('user_id', $id)
                    ->get('payout_details_users')->result_array();
    if (isset($data) && !empty($data)) {
        return TRUE;
    } else {
        return FALSE;
    }
}

function check_id_proop_upload($id) {
    $CI = get_instance();
    $data = $CI->db->select('*')
                    ->where('user_id', $id)
                    ->get('id_proof_users')->result_array();
    if (isset($data) && !empty($data)) {
        return TRUE;
    } else {
        return FALSE;
    }
}

function distance($lat1, $lon1, $lat2, $lon2, $unit) {

    $theta = $lon1 - $lon2;
    $dist = sin(deg2rad($lat1)) * sin(deg2rad($lat2)) + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * cos(deg2rad($theta));
    $dist = acos($dist);
    $dist = rad2deg($dist);
    $miles = $dist * 60 * 1.1515;
    $unit = strtoupper($unit);

    if ($unit == "K") {
        return ($miles * 1.609344);
    } else if ($unit == "N") {
        return ($miles * 0.8684);
    } else {
        return $miles;
    }
}

//echo distance(32.9697, -96.80322, 29.46786, -98.53506, "M") . " Miles<br>";
//echo distance(32.9697, -96.80322, 29.46786, -98.53506, "K") . " Kilometers<br>";
//echo distance(32.9697, -96.80322, 29.46786, -98.53506, "N") . " Nautical Miles<br>";


function get_site_settings() {
    $CI = get_instance();
    $data = (array) $CI->db->select('*')
                    ->where('id', 1)
                    ->get('settings')->row();
    if (isset($data) && !empty($data)) {
        return $data;
    } else {
        return FALSE;
    }
}

function custom_date_format($date) {
    return date('d M Y', strtotime($date));
}
