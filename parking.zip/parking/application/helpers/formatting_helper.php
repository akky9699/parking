<?php

function format_address($fields, $br = false) {
    if (empty($fields)) {
        return;
    }

    // Default format
    $default = "{firstname} {lastname}\n{address_1}\n{address_2}\n{city}, {zone} {postcode}\n{country}";

    // Fetch country record to determine which format to use
    $CI = &get_instance();
    $CI->load->model('location_model');
    $c_data = $CI->location_model->get_country($fields['country_id']);

    if (empty($c_data->address_format)) {
        $formatted = $default;
    } else {
        $formatted = $c_data->address_format;
    }

    $formatted = str_replace('{firstname}', $fields['firstname'], $formatted);
    $formatted = str_replace('{lastname}', $fields['lastname'], $formatted);
    $formatted = str_replace('{company}', $fields['company'], $formatted);

    $formatted = str_replace('{address_1}', $fields['address1'], $formatted);
    $formatted = str_replace('{address_2}', $fields['address2'], $formatted);
    $formatted = str_replace('{city}', $fields['city'], $formatted);
    $formatted = str_replace('{zone}', $fields['zone'], $formatted);
    $formatted = str_replace('{postcode}', $fields['zip'], $formatted);
    $formatted = str_replace('{country}', $fields['country'], $formatted);

    // remove any extra new lines resulting from blank company or address line
    $formatted = preg_replace('`[\r\n]+`', "\n", $formatted);
    if ($br) {
        $formatted = nl2br($formatted);
    }
    return $formatted;
}

function format_currency($value, $symbol = true) {
    // locale information must be set up for this to return a proper value
    // return money_format(!%i, $value);

    if (!is_numeric($value)) {
        return;
    }

    $CI = &get_instance();



    $currency_symbol = $CI->config->item('currency_symbol');


    if ($value < 0) {
        $neg = '- ';
    } else {
        $neg = '';
    }

    $formatted = number_format(abs($value), 2, '.', ',');

    if ($symbol) {
        $formatted = $neg . $currency_symbol . $formatted;
    }

    return $formatted;
}

function convert_Amount($amt, $from, $to) {
    if ($from == $to) {
        return $amt;
    }
    $returnHtml = array();
    $page = 'http://www.google.com/finance/converter?a=' . $amt . '&from=' . $from . '&to=' . $to;
    $returnRawHtml = @file_get_contents($page);

    preg_match_all('/\<span class=bld\>(.*)\<\/span\>/Uis', $returnRawHtml, $returnHtml, PREG_PATTERN_ORDER); // Mine
    if (isset($returnHtml[0][0])) {
        $ConversionRate = strip_tags($returnHtml[1][0]);

        return (float) $ConversionRate;
    } else {
        return false;
    }
}
