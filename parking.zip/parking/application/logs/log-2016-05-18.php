<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-18 18:04:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 18:04:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 18:04:33 --> Severity: Notice  --> Undefined variable: total /home/trademar/public_html/amhan.in/parking/application/views/admin/parking.php 145
ERROR - 2016-05-18 18:04:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 18:04:38 --> Severity: Notice  --> Undefined variable: total /home/trademar/public_html/amhan.in/parking/application/views/admin/parking.php 145
ERROR - 2016-05-18 18:04:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 18:04:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:16:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:16:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:17:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:19:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:20:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:20:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:20:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:20:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:21:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:21:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:21:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:21:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:21:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:23:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:23:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:23:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:23:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:24:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:25:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:25:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:25:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:25:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:25:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:35:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:35:03 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:35:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:35:22 --> Severity: Notice  --> Undefined variable: total D:\wamp\www\parking\application\views\admin\parking.php 145
ERROR - 2016-05-18 19:35:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:35:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:35:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:35:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:35:56 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:35:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:35:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:36:00 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:36:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:36:02 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:36:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:36:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:36:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-18 19:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-18 19:36:06 --> Severity: Notice  --> Undefined variable: start_time D:\wamp\www\parking\application\views\admin\parking_form.php 135
ERROR - 2016-05-18 19:36:06 --> Severity: Notice  --> Undefined variable: end_time D:\wamp\www\parking\application\views\admin\parking_form.php 143
ERROR - 2016-05-18 19:36:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-18 19:36:07 --> 404 Page Not Found --> admin/www.google-analytics.com
ERROR - 2016-05-18 19:36:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
