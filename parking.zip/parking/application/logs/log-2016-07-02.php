<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-07-02 21:29:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:29:46 --> Unable to select database: parking
ERROR - 2016-07-02 21:31:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:31:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-07-02 21:32:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-07-02 21:32:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-07-02 21:32:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-07-02 21:32:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-07-02 21:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-07-02 21:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\parking\system\database\drivers\mysql\mysql_driver.php 91
