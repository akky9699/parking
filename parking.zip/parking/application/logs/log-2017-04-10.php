<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2017-04-10 17:58:53 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\parking\system\core\Common.php 257
ERROR - 2017-04-10 17:58:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 17:58:54 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: The requested name is valid, but no data of the requested type was found.  C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 17:58:54 --> Severity: Warning  --> mysql_pconnect(): php_network_getaddresses: getaddrinfo failed: The requested name is valid, but no data of the requested type was found.  C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 17:58:54 --> Unable to connect to the database
ERROR - 2017-04-10 18:08:17 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\parking\system\core\Common.php 257
ERROR - 2017-04-10 18:08:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:09:23 --> Severity: Notice  --> Only variable references should be returned by reference C:\xampp\htdocs\parking\system\core\Common.php 257
ERROR - 2017-04-10 18:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:10:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:11:06 --> 404 Page Not Found --> admin_theme
ERROR - 2017-04-10 18:11:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2017-04-10 18:11:08 --> 404 Page Not Found --> admin_theme
ERROR - 2017-04-10 18:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:11:12 --> 404 Page Not Found --> admin_theme
ERROR - 2017-04-10 18:11:12 --> 404 Page Not Found --> admin/www.google-analytics.com
ERROR - 2017-04-10 18:11:12 --> 404 Page Not Found --> admin_theme
ERROR - 2017-04-10 18:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:11:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2017-04-10 18:25:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead C:\xampp\htdocs\parking\system\database\drivers\mysql\mysql_driver.php 91
