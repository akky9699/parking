<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-03 11:43:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 11:43:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 11:43:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 12:52:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 12:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 12:52:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:39 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 12:52:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 12:52:41 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 12:52:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:44:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-03 14:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 14:47:06 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 14:47:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 14:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 14:47:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:23 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 14:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:33 --> 404 Page Not Found --> banner/www.google-analytics.com
ERROR - 2016-05-03 14:47:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:47:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 14:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:53:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 14:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 14:53:56 --> 404 Page Not Found --> home/www.google-analytics.com
ERROR - 2016-05-03 14:54:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-03 15:01:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:01:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-03 15:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:01:43 --> 404 Page Not Found --> home/www.google-analytics.com
ERROR - 2016-05-03 15:01:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:01:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-03 15:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:01:51 --> 404 Page Not Found --> home/www.google-analytics.com
ERROR - 2016-05-03 15:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:02:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:02:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:02:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-03 15:02:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:02:42 --> 404 Page Not Found --> home/www.google-analytics.com
ERROR - 2016-05-03 15:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:03:01 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:03:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:03:05 --> 404 Page Not Found --> banner/www.google-analytics.com
ERROR - 2016-05-03 15:03:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:03:12 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:03:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:03:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:03:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-03 15:04:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:04:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:06:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-03 15:06:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:06:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:09:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:09:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-03 15:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:21:07 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:21:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:21:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:21:12 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-03 15:22:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:22:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:22:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:22:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:22:28 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:22:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:22:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:22:36 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-03 15:22:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:03 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:10 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-03 15:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:23:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:25 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:23:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:28 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-03 15:23:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:23:33 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 15:24:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:24:19 --> You did not select a file to upload.
ERROR - 2016-05-03 15:25:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:25:02 --> You did not select a file to upload.
ERROR - 2016-05-03 15:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 15:25:20 --> You did not select a file to upload.
ERROR - 2016-05-03 19:07:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:07:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:13:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:13:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 19:13:13 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 19:13:15 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:52 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 19:58:52 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 19:58:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:58:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:58:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 19:58:57 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 19:58:58 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 19:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 19:59:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 19:59:06 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 19:59:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-03 20:53:39 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 21:54:48 --> 404 Page Not Found --> super/data
ERROR - 2016-05-03 21:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 21:55:18 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 21:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 21:55:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 21:55:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 21:55:39 --> 404 Page Not Found --> banner/www.google-analytics.com
ERROR - 2016-05-03 21:55:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 21:55:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-03 21:55:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-03 21:56:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
