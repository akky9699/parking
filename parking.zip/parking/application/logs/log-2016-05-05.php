<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-05 17:21:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:21:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:21:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:21:57 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 17:21:58 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 17:22:04 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 17:22:05 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 17:22:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:22:31 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:22:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:22:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:22:39 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:22:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:22:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:22:49 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-05 17:29:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:29:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:29:58 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:01 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:03 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:38 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:42 --> 404 Page Not Found --> home/www.google-analytics.com
ERROR - 2016-05-05 17:30:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:50 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:56 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:30:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:33:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:33:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 17:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 17:33:18 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:09:13 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 18:09:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:09:13 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:10:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:10:47 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:10:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:10:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:10:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:10:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:27 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:28 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:12:28 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 18:12:28 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:12:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:12:44 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:13:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:13:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:13:06 --> 404 Page Not Found --> clients/www.google-analytics.com
ERROR - 2016-05-05 18:18:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:18:19 --> 404 Page Not Found --> clients/www.google-analytics.com
ERROR - 2016-05-05 18:29:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:29:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:29:50 --> 404 Page Not Found --> clients/www.google-analytics.com
ERROR - 2016-05-05 18:29:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:29:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:29:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:29:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:32:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 18:33:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:33:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:33:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:33:45 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:33:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:33:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:27 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:28 --> 404 Page Not Found --> banner/www.google-analytics.com
ERROR - 2016-05-05 18:34:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:48 --> 404 Page Not Found --> clients/www.google-analytics.com
ERROR - 2016-05-05 18:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:34:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:34:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:35:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:35:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:35:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:35:25 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:35:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:35:44 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 18:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:36:19 --> Severity: Notice  --> Undefined index: packages D:\wamp\www\boloco\application\controllers\super\packages.php 36
ERROR - 2016-05-05 18:36:19 --> Query error: Unknown column 'packages' in 'field list'
ERROR - 2016-05-05 18:36:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:36:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:36:33 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:37:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:37:08 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 18:37:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 18:37:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:37:21 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 18:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:37:24 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:43:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:43:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:45:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:45:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:46:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:46:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:47:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:47:18 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:47:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 18:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:49:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 18:49:15 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:50:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:50:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:50:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 18:53:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:53:22 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:53:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 18:53:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:53:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 18:53:38 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 18:58:04 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 18:58:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:04:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:04:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 19:04:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:10:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:10:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 19:10:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:11:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:11:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-05 19:11:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:15:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:15:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:25:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:25:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:30:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:30:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:30:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:30:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:30:51 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 91
ERROR - 2016-05-05 19:30:51 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 91
ERROR - 2016-05-05 19:30:51 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\application\controllers\super\packages.php 91
ERROR - 2016-05-05 19:30:51 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 92
ERROR - 2016-05-05 19:31:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:31:19 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:31:19 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:31:19 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:31:19 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 97
ERROR - 2016-05-05 19:31:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:31:36 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:31:36 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:31:36 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:31:36 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 97
ERROR - 2016-05-05 19:32:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:32:37 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 95
ERROR - 2016-05-05 19:32:37 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 100
ERROR - 2016-05-05 19:32:37 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 100
ERROR - 2016-05-05 19:32:37 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\application\controllers\super\packages.php 100
ERROR - 2016-05-05 19:32:37 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 101
ERROR - 2016-05-05 19:32:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:32:40 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 95
ERROR - 2016-05-05 19:32:40 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 100
ERROR - 2016-05-05 19:32:40 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 100
ERROR - 2016-05-05 19:32:40 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\application\controllers\super\packages.php 100
ERROR - 2016-05-05 19:32:40 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 101
ERROR - 2016-05-05 19:32:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:32:56 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 95
ERROR - 2016-05-05 19:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:33:17 --> Severity: Notice  --> Use of undefined constant id - assumed 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 95
ERROR - 2016-05-05 19:33:17 --> Severity: Warning  --> Illegal string offset 'id' D:\wamp\www\boloco\application\controllers\super\packages.php 95
ERROR - 2016-05-05 19:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:33:43 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:33:43 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\application\controllers\super\packages.php 96
ERROR - 2016-05-05 19:33:43 --> Severity: Warning  --> Illegal string offset 'values' D:\wamp\www\boloco\application\controllers\super\packages.php 97
ERROR - 2016-05-05 19:34:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:37:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:37:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:37:47 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:37:47 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:42:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:42:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:42:15 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:42:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:42:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:42:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:42:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:44:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:47:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:47:12 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:47:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:47:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:47:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:47:57 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:47:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:49:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:49:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:49:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:49:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:49:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:49:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:49:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:49:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:49:45 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:49:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:49:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:52:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:52:43 --> Severity: Notice  --> Undefined variable: values D:\wamp\www\boloco\application\controllers\super\packages.php 76
ERROR - 2016-05-05 19:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:53:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:53:20 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:53:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:53:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:53:25 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:53:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:54:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:54:14 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:54:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:55:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:55:10 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:55:10 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:55:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:55:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:55:20 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:55:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:55:22 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:55:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:57:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:57:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:12 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:57:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:57:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:57:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:17 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:57:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:57:39 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:57:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 19:57:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:57:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 19:57:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-05 19:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 19:58:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:00:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:00:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:00:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:05:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:05:13 --> Severity: Notice  --> Undefined index: content D:\wamp\www\boloco\application\views\super\add_packages.php 122
ERROR - 2016-05-05 20:05:13 --> Severity: Notice  --> Undefined index: content D:\wamp\www\boloco\application\views\super\add_packages.php 122
ERROR - 2016-05-05 20:05:13 --> Severity: Notice  --> Undefined index: content D:\wamp\www\boloco\application\views\super\add_packages.php 122
ERROR - 2016-05-05 20:05:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:05:14 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:05:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:05:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:05:35 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:07:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:07:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:07:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:08:52 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:08:59 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:15 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:09:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:09:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:09:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:09:55 --> 404 Page Not Found --> super/data
ERROR - 2016-05-05 20:09:56 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-05 20:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:13:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:13 --> 404 Page Not Found --> testimonial/www.google-analytics.com
ERROR - 2016-05-05 20:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:34 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:41 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:44 --> 404 Page Not Found --> clients/www.google-analytics.com
ERROR - 2016-05-05 20:14:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-05 20:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:14:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:15:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-05 20:15:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-05 20:16:53 --> 404 Page Not Found --> admin_theme
