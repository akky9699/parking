<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-04-23 11:41:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-23 11:41:41 --> Severity: Warning  --> mysql_pconnect(): No connection could be made because the target machine actively refused it.
 D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-23 11:41:41 --> Unable to connect to the database
ERROR - 2016-04-23 11:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-23 11:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-23 11:49:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-23 11:49:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-23 11:49:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-04-23 11:49:10 --> 404 Page Not Found --> super/data
ERROR - 2016-04-23 11:49:13 --> 404 Page Not Found --> super/assets
