<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-06 11:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:24:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:24:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:24:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:24:13 --> 404 Page Not Found --> super/data
ERROR - 2016-05-06 11:24:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:24:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:25:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:27:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:27:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:28:10 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:33:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:33:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:33:47 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:33:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:33:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:33:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:33:55 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 11:38:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:38:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:38:59 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 11:39:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:39:04 --> 404 Page Not Found --> super/data
ERROR - 2016-05-06 11:39:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 11:39:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:39:07 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:39:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:39:09 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:39:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:39:40 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:42:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:42:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:42:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:42:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:43:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:43:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:43:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:43:48 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 11:44:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:44:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:44:36 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:45:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:46:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:46:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:46:34 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:46:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:46:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:46:42 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 11:46:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:46:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:49:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 11:49:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 11:52:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:09:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:10:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:11:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:21:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:22:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:22:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:23:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:23:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:24:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:24:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:25:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:25:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:26:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:29:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:32:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:32:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:32:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:32:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:32:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:32:52 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:34:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:34:14 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\controllers\super\packages.php 131
ERROR - 2016-05-06 12:34:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:34:16 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:34:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:34:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:34:21 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:36:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:36:57 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:36:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:37:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:37:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:37:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:37:33 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:38:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:38:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:39:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:39:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:40:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:41:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:41:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:41:06 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:41:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:42:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:42:13 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 12:42:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:44:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:44:28 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:52 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:46:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:00 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:47:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:47:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:24 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:47:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:47:48 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:48:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:48:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:48:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:48:35 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:49:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:49:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:49:01 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:49:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:49:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:50:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:13 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:50:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:39 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:50:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:50:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:51:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:53:54 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:54:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:54:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:55:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:55:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:56:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 12:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:57:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:57:55 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:57:55 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 12:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:57:57 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:57:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 12:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:59:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 12:59:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 12:59:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 12:59:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 12:59:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 12:59:55 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:00:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:00:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:00:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:00:42 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:00:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:00:48 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:01:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:01:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:01:03 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:01:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:01:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:01:05 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:02:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:44 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:50 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:03:58 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:04:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:06:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:06:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:06:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:06:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:06:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:06:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:06:55 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:06:55 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:08:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:08:34 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:08:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:09:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:09:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:09:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:09:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:09:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:11:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:11:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:11:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:11:55 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:11:55 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:13:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:13:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:13:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:17 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:13:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:13:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:15:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:15:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:15:57 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 13:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:16:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:16:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:17:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:17:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:17:22 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:36:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:36:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:40:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:43:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:43:23 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:43:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 13:44:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:44:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:45:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:45:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 13:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:46:01 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:46:02 --> 404 Page Not Found --> packages/add_attributes
ERROR - 2016-05-06 13:50:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:50:17 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 13:50:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:50:18 --> 404 Page Not Found --> packages/add_questionaries
ERROR - 2016-05-06 13:51:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 13:51:28 --> Severity: Notice  --> Undefined variable: edit D:\wamp\www\boloco\application\controllers\super\packages.php 160
ERROR - 2016-05-06 13:51:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:32:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:40:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:40:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:40:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:40:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:45:39 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\question_form.php 30
ERROR - 2016-05-06 14:45:39 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\question_form.php 31
ERROR - 2016-05-06 14:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:45:40 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:46:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:46:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:46:05 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:49:05 --> Severity: Notice  --> Undefined variable: type D:\wamp\www\boloco\application\views\super\question_form.php 41
ERROR - 2016-05-06 14:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:49:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:49:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:49:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:49:35 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:51:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:51:05 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:51:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:51:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:51:08 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:51:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:53:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:53:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:53:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:53:48 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:54:01 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:54:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:54:32 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:54:32 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:54:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:54:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:54:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:56:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:56:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:57:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:58:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:58:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:58:34 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:58:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 14:58:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 14:58:52 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 14:58:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:01:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:01:59 --> Severity: Notice  --> Undefined variable: order D:\wamp\www\boloco\application\views\super\question_form.php 49
ERROR - 2016-05-06 15:02:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:02:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:02:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:02:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:02:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:02:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:02:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:02:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:02:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:02:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:02:37 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:04:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:04:11 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:04:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:04:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:04:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:04:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:04:31 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:04:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:04:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:04:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:04:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:05:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:05:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:05:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:05:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:05:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:05:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:05:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:06:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:06:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:06:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:06:53 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:07:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:07:17 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 15:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:07:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:07:18 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 15:07:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 15:07:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:07:38 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 15:07:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:07:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 15:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:07:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:07:58 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:11:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:13 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:11:14 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:11:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:44 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:11:45 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:12:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:32 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 106
ERROR - 2016-05-06 15:12:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:12:34 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:14:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:05 --> Severity: Notice  --> Undefined variable: val D:\wamp\www\boloco\application\views\super\question_form.php 122
ERROR - 2016-05-06 15:14:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:14:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:14:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:14:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:15:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:15:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:15:25 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:16:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:16:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:16:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:17:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:17:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:17:13 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:18:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:18:15 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 15:19:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:16 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 15:19:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:22 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 15:19:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:23 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\question_form.php 19
ERROR - 2016-05-06 15:19:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:24 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:19:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:27 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\question_form.php 19
ERROR - 2016-05-06 15:19:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:19:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:19:52 --> Severity: Warning  --> Missing argument 1 for packages::add_questionaries() D:\wamp\www\boloco\application\controllers\super\packages.php 156
ERROR - 2016-05-06 15:19:52 --> Severity: Notice  --> Undefined variable: edit D:\wamp\www\boloco\application\controllers\super\packages.php 160
ERROR - 2016-05-06 15:21:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:21:43 --> Severity: Notice  --> Undefined variable: edit D:\wamp\www\boloco\application\controllers\super\packages.php 160
ERROR - 2016-05-06 15:21:43 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\question_form.php 19
ERROR - 2016-05-06 15:21:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:21:44 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:21:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:21:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 15:21:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:21:47 --> Severity: Notice  --> Undefined variable: edit D:\wamp\www\boloco\application\controllers\super\packages.php 160
ERROR - 2016-05-06 15:21:47 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\question_form.php 19
ERROR - 2016-05-06 15:21:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:21:48 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:22:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:22:21 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\question_form.php 19
ERROR - 2016-05-06 15:22:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:22:22 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:22:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:22:35 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 158
ERROR - 2016-05-06 15:24:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:24:29 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 158
ERROR - 2016-05-06 15:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:24:38 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 158
ERROR - 2016-05-06 15:24:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:24:51 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 158
ERROR - 2016-05-06 15:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:24:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:25:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:25:05 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\question_form.php 19
ERROR - 2016-05-06 15:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:25:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:26:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:26:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:26:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:26:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:26:59 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:27:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:30:35 --> Query error: Unknown column 'lable_id' in 'field list'
ERROR - 2016-05-06 15:31:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:31:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:31:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:31:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:31:32 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:37:13 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:37:41 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:37:44 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:37:47 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:37:54 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:38:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:38:15 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:38:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:38:39 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:39:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:39:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:39:52 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:39:58 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:40:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:40:46 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:41:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:41:01 --> 404 Page Not Found --> super/view_questionries
ERROR - 2016-05-06 15:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:41:09 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 15:41:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:41:25 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 158
ERROR - 2016-05-06 15:41:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 15:47:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:47:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 15:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:47:55 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 15:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:48:01 --> Severity: Notice  --> Undefined index: sub_category_id D:\wamp\www\boloco\application\controllers\super\packages.php 210
ERROR - 2016-05-06 15:48:01 --> Query error: Table 'boloco.master_property_type' doesn't exist
ERROR - 2016-05-06 15:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:53:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:53:02 --> Query error: Unknown column 'q.question_id' in 'where clause'
ERROR - 2016-05-06 15:53:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:53:34 --> Query error: Unknown column 'q.question_id' in 'where clause'
ERROR - 2016-05-06 15:53:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 15:54:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:07:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:07:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:07:33 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:10:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:10:46 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\view_questions.php 44
ERROR - 2016-05-06 16:10:46 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\view_questions.php 44
ERROR - 2016-05-06 16:10:46 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\view_questions.php 44
ERROR - 2016-05-06 16:10:46 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\view_questions.php 44
ERROR - 2016-05-06 16:10:46 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\view_questions.php 44
ERROR - 2016-05-06 16:10:46 --> 404 Page Not Found --> upload
ERROR - 2016-05-06 16:10:46 --> 404 Page Not Found --> upload
ERROR - 2016-05-06 16:10:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:10:47 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:11:16 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:12:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:12:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:12:09 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:15:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:15:30 --> Severity: Notice  --> Undefined variable: package_id D:\wamp\www\boloco\application\views\super\view_questions.php 16
ERROR - 2016-05-06 16:15:30 --> Severity: Notice  --> Undefined variable: id D:\wamp\www\boloco\application\views\super\view_questions.php 19
ERROR - 2016-05-06 16:15:30 --> Severity: Notice  --> Undefined variable: type_array D:\wamp\www\boloco\application\views\super\view_questions.php 32
ERROR - 2016-05-06 16:15:30 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\wamp\www\boloco\system\helpers\form_helper.php 331
ERROR - 2016-05-06 16:15:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:15:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:16:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:16:09 --> Severity: Notice  --> Undefined variable: type_array D:\wamp\www\boloco\application\views\super\view_questions.php 25
ERROR - 2016-05-06 16:16:09 --> Severity: Warning  --> Invalid argument supplied for foreach() D:\wamp\www\boloco\system\helpers\form_helper.php 331
ERROR - 2016-05-06 16:16:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:16:10 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:16:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:17:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:17:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:17:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:17:58 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:18:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:18:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:18:17 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:19:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:19:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:19:11 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:19:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:19:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:19:32 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:19:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:22:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:22:19 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:22:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:22:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:22:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:22:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:22:34 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:23:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:23:55 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:23:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:25:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:28:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:09 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:28:33 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:28:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:28:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:28:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:37 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:28:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:28:44 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:33:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:33:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:33:04 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:33:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:33:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:33:17 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:33:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:33:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:33:21 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:33:21 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\views\super\view_questions.php 51
ERROR - 2016-05-06 16:33:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:33:22 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:34:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:34:13 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:34:13 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\views\super\view_questions.php 51
ERROR - 2016-05-06 16:34:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:34:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:34:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:34:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:34:19 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:34:19 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\views\super\view_questions.php 51
ERROR - 2016-05-06 16:34:20 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:34:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:35:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:35:43 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:35:44 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:35:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:35:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:35:45 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:35:46 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:35:46 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:35:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:35:48 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:35:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:35:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:35:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:35:51 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:35:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:35:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:35:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:35:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:35:58 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:36:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:36:02 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:36:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:36:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:36:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 16:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:36:31 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:36:31 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:37:00 --> Severity: Notice  --> Undefined index: package_id D:\wamp\www\boloco\application\controllers\super\packages.php 207
ERROR - 2016-05-06 16:37:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:37:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:37:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:37:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:37:08 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:37:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:37:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:40:38 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 16:41:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 16:41:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:08 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:41:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:17 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:41:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:41:24 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:42:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:42:23 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:42:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:42:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:43:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:43:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:43:46 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 16:44:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:44:12 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 16:45:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:45:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 16:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:45:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:45:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:45:16 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:45:21 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:50:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:50:55 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 16:51:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:54:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 16:54:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:01:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:02:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:02:10 --> Severity: Notice  --> Undefined index: values D:\wamp\www\boloco\application\views\super\view_questions.php 101
ERROR - 2016-05-06 17:02:10 --> Severity: Notice  --> Undefined index: values D:\wamp\www\boloco\application\views\super\view_questions.php 101
ERROR - 2016-05-06 17:02:10 --> Severity: Notice  --> Undefined index: values D:\wamp\www\boloco\application\views\super\view_questions.php 101
ERROR - 2016-05-06 17:02:10 --> Severity: Notice  --> Undefined index: values D:\wamp\www\boloco\application\views\super\view_questions.php 101
ERROR - 2016-05-06 17:02:10 --> Severity: Notice  --> Undefined index: values D:\wamp\www\boloco\application\views\super\view_questions.php 101
ERROR - 2016-05-06 17:02:10 --> Severity: Notice  --> Undefined index: values D:\wamp\www\boloco\application\views\super\view_questions.php 101
ERROR - 2016-05-06 17:02:10 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:02:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:02:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:03:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:04:27 --> Severity: Notice  --> Undefined variable: package_id D:\wamp\www\boloco\application\views\super\question_form.php 29
ERROR - 2016-05-06 17:04:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:04:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:04:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:04:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:04:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:24 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:06:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:06:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:07:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:08:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:08:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:08:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:08:30 --> Severity: Notice  --> Array to string conversion D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 612
ERROR - 2016-05-06 17:08:30 --> Query error: Unknown column 'fa_icon_id' in 'field list'
ERROR - 2016-05-06 17:09:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:10:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:10:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:11:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:12:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:12:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:12:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:20:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:20:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:05 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:21:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:21:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:21:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:22:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:22:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:23:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:23:22 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:24:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:24:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:24:15 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:24:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:26:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:30:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:31:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:31:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:31:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:31:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:31:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:36:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:36:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:36:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:36:11 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:36:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:37:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:37:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:37:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:37:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:37:53 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:37:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:37:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:38:01 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:38:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:39:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:39:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:39:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:40:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:40:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:40:33 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:41:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:46 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:41:48 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:41:48 --> 404 Page Not Found --> super/data
ERROR - 2016-05-06 17:41:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:42:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:42:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:42:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:43:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 17:44:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:44:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:46:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:46:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:48:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:48:46 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:49:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:49:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:50:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:50:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:51:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:51:46 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-06 17:52:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:52:51 --> 404 Page Not Found --> super/data
ERROR - 2016-05-06 17:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:54:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 17:54:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:55:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:55:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:55:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:55:13 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 17:55:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:55:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:55:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:56:08 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 17:56:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:56:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 17:56:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 18:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:03:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:04:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:05:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:07:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:13:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:32:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:32:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:33:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:33:25 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:33:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:34:15 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:34:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:35:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:35:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:35:14 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 18:35:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:36:00 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 18:36:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:36:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:39:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:40:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:40:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:40:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:43:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:44:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:44:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:44:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:45:03 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:45:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 18:45:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:46:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:46:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:46:48 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:50:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:50:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:50:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:50:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:50:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:50:33 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 18:50:47 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:54:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:55:07 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:55:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:55:16 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:55:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:55:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:56:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 18:56:29 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 18:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 18:59:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:00:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:00:06 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:00:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:00:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:00:31 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:01:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:01:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:01:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:01:53 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:02:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:02:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:02:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:02:02 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:02:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:02:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:02:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:02:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:02:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:02:56 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:03:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:03:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:03:24 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:03:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:03:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:03:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:03:53 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:04:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:04:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:04:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:09 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:04:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:04:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:04:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:04:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:34 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:38 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:04:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:04:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:04:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:05:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:05:33 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:05:35 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:06:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:06:09 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:06:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:06:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:06:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:07:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:07:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:07:07 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:07:18 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:07:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:07:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:07:35 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:07:35 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:07:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:07:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:07:40 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:08:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:08:03 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:08:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:08:29 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:08:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:08:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:08:47 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:08:47 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:08:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:08:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:08:58 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:09:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:09:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:09:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:09:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:09:38 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:09:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:10:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:10:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:10:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:10:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:10:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:12:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:12:47 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:13:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:13:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:13:38 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:13:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:13:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:13:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:13:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:13:45 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:14:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:14:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:14:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:30 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:14:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:33 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:14:33 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:35 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:14:35 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:14:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:14:49 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:14:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:14:55 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-06 19:15:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:00 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:15:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:15:18 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:19:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:19:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:20:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:28:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:28:25 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:28:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:28:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:46:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:46:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:46:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:46:47 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-06 19:48:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:48:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:53:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:53:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:53:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 19:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:59:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:59:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 19:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 19:59:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 20:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:03:39 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 20:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:03:55 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-06 20:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:08:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-06 20:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:38:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-06 20:38:06 --> 404 Page Not Found --> packages/www.google-analytics.com
