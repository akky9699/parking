<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-04 12:50:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-04 20:35:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
