<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-07 11:36:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:36:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 11:36:33 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 11:36:33 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:37:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:37:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 11:37:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:37:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:37:16 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:40:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:40:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:40:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:41:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:41:11 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:41:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:41:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:41:37 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:41:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:41:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:41:50 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:44:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:24 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:44:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:44:44 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:45:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:45:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:45:46 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:48:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:48:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:48:19 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:48:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:49:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:49:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:51:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:51:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:51:18 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:51:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:51:20 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:52:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:52:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:52:40 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:58:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:28 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\controllers\super\packages.php 171
ERROR - 2016-05-07 11:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:58:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:32 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:34 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:58:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:58:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 11:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:59:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:03 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 11:59:04 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 11:59:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 11:59:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> css
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> css
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> css
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> css
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> js
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 11:59:33 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> js
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> js
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> js
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> js
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> js
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> js
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:01:40 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:06:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:06:04 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:06:05 --> 404 Page Not Found --> images
ERROR - 2016-05-07 12:06:37 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 12:06:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:06:59 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 12:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:17:14 --> Severity: Warning  --> include(include/footer.php): failed to open stream: No such file or directory D:\wamp\www\boloco\application\views\web\home.php 1073
ERROR - 2016-05-07 12:17:14 --> Severity: Warning  --> include(): Failed opening 'include/footer.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\boloco\application\views\web\home.php 1073
ERROR - 2016-05-07 12:17:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:19:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:19:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:19:39 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 12:19:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:19:42 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 12:19:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:19:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 12:20:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:20:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 12:20:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:20:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 12:20:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:20:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 12:22:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:22:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:23:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:24:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:25:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:25:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:33:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:33:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'option, `ph`.`hover_title` as title, `hover_content` as content
FROM (`packages`' at line 1
ERROR - 2016-05-07 12:34:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:34:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'option, `ph`.`hover_title` as title, `hover_content` as content
FROM (`packages`' at line 1
ERROR - 2016-05-07 12:34:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:34:26 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'option, `ph`.`hover_title` as title, `ph`.`hover_content` as content
FROM (`pack' at line 1
ERROR - 2016-05-07 12:35:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:35:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'option, `ph`.`hover_title` as title, `ph`.`hover_content` as content
FROM (`pack' at line 1
ERROR - 2016-05-07 12:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:36:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:36:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'option, `ph`.`hover_title` as title, `ph`.`hover_content` as content
FROM (`pack' at line 1
ERROR - 2016-05-07 12:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:37:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:40:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:44:21 --> Severity: Notice  --> Undefined index: package D:\wamp\www\boloco\application\controllers\home.php 21
ERROR - 2016-05-07 12:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:46:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:46:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:47:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:47:19 --> Severity: Notice  --> Undefined index: packge_option D:\wamp\www\boloco\application\controllers\home.php 15
ERROR - 2016-05-07 12:47:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:49:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:50:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:52:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:52:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:52:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:53:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:53:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:55:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:55:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:56:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:57:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:57:05 --> Severity: Notice  --> Undefined index: id D:\wamp\www\boloco\application\controllers\home.php 15
ERROR - 2016-05-07 12:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 12:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:03:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:04:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:04:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:05:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:06:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:09:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 356
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 356
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 356
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 356
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'title' D:\wamp\www\boloco\application\views\web\home.php 341
ERROR - 2016-05-07 13:24:00 --> Severity: Warning  --> Illegal string offset 'price' D:\wamp\www\boloco\application\views\web\home.php 342
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\web\home.php 346
ERROR - 2016-05-07 13:24:00 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 356
ERROR - 2016-05-07 13:25:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:26:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:26:48 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 361
ERROR - 2016-05-07 13:26:48 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 361
ERROR - 2016-05-07 13:26:48 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 361
ERROR - 2016-05-07 13:26:48 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 361
ERROR - 2016-05-07 13:26:48 --> Severity: Notice  --> Use of undefined constant content - assumed 'content' D:\wamp\www\boloco\application\views\web\home.php 361
ERROR - 2016-05-07 13:27:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:35:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:40:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:40:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:41:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:42:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:43:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:44:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:49:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:52:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:53:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 13:57:31 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:01:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:01:05 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:02:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:02:42 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:03:27 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:04:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:04:27 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:08:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:09:23 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:10:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:10:55 --> 404 Page Not Found --> web_theme
ERROR - 2016-05-07 14:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:49:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:31 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:49:31 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 14:49:32 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:49:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:49:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:52:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:52:45 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:52:52 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:55:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:56:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:56:13 --> 404 Page Not Found --> mylibo21
ERROR - 2016-05-07 14:57:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:58:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:58:36 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 14:58:37 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 14:58:47 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 14:58:48 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 14:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:58:58 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:01 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 14:59:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:59:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:59:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:32 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-07 14:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:34 --> 404 Page Not Found --> portfolio/www.google-analytics.com
ERROR - 2016-05-07 14:59:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:59:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:41 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 14:59:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 14:59:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 15:01:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:01:18 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 15:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:32:57 --> Query error: Table 'boloco.designer' doesn't exist
ERROR - 2016-05-07 15:33:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:33:20 --> Severity: Notice  --> Undefined index: title D:\wamp\www\boloco\application\views\super\designer.php 36
ERROR - 2016-05-07 15:33:20 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\designer.php 37
ERROR - 2016-05-07 15:33:21 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 15:33:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:33:25 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:34:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:34:32 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:34:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:34:47 --> Severity: Notice  --> Undefined index: title D:\wamp\www\boloco\application\views\super\designer.php 36
ERROR - 2016-05-07 15:34:47 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\designer.php 37
ERROR - 2016-05-07 15:34:48 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 15:34:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 33
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: email D:\wamp\www\boloco\application\views\super\add_designer.php 48
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: mobile D:\wamp\www\boloco\application\views\super\add_designer.php 55
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: address D:\wamp\www\boloco\application\views\super\add_designer.php 63
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: country D:\wamp\www\boloco\application\views\super\add_designer.php 71
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: state D:\wamp\www\boloco\application\views\super\add_designer.php 80
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: city D:\wamp\www\boloco\application\views\super\add_designer.php 89
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: pincode D:\wamp\www\boloco\application\views\super\add_designer.php 96
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 104
ERROR - 2016-05-07 15:34:50 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 105
ERROR - 2016-05-07 15:34:50 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:35:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:35:53 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 33
ERROR - 2016-05-07 15:35:53 --> Severity: Notice  --> Undefined variable: mobile D:\wamp\www\boloco\application\views\super\add_designer.php 55
ERROR - 2016-05-07 15:35:53 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 104
ERROR - 2016-05-07 15:35:53 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 105
ERROR - 2016-05-07 15:35:53 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:36:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:36:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:36:40 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 33
ERROR - 2016-05-07 15:36:40 --> Severity: Notice  --> Undefined variable: mobile D:\wamp\www\boloco\application\views\super\add_designer.php 55
ERROR - 2016-05-07 15:36:40 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 104
ERROR - 2016-05-07 15:36:40 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 105
ERROR - 2016-05-07 15:36:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:36:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:36:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:36:55 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 33
ERROR - 2016-05-07 15:36:55 --> Severity: Notice  --> Undefined variable: mobile D:\wamp\www\boloco\application\views\super\add_designer.php 56
ERROR - 2016-05-07 15:36:55 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 105
ERROR - 2016-05-07 15:36:55 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 106
ERROR - 2016-05-07 15:36:55 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:36:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:38:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:38:03 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 33
ERROR - 2016-05-07 15:38:03 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 105
ERROR - 2016-05-07 15:38:03 --> Severity: Notice  --> Undefined variable: status D:\wamp\www\boloco\application\views\super\add_designer.php 106
ERROR - 2016-05-07 15:38:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:38:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:38:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:38:23 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 33
ERROR - 2016-05-07 15:38:24 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:38:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:38:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:38:48 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 41
ERROR - 2016-05-07 15:38:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:38:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:39:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:39:12 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 41
ERROR - 2016-05-07 15:39:13 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:39:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:39:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:39:25 --> Severity: Notice  --> Undefined variable: password D:\wamp\www\boloco\application\views\super\add_designer.php 41
ERROR - 2016-05-07 15:39:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:39:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:39:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:39:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:39:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:39:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:40:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:40:02 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 15:40:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:40:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:40:06 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:40:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:40:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:40:18 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:40:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:40:37 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:40:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:41:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:41:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:41:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:41:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:41:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:41:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 15:44:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:44:03 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:44:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:44:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:44:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:44:46 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:53:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:55:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:55:20 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 15:55:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:55:56 --> Query error: Unknown column 'status' in 'field list'
ERROR - 2016-05-07 15:56:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:57:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:57:21 --> Query error: Unknown column 'add_by' in 'field list'
ERROR - 2016-05-07 15:57:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:57:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:57:53 --> Severity: Notice  --> Undefined index: title D:\wamp\www\boloco\application\views\super\designer.php 36
ERROR - 2016-05-07 15:57:53 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\views\super\designer.php 37
ERROR - 2016-05-07 15:57:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 15:59:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 15:59:03 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:06:47 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:11:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:11:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:11:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:11:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:11:18 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:11:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:11:25 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:12:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:12:34 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:12:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:12:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:12:37 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:16:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:21:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:23:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:23:53 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 16:23:54 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:23:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:23:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:23:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:23:59 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:20 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:24:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:38 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:24:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:24:45 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:07 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:25:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:12 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:25:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:14 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:25:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:48 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:25:53 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:26:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:26:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:26:39 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:26:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:26:43 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:27:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:12 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:27:12 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 16:27:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:27:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:17 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:27:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:48 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:27:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:27:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:29:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:30:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:30:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:31:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:31:26 --> Severity: Notice  --> Undefined index: username D:\wamp\www\boloco\application\controllers\designer\login.php 22
ERROR - 2016-05-07 16:31:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:39 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:32:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:32:54 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 16:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:33:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:33:01 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:33:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:33:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:33:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:33:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:34:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:34:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:34:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:35:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:35:29 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\controllers\super\designer.php 86
ERROR - 2016-05-07 16:35:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:35:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:36:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:36:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:36:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:36:36 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\controllers\super\designer.php 86
ERROR - 2016-05-07 16:36:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:36:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:36:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:36:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:36:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:37:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 16:37:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:37:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:37:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:37:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:37:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:38:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:38:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:38:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:41:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:41:16 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 16:41:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:41:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:41:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:41:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:42:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:42:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:42:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:43:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:43:38 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 16:43:38 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:43:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:43:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:45:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:45:30 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 16:45:31 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:45:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:47:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:47:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:27 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:47:28 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:47:28 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 16:47:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:47:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:47:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:07 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:48:08 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 16:48:09 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 16:48:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:50:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:50:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:50:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:50:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:52:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 16:52:19 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 16:52:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:06:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:07:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:07:21 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:07:22 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:08:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:08:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:15 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:08:16 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 17:08:17 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 17:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:08:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:08:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:08:59 --> Severity: Warning  --> include(mail_header.php): failed to open stream: No such file or directory D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 1
ERROR - 2016-05-07 17:08:59 --> Severity: Warning  --> include(): Failed opening 'mail_header.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 1
ERROR - 2016-05-07 17:08:59 --> Severity: Warning  --> include(mail_footer.php): failed to open stream: No such file or directory D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 20
ERROR - 2016-05-07 17:08:59 --> Severity: Warning  --> include(): Failed opening 'mail_footer.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 20
ERROR - 2016-05-07 17:08:59 --> Query error: Table 'boloco.email_config' doesn't exist
ERROR - 2016-05-07 17:11:02 --> 404 Page Not Found --> supoer
ERROR - 2016-05-07 17:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:11:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:11:08 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:11:09 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:11:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:11:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:15:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:15:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:15:33 --> Severity: Warning  --> include(mail_header.php): failed to open stream: No such file or directory D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 1
ERROR - 2016-05-07 17:15:33 --> Severity: Warning  --> include(): Failed opening 'mail_header.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 1
ERROR - 2016-05-07 17:15:33 --> Severity: Warning  --> include(mail_footer.php): failed to open stream: No such file or directory D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 20
ERROR - 2016-05-07 17:15:33 --> Severity: Warning  --> include(): Failed opening 'mail_footer.php' for inclusion (include_path='.;C:\php\pear') D:\wamp\www\boloco\application\views\mail_template\designer_forgotpassword.php 20
ERROR - 2016-05-07 17:16:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:18:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:29 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:18:30 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:18:31 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:18:32 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:18:32 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 17:20:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:20:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:21:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:23:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:23:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:24:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:24:50 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:24:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:24:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:25:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:26:22 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:26:29 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:27:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:27:10 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:28:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:28:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:28:35 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:28:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:41:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:41:45 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:41:48 --> 404 Page Not Found --> super/myprofile
ERROR - 2016-05-07 17:42:33 --> 404 Page Not Found --> super/myprofile
ERROR - 2016-05-07 17:43:04 --> 404 Page Not Found --> super/myprofile
ERROR - 2016-05-07 17:43:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:43:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:43:31 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:43:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 5
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 6
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 7
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 8
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 9
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 11
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 12
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 13
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 14
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 17:43:41 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 16
ERROR - 2016-05-07 17:43:41 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:44:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:44:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 5
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 6
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 7
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 8
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 9
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 11
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 12
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 13
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 14
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 17:44:34 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 16
ERROR - 2016-05-07 17:44:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:44:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 5
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 6
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 7
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 8
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 9
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 11
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 12
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 13
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 14
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 17:45:11 --> Severity: Notice  --> Undefined offset: 0 D:\wamp\www\boloco\application\views\super\my_profile.php 16
ERROR - 2016-05-07 17:45:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:46:02 --> Severity: Notice  --> Undefined index: address D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 17:46:02 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 17:46:03 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:46:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:46:15 --> Severity: Notice  --> Undefined index: address D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 17:46:15 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 17:46:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:46:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:46:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:47:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:47:17 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:49:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:49:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:52:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:52:13 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:52:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:52:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 17:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:53:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:54:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:54:18 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 17:54:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:54:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:54:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:56:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:56:30 --> Severity: Notice  --> Undefined index: username D:\wamp\www\boloco\application\controllers\super\my_profile.php 47
ERROR - 2016-05-07 17:56:30 --> Query error: Unknown column 'username' in 'field list'
ERROR - 2016-05-07 17:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:56:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:57:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:03 --> Severity: Notice  --> Undefined index: image D:\wamp\www\boloco\application\controllers\super\designer.php 86
ERROR - 2016-05-07 17:57:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:57:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:07 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:57:07 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:57:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:57:12 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:57:12 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:57:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:18 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:57:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:57:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:58:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:01 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:03 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 17:58:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:58:06 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:58:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:58:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 17:58:52 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 17:58:53 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 17:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 17:58:56 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:00:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:00:44 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:00:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:00:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:48 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:00:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:01:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:01:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:03:38 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:03:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:03:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:03:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:16 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:17 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:07:17 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 18:07:18 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:07:20 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:07:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:07:54 --> Severity: Notice  --> Undefined index: address1 D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 18:07:54 --> Severity: Notice  --> Undefined index: active D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 18:07:54 --> Severity: Notice  --> Undefined index: user_name D:\wamp\www\boloco\application\views\super\my_profile.php 16
ERROR - 2016-05-07 18:07:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:08:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:08:13 --> Severity: Notice  --> Undefined index: address1 D:\wamp\www\boloco\application\views\super\my_profile.php 10
ERROR - 2016-05-07 18:08:13 --> Severity: Notice  --> Undefined index: active D:\wamp\www\boloco\application\views\super\my_profile.php 15
ERROR - 2016-05-07 18:08:13 --> Severity: Notice  --> Undefined index: user_name D:\wamp\www\boloco\application\views\super\my_profile.php 16
ERROR - 2016-05-07 18:08:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:08:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:08:24 --> Severity: Notice  --> Undefined index: address1 D:\wamp\www\boloco\application\views\designer\my_profile.php 10
ERROR - 2016-05-07 18:08:24 --> Severity: Notice  --> Undefined index: active D:\wamp\www\boloco\application\views\designer\my_profile.php 15
ERROR - 2016-05-07 18:08:24 --> Severity: Notice  --> Undefined index: user_name D:\wamp\www\boloco\application\views\designer\my_profile.php 16
ERROR - 2016-05-07 18:08:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:08:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:08:37 --> Severity: Notice  --> Undefined index: address1 D:\wamp\www\boloco\application\views\designer\my_profile.php 10
ERROR - 2016-05-07 18:08:37 --> Severity: Notice  --> Undefined index: active D:\wamp\www\boloco\application\views\designer\my_profile.php 15
ERROR - 2016-05-07 18:08:37 --> Severity: Notice  --> Undefined index: user_name D:\wamp\www\boloco\application\views\designer\my_profile.php 16
ERROR - 2016-05-07 18:08:38 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:09:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:09:46 --> Severity: Notice  --> Undefined index: address1 D:\wamp\www\boloco\application\views\designer\my_profile.php 10
ERROR - 2016-05-07 18:09:46 --> Severity: Notice  --> Undefined index: active D:\wamp\www\boloco\application\views\designer\my_profile.php 15
ERROR - 2016-05-07 18:09:46 --> Severity: Notice  --> Undefined index: user_name D:\wamp\www\boloco\application\views\designer\my_profile.php 16
ERROR - 2016-05-07 18:09:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:09:54 --> Severity: Notice  --> Undefined index: address1 D:\wamp\www\boloco\application\views\designer\my_profile.php 10
ERROR - 2016-05-07 18:09:54 --> Severity: Notice  --> Undefined index: active D:\wamp\www\boloco\application\views\designer\my_profile.php 15
ERROR - 2016-05-07 18:09:54 --> Severity: Notice  --> Undefined index: user_name D:\wamp\www\boloco\application\views\designer\my_profile.php 16
ERROR - 2016-05-07 18:09:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:11:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:11:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:11:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:11:27 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:12:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:23 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:12:24 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:12:25 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:12:41 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:12:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:12:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:12:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:12:50 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:13:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:13:49 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:14:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:14:04 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:14:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:14:12 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:15:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:15:18 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:16:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:16:31 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:16:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:16:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:16:37 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 18:16:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:16:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 18:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:16:58 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 18:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:17:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 18:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:18:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 18:18:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:18:20 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:18:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:18:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:21:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:22:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:22:24 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:23:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:23:17 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:23:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:23:31 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:24:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:24:20 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:25:42 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:26:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:28:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:28:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:28:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:28:46 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\controllers\designer\my_profile.php 54
ERROR - 2016-05-07 18:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:30:18 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\controllers\designer\my_profile.php 54
ERROR - 2016-05-07 18:30:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:30:27 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\controllers\designer\my_profile.php 54
ERROR - 2016-05-07 18:30:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:30:57 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\controllers\designer\my_profile.php 54
ERROR - 2016-05-07 18:31:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:31:03 --> Severity: Notice  --> Undefined index: status D:\wamp\www\boloco\application\controllers\designer\my_profile.php 54
ERROR - 2016-05-07 18:31:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:32:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:32:13 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:32:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:32:24 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:32:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:32:49 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-07 18:33:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:33:04 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:34:06 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:34:06 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 18:34:06 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:08 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:08 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:08 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:08 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:08 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:08 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:09 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:34:09 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 18:34:09 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:34:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:34:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:34:42 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:35:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:35:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:36:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:36:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:36:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:37:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:37:32 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-07 18:37:33 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-07 18:37:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:36 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:37:51 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:37:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:37:52 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:44:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:44:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:44:51 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:44:52 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:44:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:44:58 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:45:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:45:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 18:46:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:46:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:46:03 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-07 18:46:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:46:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:47:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:47:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:48:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:48:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:49:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:49:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:49:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:49:38 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:49:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:51:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:51:07 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:51:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:51:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:19 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:51:20 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:51:21 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:51:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:51:27 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:51:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:51 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:51:52 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:51:52 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:51:53 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:51:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:51:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:51:56 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:52:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:52:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:52:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:53:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:53:29 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:53:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:53:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:53:32 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:53:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:53:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:53:48 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:53:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:53:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:53:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:53:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 18:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:53:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:53:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:54:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:54:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:54:23 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:54:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:54:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:54:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:54:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:54:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:54:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:54:52 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:57:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:57:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:57:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:57:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:57:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:57:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:09 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:58:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:58:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:58:23 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:58:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:58:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:58:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:36 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:58:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:58:37 --> 404 Page Not Found --> super/data
ERROR - 2016-05-07 18:58:38 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-07 18:58:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:58:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:58:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-07 18:58:44 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-07 18:58:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:58:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-07 18:59:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:59:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-07 18:59:05 --> 404 Page Not Found --> packages/www.google-analytics.com
