<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-04-21 20:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:24:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:24:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:10 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:12 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-04-21 20:24:13 --> 404 Page Not Found --> super/data
ERROR - 2016-04-21 20:24:15 --> 404 Page Not Found --> super/assets
ERROR - 2016-04-21 20:24:22 --> 404 Page Not Found --> super/data
ERROR - 2016-04-21 20:24:36 --> 404 Page Not Found --> super/data
ERROR - 2016-04-21 20:24:37 --> 404 Page Not Found --> super/data
ERROR - 2016-04-21 20:25:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-04-21 20:25:07 --> 404 Page Not Found --> super/data
ERROR - 2016-04-21 20:25:12 --> 404 Page Not Found --> super/data
ERROR - 2016-04-21 20:25:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:25:32 --> 404 Page Not Found --> admin_theme
ERROR - 2016-04-21 20:25:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-04-21 20:25:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:25:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-04-21 20:25:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:25:44 --> 404 Page Not Found --> home/www.google-analytics.com
ERROR - 2016-04-21 20:30:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:30:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-04-21 20:30:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-04-21 20:30:13 --> 404 Page Not Found --> home/www.google-analytics.com
