<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-09 11:12:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:47 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 11:12:48 --> 404 Page Not Found --> super/data
ERROR - 2016-05-09 11:12:50 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:55 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:12:56 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 11:12:56 --> 404 Page Not Found --> super/data
ERROR - 2016-05-09 11:12:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:12:58 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 11:13:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:13:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:13:59 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 11:13:59 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-09 11:14:00 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 11:16:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:16:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 11:16:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:16:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:16:47 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 11:16:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:16:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 11:16:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:16:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead D:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 11:16:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 11:59:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:00:05 --> 404 Page Not Found --> admin
ERROR - 2016-05-09 12:00:12 --> 404 Page Not Found --> admin
ERROR - 2016-05-09 12:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:02:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:02:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:11 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:02:15 --> 404 Page Not Found --> super/data
ERROR - 2016-05-09 12:02:15 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 12:02:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:02:21 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:02:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:02:28 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:03:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:03:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:03:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:03:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:03:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:03:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:03:57 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:05:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:05:41 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:06:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:06:34 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:16:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:16:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:16:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:16:59 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:17:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:17:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:17:16 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:17:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:17:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:18:16 --> 404 Page Not Found --> login.html
ERROR - 2016-05-09 12:18:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:18:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:20:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:20:00 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:20:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:20:02 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:22:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:22:57 --> Severity: Warning  --> Invalid argument supplied for foreach() E:\wamp\www\boloco\system\helpers\form_helper.php 331
ERROR - 2016-05-09 12:22:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:23:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:23:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:23:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:23:31 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:25:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:25:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:09 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:25:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:21 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:25:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:25:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:25:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:26:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:26:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:26:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:26:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:27:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:35 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:27:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:27:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:27:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:28:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:02 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:11 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:28:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:16 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:28:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:17 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:28:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:28:22 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:29:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:29:50 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:29:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:29:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:29:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:29:54 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:18 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:30:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:30:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:25 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:30:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:30:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:30:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:30:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:32:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:32:33 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:32:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:32:47 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:32:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:32:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:34:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:34:07 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:34:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:34:59 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:35:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:35:20 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:35:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:35:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:35:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:35:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:20 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:31 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:50 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:54 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:36:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:36:57 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:37:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:37:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:37:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:37:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:37:15 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:37:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:37:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:38:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:38:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:38:05 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:39:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:09 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:39:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:39:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:39:19 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:39:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:39:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:39:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:27 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:39:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:32 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:39:34 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:40:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:40:53 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:41:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:41:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:41:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:41:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:41:40 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:41:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:41:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:41:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:41:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:42:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:42:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:42:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:42:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 12:42:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:42:36 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:42:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:42:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:42:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:42:59 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 172
ERROR - 2016-05-09 12:42:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:42:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:43:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:43:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:43:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:43:04 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:48:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:48:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:48:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:48:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:48:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:48:50 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:49:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:49:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:49:59 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:50:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:50:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:50:46 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:50:46 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:52:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:52:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:52:31 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:52:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:53:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:53:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:53:37 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:53:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:53:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:53:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:53:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:53:56 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:53:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:54:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:10 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:54:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:31 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:54:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:54:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:54:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 12:54:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:54:59 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:55:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:04 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:55:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:08 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 12:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:30 --> Severity: Notice  --> Undefined index: type E:\wamp\www\boloco\application\controllers\super\packages.php 169
ERROR - 2016-05-09 12:55:30 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 172
ERROR - 2016-05-09 12:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 12:55:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 12:55:33 --> 404 Page Not Found --> packages/www.google-analytics.com
                                                                                                                                                                                                                                          ERROR - 2016-05-09 13:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:01:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:01:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:01:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:01:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:02:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:02:15 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:03:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:25 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:03:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:31 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 172
ERROR - 2016-05-09 13:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:32 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:34 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:03:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:03:59 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 172
ERROR - 2016-05-09 13:03:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:04:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:04:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:04:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:04:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:04:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:04:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:04:02 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:04:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:05:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:05:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:05:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:05:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:05:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:38 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 172
ERROR - 2016-05-09 13:05:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:05:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:05:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:05:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:50 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 172
ERROR - 2016-05-09 13:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:50 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:05:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:05:54 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:07:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:20 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:31 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:07:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:38 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:07:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:45 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 13:07:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:47 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:07:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:07:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:11:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:11:55 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:12:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:12:26 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:12:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:12:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:12:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:12:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:13:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:13:06 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:13:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:13:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:13:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 13:13:30 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:14:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:14:52 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:15:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:15:45 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 13:16:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:17:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:40:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:41:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:52:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:53:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:53:04 --> You did not select a file to upload.
ERROR - 2016-05-09 13:53:04 --> You did not select a file to upload.
ERROR - 2016-05-09 13:53:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:53:22 --> You did not select a file to upload.
ERROR - 2016-05-09 13:53:22 --> You did not select a file to upload.
ERROR - 2016-05-09 13:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:53:43 --> You did not select a file to upload.
ERROR - 2016-05-09 13:53:43 --> You did not select a file to upload.
ERROR - 2016-05-09 13:55:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:56:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:56:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:56:51 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 13:56:51 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 13:57:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:57:32 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 13:57:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:57:42 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 13:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:57:57 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 13:58:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:58:54 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 13:59:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 13:59:09 --> The image you are attempting to upload exceedes the maximum height or width.
ERROR - 2016-05-09 14:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 14:04:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 14:05:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 14:08:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 14:08:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 14:09:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 14:10:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:06:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:07:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:09:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:09:45 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-09 15:09:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:09:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:09:50 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:09:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:09:54 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:12:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:12:05 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:05 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:06 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:06 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:12:06 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:12:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:12:18 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:18 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:21 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:21 --> 404 Page Not Found --> upload
ERROR - 2016-05-09 15:12:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:12:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:12:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 15:12:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:12:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:12:52 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:12:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 15:13:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:13:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:13:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:13:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 15:14:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 15:15:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:15:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:15:27 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:15:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 15:15:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:15:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:15:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:16:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:14 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-09 15:17:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:15 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:17:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:17 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:17:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:39 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-09 15:17:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:40 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:17:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:47 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-09 15:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:47 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:17:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:17:49 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:00 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-09 15:18:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:01 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:02 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:18:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:18:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:29 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 15:18:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:31 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:18:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:34 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:18:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:18:48 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:27:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:27:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:27:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:28:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:28:21 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:28:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:28:54 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:31:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:31:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:35:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:39:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:39:27 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:39:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:39:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:39:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:40:24 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:41:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:43:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:43:34 --> Severity: Notice  --> Undefined index: values E:\wamp\www\boloco\application\controllers\super\packages.php 292
ERROR - 2016-05-09 15:43:34 --> Severity: Notice  --> Undefined variable: sub_id E:\wamp\www\boloco\application\views\super\question_form.php 85
ERROR - 2016-05-09 15:43:34 --> Severity: Notice  --> Undefined variable: name1 E:\wamp\www\boloco\application\views\super\question_form.php 90
ERROR - 2016-05-09 15:43:34 --> Severity: Notice  --> Undefined variable: name2 E:\wamp\www\boloco\application\views\super\question_form.php 96
ERROR - 2016-05-09 15:43:34 --> Severity: Notice  --> Undefined variable: min E:\wamp\www\boloco\application\views\super\question_form.php 102
ERROR - 2016-05-09 15:43:34 --> Severity: Notice  --> Undefined variable: max E:\wamp\www\boloco\application\views\super\question_form.php 108
ERROR - 2016-05-09 15:43:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:43:35 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:44:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:44:29 --> Severity: Notice  --> Undefined index: values E:\wamp\www\boloco\application\controllers\super\packages.php 292
ERROR - 2016-05-09 15:44:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:44:30 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:44:43 --> Severity: Notice  --> Undefined index: values E:\wamp\www\boloco\application\controllers\super\packages.php 292
ERROR - 2016-05-09 15:44:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:44:43 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:45:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:12 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:20 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:45:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:30 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:45:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:31 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:45:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:45:32 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:13 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:20 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:46:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:25 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:46:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:25 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:32 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:36 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:46:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:37 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:38 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:41 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 217
ERROR - 2016-05-09 15:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:42 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:46:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:46:46 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:47:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:47:54 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:48:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:08 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:48:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:21 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:48:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-09 15:48:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 15:48:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:48:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 15:49:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:49:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:49:01 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:53:29 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:53:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:53:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:53:57 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:54:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:54:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:54:10 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:54:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:54:55 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:55:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:55:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:55:21 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:56:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:56:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:56:45 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:57:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:57:37 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:58:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:11 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:42 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:49 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:52 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:58:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:58:56 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:59:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:59:11 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 15:59:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 15:59:21 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 15:59:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:00:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:00:29 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:00:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:01:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:01:13 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:02:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:02:49 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:03:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:03:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:03:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:03:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:03:33 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:03:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:03:36 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:34 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:06:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:38 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:44 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:06:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:45 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 16:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:06:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:07:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:07:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:07:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:07:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:07:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:07:57 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:07:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:00 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 16:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:02 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:05 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 16:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:08:07 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:09:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:49 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:50 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:09:50 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-09 16:09:51 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:57 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:09:58 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:09:58 --> 404 Page Not Found --> designer/data
ERROR - 2016-05-09 16:09:58 --> 404 Page Not Found --> designer/assets
ERROR - 2016-05-09 16:10:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:10:21 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:10:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:10:25 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 16:12:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:12:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:13:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:13:10 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:13:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:13:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:13:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:13:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:14:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:14:29 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:17:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:17:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:17:38 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 16:22:06 --> 404 Page Not Found --> super/customer
ERROR - 2016-05-09 16:22:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:22:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:22:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:24:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:24:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:26:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: fistname E:\wamp\www\boloco\application\views\super\customers.php 37
ERROR - 2016-05-09 16:26:25 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:26 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:26:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:26:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:29:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:29:32 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:29:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:29:33 --> 404 Page Not Found --> designer/www.google-analytics.com
ERROR - 2016-05-09 16:30:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:40 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:30:41 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:32:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:32:55 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:36:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:23 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:36:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:37 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:36:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:36:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:38:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:38:08 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:42:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:42:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:43:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:43:02 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:43:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:43:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:44:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:44:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:44:15 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:44:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:44:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:46:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:31 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:46:33 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:46:33 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:46:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:46:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 16:49:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:08 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:11 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:49:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:49:13 --> 404 Page Not Found --> customers/view
ERROR - 2016-05-09 16:49:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:29 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:49:30 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 16:53:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:13 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 16:53:14 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:30 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:43 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:02:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:57 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:02:58 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:03:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:03:02 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:05:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:05:07 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:05:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:05:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:05:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:05:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:05:49 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 17:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:06:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:06:40 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 17:06:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:41 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:06:42 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:09:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:23 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 17:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:26 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 17:09:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:30 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 17:09:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:09:37 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 17:10:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:34 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:10:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:10:35 --> 404 Page Not Found --> super/data
ERROR - 2016-05-09 17:10:35 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:23:40 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:40 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:40 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:40 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:40 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:40 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:43 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 17:23:44 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:23:44 --> 404 Page Not Found --> super/data
ERROR - 2016-05-09 17:23:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 17:23:45 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-09 17:23:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 17:23:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 17:23:51 --> 404 Page Not Found --> super/orders
ERROR - 2016-05-09 18:09:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:09:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:31:29 --> Severity: Notice  --> Undefined variable: sort_by E:\wamp\www\boloco\application\views\super\orders.php 54
ERROR - 2016-05-09 18:31:29 --> Severity: Notice  --> Undefined variable: sort_order E:\wamp\www\boloco\application\views\super\orders.php 54
ERROR - 2016-05-09 18:33:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:35:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:36:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 38
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 40
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 41
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 43
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 47
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 50
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 55
ERROR - 2016-05-09 18:36:18 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 57
ERROR - 2016-05-09 18:39:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:39:28 --> Severity: Notice  --> Trying to get property of non-object E:\wamp\www\boloco\application\views\super\orders.php 41
ERROR - 2016-05-09 18:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:40:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:40:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:40:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 18:40:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:40:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:46 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 18:40:46 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:46 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:40:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:41:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:00 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 18:41:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:41:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 18:41:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:41:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:24 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 18:41:25 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:41:25 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:43:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:43:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:43:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 18:43:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:43:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:43:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:43:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:43:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:43:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:43:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:45:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:02 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:45:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:45:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:07 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:45:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:45:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:08 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:45:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:45:09 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:47:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:47:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:47:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:47:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:47:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:47:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:47:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:47:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:47:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:47:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:47:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:48:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> Severity: Notice  --> Undefined variable: currency_session E:\wamp\www\boloco\application\helpers\formatting_helper.php 60
ERROR - 2016-05-09 18:48:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:48:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:48:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:48:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:55:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:55:58 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:55:59 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:55:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:55:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 18:56:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:56:20 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:57:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:57:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 18:59:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 18:59:17 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:00:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:00:35 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:02:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:02:34 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:02:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:03:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:03:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:03:17 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:04:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:04:44 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:05:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:05:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:05:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:05:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:05:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:05:30 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:05:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:05:53 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:05:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:06:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:06:04 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:06:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:06:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:06:20 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:06:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:06:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:06:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:06:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:06:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:06:50 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:06:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:07:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:07:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:07:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:07:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:07:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:07:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:07:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:07:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:07:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:10:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:10:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:10:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:10:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:17:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:24:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:24:22 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:25:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:25:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:25:15 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:25:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:25:35 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:25:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:25:37 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:25:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:25:40 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:25:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:25:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:26:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:26:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:26:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:26:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:26:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:26:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:27:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:27:07 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:27:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:27:33 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:30:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:30:04 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:30:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:30:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:30:23 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:30:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:37:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:37:18 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 19:37:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:37:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:37:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:37:22 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 19:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:37:23 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:37:24 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:38:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-09 19:38:01 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 19:38:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:04 --> 404 Page Not Found --> customers/www.google-analytics.com
ERROR - 2016-05-09 19:38:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:05 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-09 19:38:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:38:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:38:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:38:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:39:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:39:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:39:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:39:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:39:46 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:39:48 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:39:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:40:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:40:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:40:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:40:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:41:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:41:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:41:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:42:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:42:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:42:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:32 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:42:32 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:36 --> 404 Page Not Found --> admin
ERROR - 2016-05-09 19:42:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:42:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:42:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:42:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:43:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:46:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:46:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:46:29 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:46:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:48:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:48:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:48:19 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:48:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:48:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:48:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:48:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:48:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:50:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:50:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:50:06 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:50:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:50:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:50:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:50:29 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:50:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:50:47 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:50:48 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:50:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:51:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:51:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:51:10 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:10 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:51:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:51:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:51:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:51:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:38 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:51:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:51:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:51:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:51:58 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:52:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:52:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:52:03 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:52:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:53:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:53:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:53:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:53:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:53:24 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:53:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:53:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:53:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:53:41 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:53:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:54:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:54:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:54:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:24 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:54:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:54:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:38 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:54:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:54:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:50 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:54:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:54:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:54:51 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:54:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:55:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:55:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:55:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:55:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:57:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:57:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:57:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:57:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:57:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:57:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:57:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:57:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:58:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:17 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:58:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 19:58:47 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:50 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 19:58:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 19:58:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:01:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:18 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:01:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:01:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:43 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:01:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:01:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:50 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:01:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:01:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:01:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:01:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:01:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:00 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:02:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:02:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:13 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:02:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:02:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:03:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:27 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:03:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:03:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:39 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:03:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:03:44 --> 404 Page Not Found --> admin
ERROR - 2016-05-09 20:04:09 --> 404 Page Not Found --> admin
ERROR - 2016-05-09 20:04:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-09 20:04:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-09 20:04:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-09 20:04:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
