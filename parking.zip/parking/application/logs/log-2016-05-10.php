<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed'); ?>

ERROR - 2016-05-10 11:50:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 11:50:47 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:03:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:08:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:04 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 12:08:06 --> 404 Page Not Found --> super/data
ERROR - 2016-05-10 12:08:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:08:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:08:07 --> 404 Page Not Found --> super/assets
ERROR - 2016-05-10 12:08:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:08:19 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:08:20 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 12:09:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:09:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:09:12 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:09:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:09:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:09:14 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:10:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:11:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:11:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:11:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:11:21 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:11:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:11:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:11:40 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:11:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:12:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:12:35 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:12:36 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:13:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:13:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:13:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:14:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:14:04 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:14:05 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:23:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:23:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:23:11 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:23:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:23:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:23:55 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:23:56 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:23:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:24:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:24:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:24:16 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:24:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:25:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:25:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:25:29 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:27:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:27:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:27:17 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:27:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:27:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:27:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:27:53 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:27:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:28:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:28:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:28:23 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:28:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:29:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:29:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:29:01 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:29:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:31:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:31:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:31:13 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:31:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:31:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:31:54 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:34:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:34:01 --> Severity: Notice  --> Undefined variable: sub_id E:\wamp\www\boloco\application\views\super\question_form.php 77
ERROR - 2016-05-10 12:34:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:34:02 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:38:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:38:42 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:38:42 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:39:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:39:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:39:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:39:58 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:39:58 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 12:40:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:10 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:10 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:43:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:10 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:43:12 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:12 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:43:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:13 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:25 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:43:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:25 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:43:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:43:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:43:27 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:44:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:44:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:44:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:44:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:44:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:00 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:45:00 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:00 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:45:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:05 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:45:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:45:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:05 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:45:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:45:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:45:07 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:53:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:29 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:53:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:43 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:53:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:43 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:53:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:53:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:45 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:51 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:53:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:51 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:53:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:53 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:59 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:59 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:53:59 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:53:59 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:14 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:23 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:26 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:26 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:31 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:31 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:32 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:32 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:33 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:34 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:35 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:36 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:37 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:54:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:38 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:39 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:41 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:41 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:43 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:43 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:43 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:46 --> Severity: Notice  --> Undefined index: image E:\wamp\www\boloco\application\controllers\super\packages.php 216
ERROR - 2016-05-10 12:54:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:46 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:46 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 12:54:54 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:54:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:54 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 12:54:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:54:54 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:55:04 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:56:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:56:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:56:04 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 12:56:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:56:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 12:56:22 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 12:56:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:57:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:57:25 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 12:57:25 --> Query error: Unknown column 'order_id' in 'field list'
ERROR - 2016-05-10 12:57:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:57:41 --> Query error: Unknown column 'order_id' in 'field list'
ERROR - 2016-05-10 12:58:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:58:20 --> Severity: Warning  --> Attempt to assign property of non-object E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 12:58:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 12:58:50 --> Severity: Warning  --> Attempt to assign property of non-object E:\wamp\www\boloco\application\models\order_model.php 190
ERROR - 2016-05-10 12:59:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:00:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:00:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:00:56 --> Severity: Notice  --> Undefined variable: start_date E:\wamp\www\boloco\application\views\super\order.php 21
ERROR - 2016-05-10 13:00:56 --> Severity: Notice  --> Undefined variable: end_date E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:00:56 --> Severity: Notice  --> Undefined variable: name E:\wamp\www\boloco\application\views\super\order.php 33
ERROR - 2016-05-10 13:00:56 --> Severity: Notice  --> Undefined variable: order_number E:\wamp\www\boloco\application\views\super\order.php 39
ERROR - 2016-05-10 13:00:56 --> Severity: Notice  --> Undefined variable: orders E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:00:56 --> Severity: Warning  --> Invalid argument supplied for foreach() E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:00:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:00:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:00:57 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:06:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:06:25 --> Severity: Warning  --> Missing argument 2 for CI_DB_active_record::join(), called in E:\wamp\www\boloco\application\models\order_model.php on line 182 and defined E:\wamp\www\boloco\system\database\DB_active_rec.php 310
ERROR - 2016-05-10 13:06:25 --> Severity: Notice  --> Undefined variable: cond E:\wamp\www\boloco\system\database\DB_active_rec.php 331
ERROR - 2016-05-10 13:06:25 --> Severity: Notice  --> Undefined variable: cond E:\wamp\www\boloco\system\database\DB_active_rec.php 340
ERROR - 2016-05-10 13:06:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE `id` =  '14'' at line 4
ERROR - 2016-05-10 13:06:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:06:39 --> Query error: Column 'id' in where clause is ambiguous
ERROR - 2016-05-10 13:06:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:06:53 --> Severity: Notice  --> Array to string conversion E:\wamp\www\boloco\application\controllers\super\orders.php 101
ERROR - 2016-05-10 13:06:53 --> Severity: Notice  --> Undefined variable: Array E:\wamp\www\boloco\application\controllers\super\orders.php 101
ERROR - 2016-05-10 13:07:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:07:05 --> Severity: Notice  --> Array to string conversion E:\wamp\www\boloco\application\controllers\super\orders.php 101
ERROR - 2016-05-10 13:07:05 --> Severity: Notice  --> Undefined variable: Array E:\wamp\www\boloco\application\controllers\super\orders.php 101
ERROR - 2016-05-10 13:07:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:09:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:10:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:11:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:11:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:11:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:11:45 --> Severity: Notice  --> Undefined variable: start_date E:\wamp\www\boloco\application\views\super\order.php 21
ERROR - 2016-05-10 13:11:45 --> Severity: Notice  --> Undefined variable: end_date E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:11:45 --> Severity: Notice  --> Undefined variable: name E:\wamp\www\boloco\application\views\super\order.php 33
ERROR - 2016-05-10 13:11:45 --> Severity: Notice  --> Undefined variable: order_number E:\wamp\www\boloco\application\views\super\order.php 39
ERROR - 2016-05-10 13:11:45 --> Severity: Notice  --> Undefined variable: orders E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:11:45 --> Severity: Warning  --> Invalid argument supplied for foreach() E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:11:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:11:46 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:11:46 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:12:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:13:13 --> Severity: Notice  --> Undefined variable: start_date E:\wamp\www\boloco\application\views\super\order.php 21
ERROR - 2016-05-10 13:13:13 --> Severity: Notice  --> Undefined variable: end_date E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:13:13 --> Severity: Notice  --> Undefined variable: name E:\wamp\www\boloco\application\views\super\order.php 33
ERROR - 2016-05-10 13:13:13 --> Severity: Notice  --> Undefined variable: order_number E:\wamp\www\boloco\application\views\super\order.php 39
ERROR - 2016-05-10 13:13:13 --> Severity: Notice  --> Undefined variable: orders E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:13:13 --> Severity: Warning  --> Invalid argument supplied for foreach() E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:13:13 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:13:13 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:13:13 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:13:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:14:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:14:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:14:35 --> Severity: Notice  --> Undefined variable: start_date E:\wamp\www\boloco\application\views\super\order.php 21
ERROR - 2016-05-10 13:14:35 --> Severity: Notice  --> Undefined variable: end_date E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:14:35 --> Severity: Notice  --> Undefined variable: name E:\wamp\www\boloco\application\views\super\order.php 33
ERROR - 2016-05-10 13:14:35 --> Severity: Notice  --> Undefined variable: order_number E:\wamp\www\boloco\application\views\super\order.php 39
ERROR - 2016-05-10 13:14:35 --> Severity: Notice  --> Undefined variable: orders E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:14:35 --> Severity: Warning  --> Invalid argument supplied for foreach() E:\wamp\www\boloco\application\views\super\order.php 73
ERROR - 2016-05-10 13:14:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:14:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:14:36 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:15:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:15:52 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:15:53 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 13:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:25:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:25:15 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:25:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:25:15 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:25:15 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:25:15 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:25:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:25:16 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:26:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:26:18 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:26:18 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:26:19 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:26:19 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:27:02 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:27:03 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:27:03 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:27:03 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:27:03 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:28:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:28:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:28:07 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:28:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:28:08 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:30:50 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:30:50 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:30:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:30:50 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:10 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:10 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:11 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:31:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: id E:\wamp\www\boloco\application\models\order_model.php 184
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: order_number E:\wamp\www\boloco\application\views\super\order.php 4
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 5
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: subtotal E:\wamp\www\boloco\application\views\super\order.php 27
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: coupon_discount E:\wamp\www\boloco\application\views\super\order.php 34
ERROR - 2016-05-10 13:31:29 --> Severity: Notice  --> Undefined index: total E:\wamp\www\boloco\application\views\super\order.php 40
ERROR - 2016-05-10 13:31:29 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:31:29 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:33:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:33:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:33:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:33:08 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:34:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:34:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:34:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:34:31 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:35:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:35:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:35:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:35:31 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:36:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:36:21 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:36:30 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:36:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:36:31 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:37:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:37:11 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:37:11 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:37:11 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:37:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:37:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:37:25 --> 404 Page Not Found --> super/www.google-analytics.com
ERROR - 2016-05-10 13:37:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:37:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:37:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:37:28 --> 404 Page Not Found --> packages/www.google-analytics.com
ERROR - 2016-05-10 13:39:33 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:39:50 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:40:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:40:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:40:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:40:51 --> Severity: Notice  --> Undefined index: title E:\wamp\www\boloco\application\views\super\order.php 92
ERROR - 2016-05-10 13:40:51 --> Severity: Notice  --> Undefined index: price E:\wamp\www\boloco\application\views\super\order.php 101
ERROR - 2016-05-10 13:40:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:40:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:40:51 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:41:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:41:26 --> Severity: Notice  --> Undefined index: title E:\wamp\www\boloco\application\views\super\order.php 97
ERROR - 2016-05-10 13:41:26 --> Severity: Notice  --> Undefined index: price E:\wamp\www\boloco\application\views\super\order.php 106
ERROR - 2016-05-10 13:41:27 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:41:30 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:41:30 --> Severity: Notice  --> Undefined index: title E:\wamp\www\boloco\application\views\super\order.php 97
ERROR - 2016-05-10 13:41:30 --> Severity: Notice  --> Undefined index: price E:\wamp\www\boloco\application\views\super\order.php 106
ERROR - 2016-05-10 13:41:31 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:41:31 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:41:31 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:42:10 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:42:34 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:43:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:43:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:44:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:48:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:48:44 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:48:58 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:49:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:49:24 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:49:24 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:49:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:49:25 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:49:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:49:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:49:57 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:51:02 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:51:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:51:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:15 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:51:26 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:26 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:51:27 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:28 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:51:36 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:36 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:51:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:51:40 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:51:40 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:52:25 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:52:25 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:52:25 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:57:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:57:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:57:37 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:57:44 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:57:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:57:56 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:57:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:57:57 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:57:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:58:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:58:07 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:58:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:58:08 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:58:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:58:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:58:17 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:58:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:58:18 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:58:18 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:58:28 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 13:58:28 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 13:58:28 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 13:58:29 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:00:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:00:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:00:16 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:00:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:00:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:00:42 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:00:42 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:00:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:00:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:00:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:00:53 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:01:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:01:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:01:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:01:38 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:02:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:02:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:02:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:02:23 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:02:51 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:02:51 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:02:52 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:02:52 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:03:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:03:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:03:01 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:03:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:03:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:03:21 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:03:48 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:03:48 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:03:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:03:49 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:04:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:04:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:04:07 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:04:07 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:05:45 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:05:45 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:05:45 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:05:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:05:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:05:57 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:07:01 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:07:01 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:07:01 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:07:16 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:07:16 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:07:17 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:07:17 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:07:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:08:14 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:08:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:08:15 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:08:15 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:08:15 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:08:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:08:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:08:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:08:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:08:22 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:09:14 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:09:53 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:09:53 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:09:55 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:09:55 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:10:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:11:22 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 14:11:22 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 14:11:22 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 14:11:23 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:22:39 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:40 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 15:22:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:40 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:41 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:22:41 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:42 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 15:22:49 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:22:49 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:22:49 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 15:23:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:23:06 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:23:06 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 15:23:08 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:23:08 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:23:09 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:23:09 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 15:32:35 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> Severity: Notice  --> Undefined index: status E:\wamp\www\boloco\application\views\super\customers.php 39
ERROR - 2016-05-10 15:32:35 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:32:35 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 15:32:37 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:32:37 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:32:37 --> 404 Page Not Found --> www.google-analytics.com
ERROR - 2016-05-10 15:32:38 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:32:38 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:32:39 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:32:39 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 15:35:56 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:35:57 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:35:57 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:35:57 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 15:36:05 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:36:05 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:36:06 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:36:06 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 15:36:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:36:21 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:36:21 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:36:21 --> 404 Page Not Found --> orders/www.google-analytics.com
ERROR - 2016-05-10 15:37:20 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:37:20 --> 404 Page Not Found --> admin_theme
ERROR - 2016-05-10 15:37:23 --> Severity: 8192  --> mysql_pconnect(): The mysql extension is deprecated and will be removed in the future: use mysqli or PDO instead E:\wamp\www\boloco\system\database\drivers\mysql\mysql_driver.php 91
ERROR - 2016-05-10 15:37:24 --> 404 Page Not Found --> orders/www.google-analytics.com
