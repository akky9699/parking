<?php

class user_mod extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    // ******************************* START 'groups' table methods *****************

    public function getUserInfo($user_id) {
        $arr = $this->db->where('user_id', $user_id)->limit(1)
                        ->get('users_login')->result_array();

        $output = array();
        if (!empty($arr)) {
            $output = $arr[0];
        }

        return $output;
    }

    public function getUserInfoByEmail($email_id) {
        $table = 'user_account';
        $fieldArray = array();
        $where = "email_id='$email_id'";
        $limit = 1;

        $arr = $this->select($table, $fieldArray, $where, 1);

        $output = array();
        if (!empty($arr)) {
            $output = $arr[0];
        }

        return $output;
    }

    public function registerUser($arr, $SESSION_ARRAY) {
        $table = 'user_account';

        $current_time = CommonFunctions::currentTime();
        $current_date = CommonFunctions::currentDate('d-M-Y g:i:s A');

        $user_id = $this->generateUserId();

        $fieldArray = array();
        $fieldArray['user_id'] = $user_id;
        $fieldArray['plan'] = $arr['plan'];
        $fieldArray['name'] = $arr['name'];
        $fieldArray['mobile_no'] = $arr['mobile_no'];
        $fieldArray['email_id'] = $arr['email_id'];
        $fieldArray['password'] = $arr['password'];
        $fieldArray['transaction_password'] = $arr['transaction_password'];
        $fieldArray['sponser_id'] = $arr['sponser_id'];
        $fieldArray['sponser_rel'] = $arr['position'];
        $fieldArray['dummy'] = $arr['dummy'];
        $fieldArray['green'] = $arr['green'];
        $fieldArray['join_date'] = $current_time;
        $fieldArray['join_date_text'] = $current_date;
        $fieldArray['status'] = 1;
        $fieldArray['create_by'] = $SESSION_ARRAY['user_id'];
        $fieldArray['bonus_end_date'] = $current_time + (BONUS_EXPIRE_DAYS * 24 * 60 * 60);

        $fieldArray['address'] = $arr['address'];
        $fieldArray['city'] = $arr['city'];
        $fieldArray['state'] = $arr['state'];
        $fieldArray['country'] = $arr['country'];
        $fieldArray['pincode'] = $arr['pincode'];

        global $ARR_PLANS;
        $plan = $arr['plan'];
        $bonus = $ARR_PLANS[$plan]['bonus'];
        $direct = $ARR_PLANS[$plan]['direct'];
        $binary = $ARR_PLANS[$plan]['binary'];
        $daily = $ARR_PLANS[$plan]['daily'];
        $binary_capping = $ARR_PLANS[$plan]['binary_capping'];

        $fieldArray['bonus'] = $bonus;
        $fieldArray['direct'] = $direct;
        $fieldArray['binary'] = $binary;
        $fieldArray['daily'] = $daily;
        $fieldArray['binary_capping'] = $binary_capping;

        if ($arr['green'] == 1) {
            $fieldArray['green_date'] = $current_time;
            $fieldArray['green_end_date'] = $current_time + (GREEN_EXPIRE_DAYS * 24 * 60 * 60);
        }

        $sponser_id = $arr['sponser_id'];
        if ($arr['position'] == 'L') {
            $arr_parent_user = $this->findMostLeftUser($sponser_id);
        } else {
            $arr_parent_user = $this->findMostRightUser($sponser_id);
        }

        $parent_id = $arr_parent_user['user_id'];
        $arr_sponser_user = $this->getUserInfo($sponser_id);

        $fieldArray['parent_id'] = $arr_parent_user['user_id'];
        $fieldArray['parent_hierarchy'] = $arr_parent_user['parent_hierarchy'] . "/" . $arr_parent_user['user_id'];
        $fieldArray['sponser_hierarchy'] = $arr_sponser_user['sponser_hierarchy'] . "/" . $arr_sponser_user['user_id'];

        // insert new userinfo	
        $data = $this->insert($table, $fieldArray);

        $fieldArray = array();
        if ($arr['position'] == 'L') {
            $fieldArray['left_node'] = $user_id;
        } else {
            $fieldArray['right_node'] = $user_id;
        }

        $obj = $this->loadModel('commonUtility');
        $ARR_SYSTEM_SETTINGS = $obj->getSystemSettings();
        $PARENT_REG_AMOUNT_CUT_PER = $ARR_SYSTEM_SETTINGS['PARENT_REG_AMOUNT_CUT_PER'];
        $wallet_cut = $arr['plan'] * ($PARENT_REG_AMOUNT_CUT_PER / 100);

        // update parent left/right node
        $where = "user_id='$parent_id'";
        $limit = 1;
        $this->update($table, $fieldArray, $where, $limit);

        // update sponser wallet
        $bonus_left = $arr_sponser_user['bonus_left'];
        $bonus_right = $arr_sponser_user['bonus_right'];
        $bonus_status = $arr_sponser_user['bonus_status'];
        if ($arr_sponser_user['bonus_status'] == 0 && $arr_sponser_user['bonus_end_date'] > $current_time) {
            if ($arr['position'] == 'L') {
                $bonus_left = $bonus_left + $arr['plan'];
            } else {
                $bonus_right = $bonus_right + $arr['plan'];
            }

            if ($bonus_left >= $arr_sponser_user['plan'] && $bonus_right >= $arr_sponser_user['plan']) {
                //$bonus_left = 0;
                //$bonus_right = 0;
                $bonus_status = 1;
            }
        }



        $fieldArray = array();
        $fieldArray['registration_wallet'] = $arr_sponser_user['registration_wallet'] - $wallet_cut;
        $fieldArray['bonus_left'] = $bonus_left;
        $fieldArray['bonus_right'] = $bonus_right;
        $fieldArray['bonus_status'] = $bonus_status;
        $where = "user_id='$sponser_id'";
        $limit = 1;
        $this->update($table, $fieldArray, $where, $limit);


        $invocie_table = "invoices";
        $tran_insert_invoice = array();
        $tran_insert_invoice['user_id'] = $sponser_id;
        $tran_insert_invoice['coins'] = $wallet_cut;
        $tran_insert_invoice['wallet_type'] = "R";
        $tran_insert_invoice['create_date'] = CommonFunctions::currentTime();
        $tran_insert_invoice['create_date_text'] = date("d-M-Y g:i:s A");
        $tran_insert_invoice['create_day'] = strtotime(date("d-M-Y"));
        $tran_insert_invoice['action_type'] = "D";
        $tran_insert_invoice['create_by'] = $sponser_id;
        $tran_insert_invoice['description'] = "Register new User - " . $user_id;

        $this->insert($invocie_table, $tran_insert_invoice);  // create invoice for add credit
        // update total left/right in up hierarchy
        $this->updateTotalCountInUpHierarchy($parent_id, $user_id);

        if ($arr['green'] == 0) {
            // update donation info as receive link by user
            $table = "donation_info";
            $fieldArray = array();
            $fieldArray['user_id'] = $user_id;
            $fieldArray['coins'] = $arr['plan'] - $wallet_cut;
            $fieldArray['create_date'] = $current_time;
            $fieldArray['start_date'] = $current_time;

            $this->insert($table, $fieldArray);
        } else {
            // insert data in green info
            $table = "green_info";
            $fieldArray = array();
            $fieldArray['user_id'] = $user_id;
            $fieldArray['create_date'] = $current_time;

            $this->insert($table, $fieldArray);
        }

        // update total left/right in up hierarchy
        $this->sendRegistrationMail($user_id);

        return $user_id;
    }

    public function checkValidUser($user_id) {
        $table = 'user_account';
        $fieldArray = array();
        $where = "user_id='$user_id'";
        $limit = 1;

        $arr = $this->select($table, $fieldArray, $where, 1);

        $output = array();
        if (!empty($arr)) {
            $output = $arr[0];
        }

        return $output;
    }

    public function checkValidUserUnderSponser($user_id, $sponser_id) {
        $table = 'user_account';
        $fieldArray = array();
        $where = "user_id='$user_id' AND (sponser_hierarchy LIKE '%/$sponser_id%' OR coins_transfer_from='$sponser_id') ";
        $limit = 1;

        $arr = $this->select($table, $fieldArray, $where, 1);

        $output = array();
        if (!empty($arr)) {
            $output = $arr[0];
        }

        return $output;
    }

    public function checkValidUserUnderParent($user_id, $parent_id) {
        $table = 'user_account';
        $fieldArray = array();
        $where = "user_id='$user_id' AND parent_hierarchy LIKE '%/$parent_id%'";
        $limit = 1;

        $arr = $this->select($table, $fieldArray, $where, 1);

        $output = array();
        if (!empty($arr)) {
            $output = $arr[0];
        }

        return $output;
    }

    public function findMostLeftRightUser($sponser_id, $node) {
        $arr_user = $this->findUserInHierarchy($sponser_id, $node);
        return $arr_user;
    }

    public function findUserInHierarchy($sponser_id, $pos) {

        $arr = $this->db->where('user_id', $sponser_id)->limit(1)
                        ->get('users_login')->result_array();

        if ($pos == 'L') {
            $node = $arr[0]['left_node'];
        } else {
            $node = $arr[0]['right_node'];
        }

        if ($node == 0) {
            return $arr[0];
        } else {
            return $this->findUserInHierarchy($node, $pos);
        }
        return;
    }

    public function generateUserId() {
        $loop = 1;
        do {
            $user_id = CommonFunctions::generateKey(8, 0, 0, 1);
            $user_id = ltrim($user_id, '0');
            if (strlen($user_id) != 8 || substr($user_id, 0, 1) == "0" || substr($user_id, 0, 1) == 0) {
                continue;
            }

            $arr = $this->checkValidUser($user_id);
            if (empty($arr)) {
                $loop = 0;
            }
        } while ($loop == 1);

        return $user_id;
    }

    public function updateTotalCountInUpHierarchy($parent_id, $child_id) {
        $parent_data = $this->getUserInfo($parent_id);

        $fieldArray = array();

        if ($parent_data['left_node'] == $child_id) {
            $fieldArray['total_left'] = $parent_data['total_left'] + 1;
        } else {
            $fieldArray['total_right'] = $parent_data['total_right'] + 1;
        }

        $this->db->where('user_id', $parent_id)->update('users_login', $fieldArray);


        if ($parent_data['parent_id'] == 0) {
            return;
        } else {
            return $this->updateTotalCountInUpHierarchy($parent_data['parent_id'], $parent_id);
        }
    }

    public function listUsersAM($arrSearch = array()) {
        $table = 'user_account';

        $where = " id!='' ";
        $page_no = 1;
        $rows_per_page = LIST_ROWS_PER_PAGE;
        $include_limit = "Y";
        $search_url = 'search=true';

        $arr_search_url = array();
        //$rows_per_page =20;

        if (!empty($arrSearch)) {
            if (isset($arrSearch['include_limit']) && $arrSearch['include_limit'] != '') {
                $include_limit = $arrSearch['include_limit'];
            }

            if (isset($arrSearch['search_user_id']) && $arrSearch['search_user_id'] != '') {
                $search_user_id = $arrSearch['search_user_id'];
                $where .= " AND user_id='" . $search_user_id . "' ";

                $arr_search_url['search_user_id'] = 'search_user_id=' . $search_user_id;
            }


            if (isset($arrSearch['search_name']) && $arrSearch['search_name'] != '') {
                $search_name = $arrSearch['search_name'];
                $where .= " AND name LIKE '%" . $search_name . "%' ";

                $arr_search_url['search_name'] = 'search_name=' . $search_name;
            }

            if (isset($arrSearch['search_mobile_no']) && $arrSearch['search_mobile_no'] != '') {
                $search_mobile_no = $arrSearch['search_mobile_no'];
                $where .= " AND mobile_no='" . $search_mobile_no . "' ";

                $arr_search_url['search_mobile_no'] = 'search_mobile_no=' . $search_mobile_no;
            }

            if (isset($arrSearch['search_email_id']) && $arrSearch['search_email_id'] != '') {
                $search_email_id = $arrSearch['search_email_id'];
                $where .= " AND email_id='" . $search_email_id . "' ";

                $arr_search_url['search_email_id'] = 'search_email_id=' . $search_email_id;
            }

            if (isset($arrSearch['search_sponser_id']) && $arrSearch['search_sponser_id'] != '') {
                $search_sponser_id = $arrSearch['search_sponser_id'];
                $where .= " AND sponser_id='" . $search_sponser_id . "' ";

                $arr_search_url['search_sponser_id'] = 'search_sponser_id=' . $search_sponser_id;
            }

            if (isset($arrSearch['search_parent_id']) && $arrSearch['search_parent_id'] != '') {
                $search_parent_id = $arrSearch['search_parent_id'];
                $where .= " AND parent_id='" . $search_parent_id . "' ";

                $arr_search_url['search_parent_id'] = 'search_parent_id=' . $search_parent_id;
            }

            if (isset($arrSearch['parent_hierarchy_user_id']) && $arrSearch['parent_hierarchy_user_id'] != '') {
                $parent_hierarchy_user_id = $arrSearch['parent_hierarchy_user_id'];
                $where .= " AND parent_hierarchy LIKE '%/" . $parent_hierarchy_user_id . "%' ";
            }

            if (isset($arrSearch['sponser_hierarchy_user_id']) && $arrSearch['sponser_hierarchy_user_id'] != '') {
                $sponser_hierarchy_user_id = $arrSearch['sponser_hierarchy_user_id'];
                $where .= " AND sponser_hierarchy LIKE '%/" . $sponser_hierarchy_user_id . "%' ";
            }

            if (isset($arrSearch['my_sponser_id']) && $arrSearch['my_sponser_id'] != '') {
                $my_sponser_id = $arrSearch['my_sponser_id'];
                $where .= " AND sponser_id='" . $my_sponser_id . "' ";
            }

            if (isset($arrSearch['search_password']) && $arrSearch['search_password'] != '') {
                $search_password = $arrSearch['search_password'];
                $where .= " AND password='" . $search_password . "' ";

                $arr_search_url['search_password'] = 'search_password=' . $search_password;
            }



            if (isset($arrSearch['search_transaction_password']) && $arrSearch['search_transaction_password'] != '') {
                $search_transaction_password = $arrSearch['search_transaction_password'];
                $where .= " AND transaction_password='" . $search_transaction_password . "' ";

                $arr_search_url['search_transaction_password'] = 'search_transaction_password=' . $search_transaction_password;
            }


            if (isset($arrSearch['search_status']) && $arrSearch['search_status'] != '') {
                $search_status = $arrSearch['search_status'];
                if ($arrSearch['search_status'] == 'active')
                    $where .= " AND status=1 ";
                else if ($arrSearch['search_status'] == 'inactive')
                    $where .= " AND status=0 ";

                $arr_search_url['search_status'] = 'search_status=' . $search_status;
            }

            if (isset($arrSearch['rows_per_page']) && $arrSearch['rows_per_page'] != '') {
                $rows_per_page = $arrSearch['rows_per_page'];
            }


            if (isset($arrSearch['page_no']) && $arrSearch['page_no'] != '') {
                $page_no = $arrSearch['page_no'];
            }
        }

        $order_by_text = " ORDER BY join_date ";

        $search_limit = "";
        if ($include_limit == 'Y') {
            $search_limit = " " . ($rows_per_page * ($page_no - 1)) . ", " . $rows_per_page . " ";
        }

        $count = $this->getCountFromTable($table, $where);

        $sql = "SELECT * FROM $table WHERE " . $where . " " . $order_by_text . " LIMIT " . $search_limit;
        // echo $sql;
        $data['tbl_data'] = $this->query_exec($sql);



        $data['total_rows'] = $count;
        $data['total_page'] = ceil($count / $rows_per_page);
        $data['search_url'] = implode("&", $arr_search_url);
        $data['rows_per_page'] = $rows_per_page;
        $data['page_no'] = $page_no;

        return $data;
    }

    /* ram functions */

    public function isUserExists($user_id) {
        if (strlen($user_id) == ADMIN_ID_LENGTH) {
            $table = "admin_account";
        } else {
            $table = "user_account";
        }

        $where = "user_id='$user_id'";
        return $this->select($table, array(), $where, 1);
    }

    public function getUserDownlineParentHierarchy($user_id) {
        $table = "user_account";
        $where = "user_id='$user_id' OR parent_hierarchy LIKE '%/$user_id%'";
        $fieldArray = array();

        $data = $this->select($table, $fieldArray, $where);

        $new_data = array();
        foreach ($data as $key => $arr) {
            $new_data[$arr['user_id']] = $arr;
        }

        return $new_data;
    }

    public function getUserDownlineSponserHierarchy($user_id) {
        $table = "user_account";
        $where = "user_id='$user_id' OR sponser_hierarchy LIKE '%/$user_id%'";
        $fieldArray = array();

        $data = $this->select($table, $fieldArray, $where);

        $new_data = array();
        foreach ($data as $key => $arr) {
            $new_data[$arr['user_id']] = $arr;
        }

        return $new_data;
    }

    public function getPendingWithdrawal($user_id) {
        $table = "withdrawal_info";
        $fieldArray = array();
        $where = "user_id='$user_id' AND status=0 ";
        $limit = 1;

        $output = array();
        $data = $this->select($table, $fieldArray, $where, $limit);
        if (!empty($data)) {
            $output = $data[0];
        }

        return $output;
    }

    public function makeWithdrawalFromSellWallet($user_id, $coins, $current_coins) {
        $USER_INFO = $this->getUserInfo($user_id);

        $table = "user_account";
        $fieldArray = array();
        $fieldArray['sell_wallet'] = $current_coins - $coins;
        $where = "user_id='$user_id'";
        $limit = 1;

        $this->update($table, $fieldArray, $where, $limit);

        $current_time = CommonFunctions::currentTime();
        $table = "withdrawal_info";
        $fieldArray = array();
        $fieldArray['user_id'] = $user_id;
        $fieldArray['coins'] = $coins;
        $fieldArray['wallet'] = "S";
        $fieldArray['create_date'] = $current_time;
        $fieldArray['start_date'] = $current_time + ($USER_INFO['withdrawal_delay_days'] * 24 * 60 * 60);

        $this->insert($table, $fieldArray);
    }

    public function makeWithdrawalFromGoldWallet($user_id, $coins, $current_coins) {
        $USER_INFO = $this->getUserInfo($user_id);

        $table = "user_account";
        $fieldArray = array();
        $fieldArray['gold_wallet'] = $current_coins - $coins;
        $where = "user_id='$user_id'";
        $limit = 1;

        $this->update($table, $fieldArray, $where, $limit);

        $current_time = CommonFunctions::currentTime();
        $table = "withdrawal_info";
        $fieldArray = array();
        $fieldArray['user_id'] = $user_id;
        $fieldArray['coins'] = $coins;
        $fieldArray['wallet'] = "G";
        $fieldArray['create_date'] = $current_time;
        $fieldArray['start_date'] = $current_time + ($USER_INFO['withdrawal_delay_days'] * 24 * 60 * 60);

        $this->insert($table, $fieldArray);
    }

    public function listWithdrawalHistory($arrSearch = array()) {
        $table = 'withdrawal_info';

        $where = " id!='' ";
        $page_no = 1;
        $rows_per_page = LIST_ROWS_PER_PAGE;
        $include_limit = "Y";
        $search_url = 'search=true';

        $arr_search_url = array();
        //$rows_per_page =20;

        if (!empty($arrSearch)) {
            if (isset($arrSearch['include_limit']) && $arrSearch['include_limit'] != '') {
                $include_limit = $arrSearch['include_limit'];
            }

            if (isset($arrSearch['search_user_id']) && $arrSearch['search_user_id'] != '') {
                $search_user_id = $arrSearch['search_user_id'];
                $where .= " AND user_id='" . $search_user_id . "' ";

                $arr_search_url['search_user_id'] = 'search_user_id=' . $search_user_id;
            }


            if (isset($arrSearch['search_wallet']) && $arrSearch['search_wallet'] != '') {
                $search_wallet = $arrSearch['search_wallet'];

                if ($search_wallet == 'O') {
                    $where .= " AND wallet='' ";
                } else {
                    $where .= " AND wallet='" . $search_wallet . "' ";
                }

                $arr_search_url['search_wallet'] = 'search_wallet=' . $search_wallet;
            }


            if (isset($arrSearch['search_from_date']) && $arrSearch['search_from_date'] != '') {
                $search_from_date = $arrSearch['search_from_date'];
                $search_from_time = CommonFunctions::dateToTime($search_from_date);
                $where .= " AND create_date>='" . $search_from_time . "' ";

                $arr_search_url['search_from_date'] = 'search_from_date=' . $search_from_date;
            }

            if (isset($arrSearch['search_to_date']) && $arrSearch['search_to_date'] != '') {
                $search_to_date = $arrSearch['search_to_date'];
                $search_to_time = CommonFunctions::dateToTime($search_to_date) + (3600 * 24);
                $where .= " AND create_date<='" . $search_to_time . "' ";

                $arr_search_url['search_to_date'] = 'search_to_date=' . $search_to_date;
            }

            if (isset($arrSearch['search_my_user_id']) && $arrSearch['search_my_user_id'] != '') {
                $search_my_user_id = $arrSearch['search_my_user_id'];
                $where .= " AND user_id='" . $search_my_user_id . "' ";
            }

            if (isset($arrSearch['search_status']) && $arrSearch['search_status'] != '') {
                $search_status = $arrSearch['search_status'];
                if ($search_status == 'pending')
                    $where .= " AND status=0 ";
                else if ($search_status == 'completed')
                    $where .= " AND status=1 ";
                if ($search_status == 'rejected')
                    $where .= " AND status=2 ";

                $arr_search_url['search_status'] = 'search_status=' . $search_status;
            }

            if (isset($arrSearch['rows_per_page']) && $arrSearch['rows_per_page'] != '') {
                $rows_per_page = $arrSearch['rows_per_page'];
            }


            if (isset($arrSearch['page_no']) && $arrSearch['page_no'] != '') {
                $page_no = $arrSearch['page_no'];
            }
        }

        $order_by_text = " ORDER BY id ";

        $search_limit = "";
        if ($include_limit == 'Y') {
            $search_limit = " " . ($rows_per_page * ($page_no - 1)) . ", " . $rows_per_page . " ";
        }

        $count = $this->getCountFromTable($table, $where);

        $sql = "SELECT * FROM $table WHERE " . $where . " " . $order_by_text . " LIMIT " . $search_limit;
        // echo $sql;
        $data['tbl_data'] = $this->query_exec($sql);

        foreach ($data['tbl_data'] as $key => $arr) {
            $data['tbl_data'][$key]['user_data'] = $this->getUserInfo($arr['user_id']);

            $sql2 = "SELECT SUM(coins) as coins FROM $table WHERE user_id='" . $arr['user_id'] . "' AND status=1 ";
            $data2 = $this->query_exec($sql2);
            $data['tbl_data'][$key]['coins_taken'] = $data2[0]['coins'];
        }

        $data['total_rows'] = $count;
        $data['total_page'] = ceil($count / $rows_per_page);
        $data['search_url'] = implode("&", $arr_search_url);
        $data['rows_per_page'] = $rows_per_page;
        $data['page_no'] = $page_no;

        return $data;
    }

    public function getWithdrawalLinks($withdrawal_id) {
        $table = "links";
        $fieldArray = array();
        $where = "withdrawal_id='$withdrawal_id'";

        $data = $this->select($table, $fieldArray, $where);

        foreach ($data as $key => $arr) {
            $withdrawal_user_id = $arr['withdrawal_user_id'];
            $donation_user_id = $arr['donation_user_id'];

            $withdrawal_user_data = $this->getUserInfo($withdrawal_user_id);
            $withdrawal_user_sponser_data = $this->getUserInfo($withdrawal_user_data['sponser_id']);

            $donation_user_data = $this->getUserInfo($donation_user_id);
            $donation_user_sponser_data = $this->getUserInfo($donation_user_data['sponser_id']);

            $data[$key]['withdrawal_user_data'] = $withdrawal_user_data;
            $data[$key]['withdrawal_user_sponser_data'] = $withdrawal_user_sponser_data;

            $data[$key]['donation_user_data'] = $donation_user_data;
            $data[$key]['donation_user_sponser_data'] = $donation_user_sponser_data;
        }

        return $data;
    }

    public function getDonationLinks($donation_id) {
        $table = "links";
        $fieldArray = array();
        $where = "donation_id='$donation_id'";

        $data = $this->select($table, $fieldArray, $where);

        foreach ($data as $key => $arr) {
            $withdrawal_user_id = $arr['withdrawal_user_id'];
            $donation_user_id = $arr['donation_user_id'];

            $withdrawal_user_data = $this->getUserInfo($withdrawal_user_id);
            $withdrawal_user_sponser_data = $this->getUserInfo($withdrawal_user_data['sponser_id']);

            $donation_user_data = $this->getUserInfo($donation_user_id);
            $donation_user_sponser_data = $this->getUserInfo($donation_user_data['sponser_id']);

            $data[$key]['withdrawal_user_data'] = $withdrawal_user_data;
            $data[$key]['withdrawal_user_sponser_data'] = $withdrawal_user_sponser_data;

            $data[$key]['donation_user_data'] = $donation_user_data;
            $data[$key]['donation_user_sponser_data'] = $donation_user_sponser_data;
        }


        return $data;
    }

    public function getPendingDonation($user_id) {
        $table = "donation_info";
        $fieldArray = array();
        $where = "user_id='$user_id' AND status=0 ";
        $limit = 1;

        $output = array();
        $data = $this->select($table, $fieldArray, $where, $limit);
        if (!empty($data)) {
            $output = $data[0];
        }

        return $output;
    }

    public function listDonationHistory($arrSearch = array()) {
        $table = 'donation_info';

        $where = " id!='' ";
        $page_no = 1;
        $rows_per_page = LIST_ROWS_PER_PAGE;
        $include_limit = "Y";
        $search_url = 'search=true';

        $arr_search_url = array();
        //$rows_per_page =20;

        if (!empty($arrSearch)) {
            if (isset($arrSearch['include_limit']) && $arrSearch['include_limit'] != '') {
                $include_limit = $arrSearch['include_limit'];
            }

            if (isset($arrSearch['search_user_id']) && $arrSearch['search_user_id'] != '') {
                $search_user_id = $arrSearch['search_user_id'];
                $where .= " AND user_id='" . $search_user_id . "' ";

                $arr_search_url['search_user_id'] = 'search_user_id=' . $search_user_id;
            }


            if (isset($arrSearch['search_from_date']) && $arrSearch['search_from_date'] != '') {
                $search_from_date = $arrSearch['search_from_date'];
                $search_from_time = CommonFunctions::dateToTime($search_from_date);
                $where .= " AND create_date>='" . $search_from_time . "' ";

                $arr_search_url['search_from_date'] = 'search_from_date=' . $search_from_date;
            }

            if (isset($arrSearch['search_to_date']) && $arrSearch['search_to_date'] != '') {
                $search_to_date = $arrSearch['search_to_date'];
                $search_to_time = CommonFunctions::dateToTime($search_to_date) + (3600 * 24);
                $where .= " AND create_date<='" . $search_to_time . "' ";

                $arr_search_url['search_to_date'] = 'search_to_date=' . $search_to_date;
            }

            if (isset($arrSearch['search_my_user_id']) && $arrSearch['search_my_user_id'] != '') {
                $search_my_user_id = $arrSearch['search_my_user_id'];
                $where .= " AND user_id='" . $search_my_user_id . "' ";
            }

            if (isset($arrSearch['search_status']) && $arrSearch['search_status'] != '') {
                $search_status = $arrSearch['search_status'];
                if ($search_status == 'pending')
                    $where .= " AND status=0 ";
                else if ($search_status == 'completed')
                    $where .= " AND status=1 ";
                if ($search_status == 'rejected')
                    $where .= " AND status=2 ";

                $arr_search_url['search_status'] = 'search_status=' . $search_status;
            }

            if (isset($arrSearch['rows_per_page']) && $arrSearch['rows_per_page'] != '') {
                $rows_per_page = $arrSearch['rows_per_page'];
            }


            if (isset($arrSearch['page_no']) && $arrSearch['page_no'] != '') {
                $page_no = $arrSearch['page_no'];
            }
        }

        $order_by_text = " ORDER BY id ";

        $search_limit = "";
        if ($include_limit == 'Y') {
            $search_limit = " " . ($rows_per_page * ($page_no - 1)) . ", " . $rows_per_page . " ";
        }

        $count = $this->getCountFromTable($table, $where);

        $sql = "SELECT * FROM $table WHERE " . $where . " " . $order_by_text . " LIMIT " . $search_limit;
        // echo $sql;
        $data['tbl_data'] = $this->query_exec($sql);

        foreach ($data['tbl_data'] as $key => $arr) {
            $data['tbl_data'][$key]['user_data'] = $this->getUserInfo($arr['user_id']);
        }

        $data['total_rows'] = $count;
        $data['total_page'] = ceil($count / $rows_per_page);
        $data['search_url'] = implode("&", $arr_search_url);
        $data['rows_per_page'] = $rows_per_page;
        $data['page_no'] = $page_no;

        return $data;
    }

    public function sendRegistrationMail($user_id) {
        $ARR_USER = $this->getUserInfo($user_id);
        $name = $ARR_USER['name'];
        $email_id = $ARR_USER['email_id'];
        $user_id = $ARR_USER['user_id'];
        $password = $ARR_USER['password'];
        $transaction_password = $ARR_USER['transaction_password'];

        $from_email_id = "info@newerracoins.com";
        $from_name = "New Erra coins";
        $subject = "New Erra Coins Login Details.";

        $message = "Welcome to New Erra Coins. \r\n\r\n";

        $message .= "Account enrolment Confirmation. \r\n\r\n";

        $message .= "Dear $name \r\n\r\n";

        $message .= "Congratulation !! \r\n\r\n";

        $message .= "You have successfully gone through the process of registration of New Erra Coins. \r\n\r\n";
        $message .= "You have accepted Terms and Conditions and Security policy while enrolling.";
        $message .= "This Email is confirmation of your enrolment data as selected / generated by you during enrolment process. ";
        $message .= "Please find following entrolment data for your reference. \r\n\r\n";

        $message .= "User ID : $user_id. \r\n";
        $message .= "Password : $password. \r\n";
        $message .= "Transaction Password : $transaction_password. \r\n\r\n\r\n";

        $message .= "Now you can refer start coin marketing with us and enjoy your coins investments return. \r\n\r\n\r\n\r\n";

        $message .= "Warm Regards. \r\n";
        $message .= "New Erra Coins Team. \r\n";

        $header = "From:$from_email_id \r\n";
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-type: text/plain\r\n";

        $retval = mail($email_id, $subject, $message, $header);

        if ($retval == true) {
            //echo "Message sent successfully...";
        } else {
            //echo "Message could not be sent...";
        }
    }

    public function getRegistrationText($user_id) {
        $ARR_USER = $this->getUserInfo($user_id);
        $name = $ARR_USER['name'];
        $email_id = $ARR_USER['email_id'];
        $user_id = $ARR_USER['user_id'];
        $password = $ARR_USER['password'];
        $transaction_password = $ARR_USER['transaction_password'];

        $from_email_id = "info@newerracoins.com";
        $from_name = "New Erra coins";
        $subject = "New Erra Coins Login Details.";

        $message = "Welcome to New Erra Coins. <br/><br/>";

        $message .= "Account enrolment Confirmation. <br/><br/>";

        $message .= "Dear $name <br/><br/>";

        $message .= "Congratulation !! <br/><br/>";

        $message .= "You have successfully gone through the process of registration of New Erra Coins. <br/><br/>";
        $message .= "You have accepted Terms and Conditions and Security policy while enrolling.";
        $message .= "This Email is confirmation of your enrolment data as selected / generated by you during enrolment process. ";
        $message .= "Please find following entrolment data for your reference. <br/><br/>";

        $message .= "User ID : $user_id. <br/>";
        $message .= "Password : $password. <br/>";
        $message .= "Transaction Password : $transaction_password. <br/><br/><br/>";

        $message .= "Now you can refer start coin marketing with us and enjoy your coins investments return. <br/><br/><br/><br/>";

        $message .= "Warm Regards. <br/>";
        $message .= "New Erra Coins Team. <br/>";

        return $message;
    }

    public function getUserTree($user_id, $level = 3) {
        if ($level < 3) {
            $level = 3;
        }

        $ARR_DATA = array();
        for ($i = 0; $i <= $level; $i++) {
            for ($k = 0; $k <= (pow(2, $i) - 1); $k++) {
                $ARR_DATA[$i][$k]['user_id'] = "NA";
            }
        }

        //Session::pr($ARR_DATA);

        $i = 0;
        $k = 0;

        $USER_DATA = $this->getUserInfo($user_id);
        if (!empty($USER_DATA)) {
            $ARR_DATA[$i][$k] = $USER_DATA;
            $left_node = $USER_DATA['left_node'];
            $right_node = $USER_DATA['right_node'];

            $i+=1;
            if ($left_node != 0) {
                $USER_DATA = $this->getUserInfo($left_node);
                $ARR_DATA[$i][$k] = $USER_DATA;
            }
            $k+=1;
            if ($right_node != 0) {
                $USER_DATA = $this->getUserInfo($right_node);
                $ARR_DATA[$i][$k] = $USER_DATA;
            }
        }

        $l = 1;

        //Session::pr($ARR_DATA);

        while ($l <= $level) {
            $x = $l - 1;
            $y = 0;
            $k = 0;

            //Session::pr($ARR_DATA[$x]);
            foreach ($ARR_DATA[$x] as $key => $arr) {
                //Session::pr($arr);
                $user_id = $arr['user_id'];
                //echo "  ".$user_id;
                if ($user_id != 'NA') {
                    $USER_DATA = $this->getUserInfo($user_id);
                    //Session::pr($USER_DATA); die;
                    $left_node = $USER_DATA['left_node'];
                    $right_node = $USER_DATA['right_node'];
                    if ($left_node != 0) {
                        $USER_DATA = $this->getUserInfo($left_node);
                        $ARR_DATA[$l][$k] = $USER_DATA;
                    }
                    $k+=1;
                    if ($right_node != 0) {
                        $USER_DATA = $this->getUserInfo($right_node);
                        $ARR_DATA[$l][$k] = $USER_DATA;
                    }
                    $k+=1;
                } else {
                    $k+=2;
                }
            }
            $l += 1;
        }

        return $ARR_DATA;
        //Session::pr($ARR_DATA);
        //die;
    }

    /* 4 july */

    public function editUserSubmit($postData, $SESSION_ARRAY) {
        $user_id = $postData['user_id'];
        $table = "user_account";
        //Session::pr($postData);
        //Session::pr($SESSION_ARRAY);

        $fieldArray = array();
        $fieldArray['name'] = $postData['name'];
        $fieldArray['mobile_no'] = $postData['mobile_no'];
        $fieldArray['email_id'] = $postData['email_id'];
        $fieldArray['city'] = $postData['city'];
        $fieldArray['state'] = $postData['state'];
        $fieldArray['country'] = $postData['country'];
        $fieldArray['address'] = $postData['address'];
        $fieldArray['pincode'] = $postData['pincode'];
        $where = "user_id='$user_id'";
        $limit = 1;
        return $this->update($table, $fieldArray, $where, $limit);
    }

    public function maxDuplicateMobileNoLimit($mobile, $limit, $user_id = null) {
        $table = "user_account";
        $where = " mobile_no ='$mobile' ";
        if ($user_id != null) {
            // echo "user not null<br>";
            $where .= " and user_id !='$user_id' ";
            $count = $this->getCountFromTable($table, $where);
            //  echo $count.'  '.$limit;
            // die;
            if ($count >= $limit) {
                return false;
            }
            return true;
        } else {
            // echo "else<br>";
            $count = $this->getCountFromTable($table, $where);
            // echo $count.'  '.$limit;
            // die;
            if ($count > $limit) {
                return false;
            }
            return true;
        }
    }

    public function changeWithdrawalActiveStatus($id) {
        $table = "withdrawal_info";
        $where = " id ='$id' ";
        $limit = 1;
        $fieldArray = array();

        $arr = $this->select($table, $fieldArray, $where, $limit);
        $id = $arr[0]['id'];
        if ($arr[0]['active'] == 1) {
            $active = 0;
        } else {
            $active = 1;
        }

        $fieldArray['active'] = $active;
        $this->update($table, $fieldArray, $where, $limit);

        $file = Session::getRootURL() . "user/changeWithdrawalActive/" . $id;
        if ($active == 0) {
            ?>
            <a style="color:red" href="javascript:void(0);" onclick="javascript:changeStatus('<?php echo $file; ?>', '<?php echo $id; ?>', '<?php echo "active_" . $id; ?>');">InActive</a>
            <?php
        } else {
            ?>
            <a style="color:green" href="javascript:void(0);" onclick="javascript:changeStatus('<?php echo $file; ?>', '<?php echo $id; ?>', '<?php echo "active_" . $id; ?>');">Active</a>
            <?php
        }
    }

    public function changeDonationActiveStatus($id) {
        $table = "donation_info";
        $where = " id ='$id' ";
        $limit = 1;
        $fieldArray = array();

        $arr = $this->select($table, $fieldArray, $where, $limit);
        $id = $arr[0]['id'];
        if ($arr[0]['active'] == 1) {
            $active = 0;
        } else {
            $active = 1;
        }

        $fieldArray['active'] = $active;
        $this->update($table, $fieldArray, $where, $limit);

        $file = Session::getRootURL() . "user/changeDonationActive/" . $id;
        if ($active == 0) {
            ?>
            <a style="color:red" href="javascript:void(0);" onclick="javascript:changeStatus('<?php echo $file; ?>', '<?php echo $id; ?>', '<?php echo "active_" . $id; ?>');">InActive</a>
            <?php
        } else {
            ?>
            <a style="color:green" href="javascript:void(0);" onclick="javascript:changeStatus('<?php echo $file; ?>', '<?php echo $id; ?>', '<?php echo "active_" . $id; ?>');">Active</a>
            <?php
        }
    }

}
