<?php

class login_mod extends CI_Model {

    function __construct() {
        parent::__construct();
    }

    function user_login() {
        $password = md5($_POST['password']);
        return $this->db->where('user_name', $_POST['user_name'])->where('password', $password)->where('active', '1')->get('admin_login')->result_array();
    }

}


