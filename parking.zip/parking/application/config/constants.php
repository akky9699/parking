<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

/*
  |--------------------------------------------------------------------------
  | File and Directory Modes
  |--------------------------------------------------------------------------
  |
  | These prefs are used when checking and setting modes when working
  | with the file system.  The defaults are fine on servers with proper
  | security, but you may wish (or even need) to change the values in
  | certain environments (Apache running a separate process for each
  | user, PHP under CGI with Apache suEXEC, etc.).  Octal values should
  | always be used to set the mode correctly.
  |
 */
define('FILE_READ_MODE', 0644);
define('FILE_WRITE_MODE', 0666);
define('DIR_READ_MODE', 0755);
define('DIR_WRITE_MODE', 0777);

/*
  |--------------------------------------------------------------------------
  | File Stream Modes
  |--------------------------------------------------------------------------
  |
  | These modes are used when working with fopen()/popen()
  |
 */

define('FOPEN_READ', 'rb');
define('FOPEN_READ_WRITE', 'r+b');
define('FOPEN_WRITE_CREATE_DESTRUCTIVE', 'wb'); // truncates existing file data, use with care
define('FOPEN_READ_WRITE_CREATE_DESTRUCTIVE', 'w+b'); // truncates existing file data, use with care
define('FOPEN_WRITE_CREATE', 'ab');
define('FOPEN_READ_WRITE_CREATE', 'a+b');
define('FOPEN_WRITE_CREATE_STRICT', 'xb');
define('FOPEN_READ_WRITE_CREATE_STRICT', 'x+b');

$open_on_array = array(1 => 'Monday', 2 => 'Tuesday', 3 => 'Wednesday', 4 => 'Thursday', 5 => 'Friday', 6 => 'Saturday', 7 => 'Sunday');

define('OPEN_ON_ARRAY', serialize($open_on_array));

define('CURRENCY_SYMBOL', 'Rs.');

$month_array = array(
    '01' => 'January',
    '02' => 'February',
    '03' => 'March',
    '04' => 'April',
    '05' => 'May',
    '06' => 'Jun',
    '07' => 'July',
    '08' => 'August',
    '09' => 'September',
    '10' => 'Octomber',
    '11' => 'November',
    '12' => 'December'
);
define('MONTH_ARRAY', serialize($month_array));

$order = array();
for ($i = 1; $i <= 50; $i++) {
    $order[$i] = $i;
}
define('ORDER', serialize($order));

define('ADMIN_NAME', 'naren');
define('ADMIN_FOLDER', 'admin/');

//$date_format = array(1 => 'Today`s',2 => 'Monthly', 3 => 'Yearly',4 => 'Custom',5 => 'Weekly');
$date_format = array(1 => 'Today`s',2 => 'Monthly', 3 => 'Yearly',4 => 'Custom Date');
define('DATE_FORMAT', serialize($date_format));

/* End of file constants.php */
/* Location: ./application/config/constants.php */